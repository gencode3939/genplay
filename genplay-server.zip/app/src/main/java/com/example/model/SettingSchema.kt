package com.example.model

enum class SettingType { BOOL, INT, ENUM, STRING }

data class SettingDef(
    val key: String,
    val type: SettingType,
    val defaultValue: Any,
    val group: String,
    val nameTr: String,
    val descTr: String,
    val options: List<String> = emptyList(),
    val rangeInt: IntRange? = null,
    val readOnly: Boolean = false,
    val adminOnly: Boolean = false,
    val requiresRestart: Boolean = false
)

object SettingSchema {
    val ALL: List<SettingDef> = listOf(
        // ── Görünüm (9) ────────────────────────────────────
        SettingDef("theme", SettingType.ENUM, "dark", "look", "Tema", "Koyu · AMOLED · Açık", listOf("dark", "amoled", "light")),
        SettingDef("palette", SettingType.ENUM, "genplay", "look", "Palet", "GenPlay · Sinema · Orman", listOf("genplay", "sinema", "orman")),
        SettingDef("card_size_adjust", SettingType.INT, 0, "look", "Kart boyutu", "−2 … +2 adım", rangeInt = -2..2),
        SettingDef("home_orientation", SettingType.ENUM, "vertical", "look", "Yönelim", "Dikey · Yatay", listOf("vertical", "horizontal")),
        SettingDef("folder_outlines", SettingType.BOOL, true, "look", "Klasör hatları", "Görsel kenarlıklar"),
        SettingDef("show_runtime_badge", SettingType.BOOL, true, "look", "Süre rozeti", "Karta süre ekle"),
        SettingDef("focus_preview", SettingType.BOOL, false, "look", "Odak önizleme", "Büyük önizleme"),
        SettingDef("animations", SettingType.BOOL, true, "look", "Animasyonlar", "Tüm geçiş süreleri"),
        SettingDef("font_scale", SettingType.ENUM, "normal", "look", "Yazı ölçeği", "%85 – %130", listOf("small", "normal", "large", "xlarge")),

        // ── Sunucu (5) ─────────────────────────────────────
        SettingDef("server_port", SettingType.INT, 8471, "net", "Sunucu portu", "Varsayılan 8471", rangeInt = 1024..65535, requiresRestart = true),
        SettingDef("max_streams", SettingType.INT, 4, "net", "Eşzamanlı akış", "5. istek 503 alır", rangeInt = 1..10),
        SettingDef("discovery_enabled", SettingType.BOOL, true, "net", "Yerel keşif", "NSD ile bulunabilirlik"),
        SettingDef("boot_autostart", SettingType.BOOL, false, "net", "Otomatik başlat", "Cihaz açılışında başlat", requiresRestart = true),
        SettingDef("language", SettingType.ENUM, "tr", "net", "Dil", "Arayüz dili", listOf("tr", "en"), requiresRestart = true),

        // ── Kütüphane (5) ──────────────────────────────────
        SettingDef("scan_on_start", SettingType.BOOL, true, "lib", "Açılışta tara", "Uygulama açılırken tara"),
        SettingDef("scan_wifi_only", SettingType.BOOL, true, "lib", "Yalnızca Wi-Fi", "Hücresel ağda tarama"),
        SettingDef("hide_played_latest", SettingType.BOOL, false, "lib", "İzlenenleri gizle", "Son eklenenlerde gizle"),
        SettingDef("exclude_patterns", SettingType.STRING, "*.tmp,.*", "lib", "Dışlama kalıpları", "Virgülle ayrılmış"),
        SettingDef("sort_language", SettingType.ENUM, "tr", "lib", "Sıralama dili", "Türkçe alfabe duyarlı", listOf("tr", "en")),

        // ── Cihazlar (4) ───────────────────────────────────
        SettingDef("auto_update_connect", SettingType.BOOL, true, "dev", "Otomatik eşleştirme", "TV cihazları otomatik eşle"),
        SettingDef("adb_timeout_s", SettingType.INT, 90, "dev", "Bağlantı zaman aşımı", "Saniye cinsinden", rangeInt = 30..300),
        SettingDef("keep_orphan_tokens", SettingType.BOOL, false, "dev", "Yetkisiz token koruma", "Eski tokenları tut"),
        SettingDef("deploy_verify", SettingType.BOOL, true, "dev", "Oturum doğrulama", "Cihaz oturum kontrolü"),

        // ── Oynatma (18) ───────────────────────────────────
        SettingDef("autoplay_next", SettingType.BOOL, true, "play", "Sıradaki bölüm", "Otomatik oynat"),
        SettingDef("autoplay_delay_ms", SettingType.INT, 8000, "play", "Geri sayım", "Milisaniye", rangeInt = 3000..30000),
        SettingDef("resume_threshold", SettingType.INT, 90, "play", "Tamamlama eşiği", "Yüzde", rangeInt = 50..99),
        SettingDef("intro_skip_enabled", SettingType.BOOL, false, "play", "Jenerik atla", "Bölüm jenerik atlama"),
        SettingDef("skip_back_seconds", SettingType.INT, 10, "play", "Geri atlama", "Saniye", rangeInt = 5..30),
        SettingDef("skip_forward_seconds", SettingType.INT, 30, "play", "İleri atlama", "Saniye", rangeInt = 10..120),
        SettingDef("audio_boost", SettingType.BOOL, false, "play", "Ses yükseltme", "Düşük sesli içerik"),
        SettingDef("refresh_rate_match", SettingType.BOOL, true, "play", "Yenileme hızı eşleme", "24p içerik ekran hızı"),
        SettingDef("max_bitrate_mbps", SettingType.INT, 0, "play", "Bit hızı sınırı", "0 = sınırsız", rangeInt = 0..400),
        SettingDef("subtitle_enabled", SettingType.BOOL, false, "play", "Altyazı aç", "Varsayılan durum"),
        SettingDef("subtitle_language", SettingType.STRING, "tr", "play", "Altyazı dili", "Varsayılan dil"),
        SettingDef("subtitle_size", SettingType.ENUM, "medium", "play", "Altyazı boyutu", "Yazı boyutu", listOf("small", "medium", "large", "xlarge")),
        SettingDef("subtitle_color", SettingType.ENUM, "white", "play", "Altyazı rengi", "Metin rengi", listOf("white", "yellow", "cyan")),
        SettingDef("subtitle_background", SettingType.ENUM, "translucent", "play", "Altyazı arka planı", "Okunabilirlik", listOf("none", "translucent", "opaque")),
        SettingDef("subtitle_position", SettingType.ENUM, "bottom", "play", "Altyazı konumu", "Ekran konumu", listOf("bottom", "top")),
        SettingDef("subtitle_on_skipback", SettingType.BOOL, true, "play", "Geri sarınca altyazı", "Geri sarmada aç"),
        SettingDef("subtitle_force_override", SettingType.BOOL, false, "play", "Zorunlu altyazı", "Gömülü stilleri ez"),
        SettingDef("sound_effects", SettingType.BOOL, false, "play", "Ses efektleri", "Arayüz sesleri"),

        // ── Gizlilik & Sistem (3) ──────────────────────────
        SettingDef("show_stats_overlay", SettingType.BOOL, false, "priv", "İstatistik bilgisi", "Oynatma detayları"),
        SettingDef("show_file_path", SettingType.BOOL, false, "priv", "Dosya yolları", "Yönetici alanları", adminOnly = true),
        SettingDef("log_level", SettingType.ENUM, "warn", "priv", "Günlük seviyesi", "Sessiz · Normal · Ayrıntılı", listOf("error", "warn", "info"), adminOnly = true, requiresRestart = true)
    )

    fun find(key: String): SettingDef? = ALL.find { it.key == key }

    fun isValid(key: String, value: Any): Boolean {
        val def = find(key) ?: return false
        return when (def.type) {
            SettingType.BOOL -> value is Boolean
            SettingType.INT -> {
                val num = (value as? Number)?.toInt() ?: return false
                def.rangeInt == null || num in def.rangeInt
            }
            SettingType.ENUM -> value is String && def.options.contains(value)
            SettingType.STRING -> value is String
        }
    }
}
