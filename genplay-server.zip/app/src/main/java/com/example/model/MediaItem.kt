package com.example.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class MediaItem(
    @Json(name = "Id") val id: String,
    @Json(name = "ParentId") val parentId: String? = null,
    @Json(name = "Type") val type: String, // Movie, Series, Season, Episode, Video, Album, Audio, Folder
    @Json(name = "MediaType") val mediaType: String = "Video", // Video, Audio, Photo
    @Json(name = "Name") val name: String,
    @Json(name = "OriginalTitle") val originalTitle: String? = null,
    @Json(name = "SortName") val sortName: String = name,
    @Json(name = "IndexNumber") val indexNumber: Int? = null,
    @Json(name = "ParentIndexNumber") val parentIndexNumber: Int? = null,
    @Json(name = "ProductionYear") val productionYear: Int? = null,
    @Json(name = "PremiereDate") val premiereDate: String? = null,
    @Json(name = "DateCreated") val dateCreated: String = "",
    @Json(name = "Overview") val overview: String? = null,
    @Json(name = "Tagline") val tagline: String? = null,
    @Json(name = "OfficialRating") val officialRating: String? = null,
    @Json(name = "CommunityRating") val communityRating: Float? = null,
    @Json(name = "RunTimeTicks") val runTimeTicks: Long? = null, // 1 sec = 10,000,000 ticks
    @Json(name = "IsFolder") val isFolder: Boolean = false,
    @Json(name = "HasDrm") val hasDrm: Boolean = false,
    @Json(name = "Genres") val genres: List<String> = emptyList(),
    @Json(name = "People") val people: List<PersonCredit> = emptyList(),
    @Json(name = "MediaSources") val mediaSources: List<MediaSource> = emptyList(),
    @Json(name = "ImageTags") val imageTags: Map<String, String> = emptyMap(),
    @Json(name = "BackdropImageTags") val backdropImageTags: List<String> = emptyList(),
    @Json(name = "PrimaryImageAspectRatio") val primaryImageAspectRatio: Float? = null,
    @Json(name = "UserData") val userData: UserData? = null,
    @Json(name = "Chapters") val chapters: List<Chapter> = emptyList(),
    @Json(name = "MediaStreams") val mediaStreams: List<MediaStream> = emptyList(),
    @Json(name = "Path") val path: String? = null
) {
    fun runtimeSeconds(): Long = (runTimeTicks ?: 0L) / 10_000_000L
}

@JsonClass(generateAdapter = true)
data class PersonCredit(
    @Json(name = "Name") val name: String,
    @Json(name = "Type") val type: String = "Actor", // Actor, Director, Writer, Producer
    @Json(name = "Role") val role: String? = null
)

@JsonClass(generateAdapter = true)
data class MediaSource(
    @Json(name = "Id") val id: String,
    @Json(name = "Path") val path: String,
    @Json(name = "Protocol") val protocol: String = "File",
    @Json(name = "Container") val container: String = "mp4",
    @Json(name = "Size") val size: Long = 0L,
    @Json(name = "Bitrate") val bitrate: Long = 0L
)

@JsonClass(generateAdapter = true)
data class Chapter(
    @Json(name = "StartTicks") val startTicks: Long,
    @Json(name = "Name") val name: String,
    @Json(name = "ImageTag") val imageTag: String? = null
)

@JsonClass(generateAdapter = true)
data class MediaStream(
    @Json(name = "Type") val type: String, // Video, Audio, Subtitle
    @Json(name = "Index") val index: Int,
    @Json(name = "Codec") val codec: String,
    @Json(name = "Language") val language: String? = null,
    @Json(name = "IsDefault") val isDefault: Boolean = false,
    @Json(name = "IsForced") val isForced: Boolean = false
)

@JsonClass(generateAdapter = true)
data class UserData(
    @Json(name = "PlayedPercentage") val playedPercentage: Float = 0f,
    @Json(name = "PlaybackPositionTicks") val playbackPositionTicks: Long = 0L,
    @Json(name = "IsPlayed") val isPlayed: Boolean = false,
    @Json(name = "IsFavorite") val isFavorite: Boolean = false,
    @Json(name = "PlayCount") val playCount: Int = 0
)
