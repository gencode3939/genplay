package com.example.model

enum class CardShape {
    PORTRAIT,     // 2:3 ratio (Movies/Series)
    BACKDROP,     // 16:9 ratio (Resume points, Episodes)
    FOUR_THREE,   // 4:3 ratio
    SQUARE,       // 1:1 ratio (Albums, Music)
    SIDE_FOOTER,  // Compact horizontal tile
    SPOTLIGHT,    // Hero banner
    AUTO_WIDTH    // Banner / info card
}

fun resolveCardShape(
    userOverride: CardShape?,
    firstItem: MediaItem?,
    sectionType: SectionType
): CardShape {
    if (userOverride != null) return userOverride

    if (firstItem != null) {
        if (firstItem.backdropImageTags.isNotEmpty() || firstItem.type == "Episode") {
            return CardShape.BACKDROP
        }
        if (firstItem.type == "Audio" || firstItem.type == "Album") {
            return CardShape.SQUARE
        }
    }

    return when (sectionType) {
        SectionType.RESUME, SectionType.NEXT_UP -> CardShape.BACKDROP
        SectionType.LATEST_MEDIA -> CardShape.PORTRAIT
        SectionType.USER_VIEWS, SectionType.DEVICES, SectionType.LIBRARIES -> CardShape.SIDE_FOOTER
        SectionType.LATEST_AUDIO, SectionType.PLAYLISTS -> CardShape.SQUARE
        SectionType.SCAN -> CardShape.AUTO_WIDTH
        SectionType.SPOTLIGHT -> CardShape.SPOTLIGHT
        else -> CardShape.PORTRAIT
    }
}
