package com.example.model

enum class SectionType(val titleTr: String) {
    SPOTLIGHT("Öne Çıkanlar"),
    RESUME("Devam Et"),
    NEXT_UP("Sıradaki"),
    LATEST_MEDIA("Son Eklenenler"),
    DISCOVER("Keşfet"),
    USER_VIEWS("Kütüphanelerim"),
    DEVICES("Cihazlar"),
    SCAN("Tarama"),
    LIBRARIES("Kütüphaneler"),
    LATEST_AUDIO("Son Eklenen Müzik"),
    PLAYLISTS("Çalma Listeleri"),
    COLLECTIONS("Koleksiyonlar")
}
