package com.example.security

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object CryptoManager {
    private const val KEY_ALIAS = "GenPlayAuthSecretKey"
    private const val ALGORITHM = KeyProperties.KEY_ALGORITHM_AES
    private const val BLOCK_MODE = KeyProperties.BLOCK_MODE_GCM
    private const val PADDING = KeyProperties.ENCRYPTION_PADDING_NONE
    private const val TRANSFORMATION = "$ALGORITHM/$BLOCK_MODE/$PADDING"

    private val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    private fun getSecretKey(): SecretKey {
        val existingKey = keyStore.getEntry(KEY_ALIAS, null) as? KeyStore.SecretKeyEntry
        if (existingKey != null) return existingKey.secretKey

        val keyGenerator = KeyGenerator.getInstance(ALGORITHM, "AndroidKeyStore")
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(BLOCK_MODE)
            .setEncryptionPaddings(PADDING)
            .setKeySize(256)
            .setUserAuthenticationRequired(false)
            .build()

        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }

    fun getOrCreateAuthSecret(context: Context): ByteArray {
        val file = File(context.noBackupFilesDir, "auth_secret.bin")
        if (file.exists()) {
            return decryptFile(file)
        }

        val secretBytes = ByteArray(32)
        SecureRandom().nextBytes(secretBytes)
        encryptToFile(secretBytes, file)
        return secretBytes
    }

    private fun encryptToFile(bytes: ByteArray, file: File) {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getSecretKey())
        val iv = cipher.iv

        FileOutputStream(file).use { fos ->
            fos.write(iv.size)
            fos.write(iv)
            val encryptedBytes = cipher.doFinal(bytes)
            fos.write(encryptedBytes.size)
            fos.write(encryptedBytes)
        }
    }

    private fun decryptFile(file: File): ByteArray {
        FileInputStream(file).use { fis ->
            val ivSize = fis.read()
            val iv = ByteArray(ivSize)
            fis.read(iv)

            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), GCMParameterSpec(128, iv))

            val encryptedSize = fis.read()
            val encryptedBytes = ByteArray(encryptedSize)
            fis.read(encryptedBytes)

            return cipher.doFinal(encryptedBytes)
        }
    }
}
