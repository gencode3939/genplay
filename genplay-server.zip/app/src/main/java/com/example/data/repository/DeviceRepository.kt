package com.example.data.repository

import com.example.data.db.ApiTokenEntity
import com.example.data.db.DeviceEntity
import com.example.data.db.GenPlayDatabase
import kotlinx.coroutines.flow.Flow

class DeviceRepository(private val db: GenPlayDatabase) {
    val devices: Flow<List<DeviceEntity>> = db.deviceDao().getAllDevices()

    suspend fun addOrUpdateDevice(device: DeviceEntity) {
        db.deviceDao().insertDevice(device)
    }

    suspend fun removeDevice(deviceId: String) {
        db.deviceDao().deleteDeviceById(deviceId)
        db.apiTokenDao().revokeTokenForDevice(deviceId)
    }

    suspend fun getDeviceById(id: String): DeviceEntity? {
        return db.deviceDao().getDeviceById(id)
    }

    suspend fun validateToken(hash: String): ApiTokenEntity? {
        return db.apiTokenDao().findValidTokenByHash(hash)
    }

    suspend fun saveToken(token: ApiTokenEntity) {
        db.apiTokenDao().insertToken(token)
    }
}
