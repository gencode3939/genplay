package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "library_folder")
data class LibraryFolderEntity(
    @PrimaryKey val id: String,
    val treeUri: String,
    val name: String,
    val dateAdded: Long = System.currentTimeMillis(),
    val itemCount: Int = 0
)

@Entity(tableName = "media_item")
data class MediaItemEntity(
    @PrimaryKey val id: String,
    val parentId: String? = null,
    val type: String,
    val mediaType: String = "Video",
    val name: String,
    val originalTitle: String? = null,
    val sortName: String,
    val indexNumber: Int? = null,
    val parentIndexNumber: Int? = null,
    val productionYear: Int? = null,
    val premiereDate: String? = null,
    val dateCreated: String,
    val overview: String? = null,
    val tagline: String? = null,
    val officialRating: String? = null,
    val communityRating: Float? = null,
    val runTimeTicks: Long? = null,
    val isFolder: Boolean = false,
    val hasDrm: Boolean = false,
    val genresJson: String = "[]",
    val peopleJson: String = "[]",
    val imageTagsJson: String = "{}",
    val backdropImageTagsJson: String = "[]",
    val primaryImageAspectRatio: Float? = null,
    val userDataJson: String? = null,
    val chaptersJson: String = "[]",
    val mediaStreamsJson: String = "[]",
    val path: String? = null,
    val fileSize: Long = 0L,
    val mimeType: String? = null,
    val checksum: String? = null
)

@Entity(tableName = "media_image")
data class MediaImageEntity(
    @PrimaryKey val id: String,
    val itemId: String,
    val imageType: String,
    val tag: String,
    val localPath: String? = null,
    val width: Int = 0,
    val height: Int = 0
)

@Entity(tableName = "subtitle_track")
data class SubtitleTrackEntity(
    @PrimaryKey val id: String,
    val itemId: String,
    val index: Int,
    val language: String = "tr",
    val title: String = "",
    val isDefault: Boolean = false,
    val isForced: Boolean = false,
    val codec: String = "vtt",
    val path: String? = null
)

@Entity(tableName = "chapter")
data class ChapterEntity(
    @PrimaryKey val id: String,
    val itemId: String,
    val startTicks: Long,
    val name: String,
    val imageTag: String? = null
)

@Entity(tableName = "collection")
data class CollectionEntity(
    @PrimaryKey val id: String,
    val name: String,
    val overview: String? = null
)

@Entity(tableName = "collection_item", primaryKeys = ["collectionId", "itemId"])
data class CollectionItemEntity(
    val collectionId: String,
    val itemId: String
)

@Entity(tableName = "genre")
data class GenreEntity(
    @PrimaryKey val id: String,
    val name: String
)

@Entity(tableName = "genre_item", primaryKeys = ["genreId", "itemId"])
data class GenreItemEntity(
    val genreId: String,
    val itemId: String
)

@Entity(tableName = "person")
data class PersonEntity(
    @PrimaryKey val id: String,
    val name: String,
    val imageTag: String? = null
)

@Entity(tableName = "person_credit", primaryKeys = ["personId", "itemId", "type"])
data class PersonCreditEntity(
    val personId: String,
    val itemId: String,
    val role: String? = null,
    val type: String = "Actor"
)

@Entity(tableName = "user")
data class UserEntity(
    @PrimaryKey val id: String,
    val name: String,
    val isAdmin: Boolean = true,
    val avatarTag: String? = null
)

@Entity(tableName = "home_section")
data class HomeSectionEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val sectionType: String,
    val position: Int,
    val isVisible: Boolean = true,
    val cardShapeOverride: String? = null
)

@Entity(tableName = "progress")
data class ProgressEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val itemId: String,
    val playbackPositionTicks: Long = 0L,
    val playedPercentage: Float = 0f,
    val isPlayed: Boolean = false,
    val isFavorite: Boolean = false,
    val lastPlayedDate: Long = System.currentTimeMillis()
)

@Entity(tableName = "device")
data class DeviceEntity(
    @PrimaryKey val id: String,
    val deviceName: String,
    val ipAddress: String,
    val port: Int = 8471,
    val lastSeenMs: Long = System.currentTimeMillis(),
    val isConnected: Boolean = false,
    val clientVersion: String = "1.0.0",
    val role: String = "tv",
    val model: String = "Android TV"
)

@Entity(tableName = "device_setting", primaryKeys = ["deviceId", "key"])
data class DeviceSettingEntity(
    val deviceId: String,
    val key: String,
    val value: String
)

@Entity(tableName = "api_token")
data class ApiTokenEntity(
    @PrimaryKey val id: String,
    val tokenHash: String,
    val deviceId: String,
    val userId: String,
    val createdAtMs: Long = System.currentTimeMillis(),
    val revokedAtMs: Long? = null
)

@Entity(tableName = "scan_cursor")
data class ScanCursorEntity(
    @PrimaryKey val id: String,
    val folderUri: String,
    val lastScannedPath: String? = null,
    val scannedCount: Int = 0,
    val isCompleted: Boolean = false
)

@Entity(tableName = "setting")
data class SettingEntity(
    @PrimaryKey val key: String,
    val value: String,
    val configRevision: Int = 0
)
