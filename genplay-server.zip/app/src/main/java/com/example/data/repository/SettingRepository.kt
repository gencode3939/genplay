package com.example.data.repository

import com.example.data.db.GenPlayDatabase
import com.example.data.db.SettingEntity
import com.example.model.SettingSchema
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class SettingRepository(private val db: GenPlayDatabase) {
    val allSettings: Flow<Map<String, String>> = db.settingDao().getAllSettings().map { list ->
        val map = list.associate { it.key to it.value }.toMutableMap()
        // Fill defaults for unconfigured settings
        SettingSchema.ALL.forEach { def ->
            if (!map.containsKey(def.key)) {
                map[def.key] = def.defaultValue.toString()
            }
        }
        map
    }

    suspend fun getSettingValue(key: String): String {
        val entity = db.settingDao().getSetting(key)
        if (entity != null) return entity.value
        val def = SettingSchema.find(key)
        return def?.defaultValue?.toString() ?: ""
    }

    suspend fun updateSetting(key: String, value: String): Int {
        val currentRev = db.settingDao().getMaxRevision() ?: 0
        val newRev = currentRev + 1
        db.settingDao().insertSetting(SettingEntity(key = key, value = value, configRevision = newRev))
        return newRev
    }

    suspend fun getCurrentRevision(): Int {
        return db.settingDao().getMaxRevision() ?: 0
    }
}
