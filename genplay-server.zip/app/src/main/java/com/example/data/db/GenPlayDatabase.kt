package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        LibraryFolderEntity::class,
        MediaItemEntity::class,
        MediaImageEntity::class,
        SubtitleTrackEntity::class,
        ChapterEntity::class,
        CollectionEntity::class,
        CollectionItemEntity::class,
        GenreEntity::class,
        GenreItemEntity::class,
        PersonEntity::class,
        PersonCreditEntity::class,
        UserEntity::class,
        HomeSectionEntity::class,
        ProgressEntity::class,
        DeviceEntity::class,
        DeviceSettingEntity::class,
        ApiTokenEntity::class,
        ScanCursorEntity::class,
        SettingEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class GenPlayDatabase : RoomDatabase() {
    abstract fun libraryFolderDao(): LibraryFolderDao
    abstract fun mediaItemDao(): MediaItemDao
    abstract fun deviceDao(): DeviceDao
    abstract fun apiTokenDao(): ApiTokenDao
    abstract fun settingDao(): SettingDao
    abstract fun progressDao(): ProgressDao
    abstract fun homeSectionDao(): HomeSectionDao

    companion object {
        @Volatile
        private var INSTANCE: GenPlayDatabase? = null

        fun getInstance(context: Context): GenPlayDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GenPlayDatabase::class.java,
                    "genplay_server.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
