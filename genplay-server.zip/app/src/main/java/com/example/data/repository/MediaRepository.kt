package com.example.data.repository

import com.example.data.db.*
import com.example.model.MediaItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class MediaRepository(private val db: GenPlayDatabase) {
    val allFolders: Flow<List<LibraryFolderEntity>> = db.libraryFolderDao().getAllFolders()
    val totalItemCount: Flow<Int> = db.mediaItemDao().getItemCountFlow()
    val latestItems: Flow<List<MediaItemEntity>> = db.mediaItemDao().getLatestItems(20)

    suspend fun getLatestItemsList(limit: Int = 50): List<MediaItemEntity> {
        return db.mediaItemDao().getLatestItemsList(limit)
    }

    suspend fun addFolder(folder: LibraryFolderEntity) {
        db.libraryFolderDao().insertFolder(folder)
    }

    suspend fun removeFolder(folder: LibraryFolderEntity) {
        db.libraryFolderDao().deleteFolder(folder)
    }

    fun getItemsByParent(parentId: String?): Flow<List<MediaItemEntity>> {
        return db.mediaItemDao().getItemsByParent(parentId)
    }

    suspend fun getItemById(id: String): MediaItemEntity? {
        return db.mediaItemDao().getItemById(id)
    }

    fun searchItems(query: String): Flow<List<MediaItemEntity>> {
        return db.mediaItemDao().searchItems(query)
    }

    suspend fun saveMediaItems(items: List<MediaItemEntity>) {
        db.mediaItemDao().insertItems(items)
    }

    fun getResumePoints(userId: String = "admin"): Flow<List<ProgressEntity>> {
        return db.progressDao().getResumeItems(userId)
    }

    suspend fun getProgress(itemId: String, userId: String = "admin"): ProgressEntity? {
        return db.progressDao().getProgress(userId, itemId)
    }

    suspend fun updateProgress(progress: ProgressEntity) {
        db.progressDao().insertProgress(progress)
    }

    fun getHomeSections(userId: String): Flow<List<HomeSectionEntity>> {
        return db.homeSectionDao().getHomeSections(userId)
    }

    suspend fun saveHomeSections(sections: List<HomeSectionEntity>) {
        db.homeSectionDao().insertSections(sections)
    }
}
