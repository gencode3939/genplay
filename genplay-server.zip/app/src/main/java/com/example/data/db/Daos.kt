package com.example.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface LibraryFolderDao {
    @Query("SELECT * FROM library_folder ORDER BY dateAdded DESC")
    fun getAllFolders(): Flow<List<LibraryFolderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFolder(folder: LibraryFolderEntity)

    @Delete
    suspend fun deleteFolder(folder: LibraryFolderEntity)
}

@Dao
interface MediaItemDao {
    @Query("SELECT * FROM media_item WHERE parentId IS :parentId ORDER BY sortName ASC")
    fun getItemsByParent(parentId: String?): Flow<List<MediaItemEntity>>

    @Query("SELECT * FROM media_item WHERE id = :id LIMIT 1")
    suspend fun getItemById(id: String): MediaItemEntity?

    @Query("SELECT * FROM media_item WHERE id = :id LIMIT 1")
    fun getItemFlowById(id: String): Flow<MediaItemEntity?>

    @Query("SELECT * FROM media_item WHERE isFolder = 0 ORDER BY dateCreated DESC LIMIT :limit")
    fun getLatestItems(limit: Int = 20): Flow<List<MediaItemEntity>>

    @Query("SELECT * FROM media_item WHERE isFolder = 0 ORDER BY dateCreated DESC LIMIT :limit")
    suspend fun getLatestItemsList(limit: Int = 50): List<MediaItemEntity>

    @Query("SELECT * FROM media_item WHERE name LIKE '%' || :query || '%' OR sortName LIKE '%' || :query || '%' LIMIT 50")
    fun searchItems(query: String): Flow<List<MediaItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: MediaItemEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItems(items: List<MediaItemEntity>)

    @Query("DELETE FROM media_item WHERE path = :path")
    suspend fun deleteByPath(path: String)

    @Query("SELECT COUNT(*) FROM media_item")
    fun getItemCountFlow(): Flow<Int>
}

@Dao
interface DeviceDao {
    @Query("SELECT * FROM device ORDER BY lastSeenMs DESC")
    fun getAllDevices(): Flow<List<DeviceEntity>>

    @Query("SELECT * FROM device WHERE id = :id LIMIT 1")
    suspend fun getDeviceById(id: String): DeviceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDevice(device: DeviceEntity)

    @Query("DELETE FROM device WHERE id = :id")
    suspend fun deleteDeviceById(id: String)
}

@Dao
interface ApiTokenDao {
    @Query("SELECT * FROM api_token WHERE tokenHash = :hash AND revokedAtMs IS NULL LIMIT 1")
    suspend fun findValidTokenByHash(hash: String): ApiTokenEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertToken(token: ApiTokenEntity)

    @Query("UPDATE api_token SET revokedAtMs = :revokedAt WHERE deviceId = :deviceId")
    suspend fun revokeTokenForDevice(deviceId: String, revokedAt: Long = System.currentTimeMillis())
}

@Dao
interface SettingDao {
    @Query("SELECT * FROM setting")
    fun getAllSettings(): Flow<List<SettingEntity>>

    @Query("SELECT * FROM setting WHERE `key` = :key LIMIT 1")
    suspend fun getSetting(key: String): SettingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSetting(setting: SettingEntity)

    @Query("SELECT MAX(configRevision) FROM setting")
    suspend fun getMaxRevision(): Int?
}

@Dao
interface ProgressDao {
    @Query("SELECT * FROM progress WHERE userId = :userId AND playedPercentage > 0 AND isPlayed = 0 ORDER BY lastPlayedDate DESC")
    fun getResumeItems(userId: String): Flow<List<ProgressEntity>>

    @Query("SELECT * FROM progress WHERE userId = :userId AND itemId = :itemId LIMIT 1")
    suspend fun getProgress(userId: String, itemId: String): ProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProgress(progress: ProgressEntity)
}

@Dao
interface HomeSectionDao {
    @Query("SELECT * FROM home_section WHERE userId = :userId ORDER BY position ASC")
    fun getHomeSections(userId: String): Flow<List<HomeSectionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSections(sections: List<HomeSectionEntity>)

    @Query("DELETE FROM home_section WHERE id = :id")
    suspend fun deleteSection(id: String)
}
