package com.example.server

import android.content.Context
import android.net.Uri
import com.example.data.db.ApiTokenEntity
import com.example.data.db.DeviceEntity
import com.example.data.repository.DeviceRepository
import com.example.data.repository.MediaRepository
import com.example.data.repository.SettingRepository
import com.example.security.AuthManager
import com.example.security.CryptoManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.firstOrNull
import java.io.*
import java.net.ServerSocket
import java.net.Socket
import java.nio.channels.FileChannel

data class ActiveSessionInfo(
    val deviceId: String,
    val deviceName: String,
    val userName: String,
    val nowPlayingTitle: String,
    val isPaused: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L
)

class GenPlayHttpServer(
    private val context: Context,
    private val mediaRepository: MediaRepository,
    private val deviceRepository: DeviceRepository,
    private val settingRepository: SettingRepository
) {
    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning

    private val _activeSessions = MutableStateFlow<List<ActiveSessionInfo>>(emptyList())
    val activeSessions: StateFlow<List<ActiveSessionInfo>> = _activeSessions

    private var activeStreamCount = 0
    private val activeChallenges = mutableMapOf<String, Long>()
    private val pendingBeams = java.util.concurrent.ConcurrentHashMap<String, BeamPayload>()

    fun startServer(port: Int = 8471) {
        if (_isRunning.value) return
        _isRunning.value = true

        serverJob = scope.launch {
            try {
                serverSocket = ServerSocket(port)
                while (isActive) {
                    val socket = serverSocket?.accept() ?: break
                    launch {
                        handleConnection(socket)
                    }
                }
            } catch (_: Exception) {
            } finally {
                _isRunning.value = false
            }
        }
    }

    fun stopServer() {
        _isRunning.value = false
        serverJob?.cancel()
        try {
            serverSocket?.close()
        } catch (_: Exception) {}
        serverSocket = null
    }

    private suspend fun handleConnection(socket: Socket) = withContext(Dispatchers.IO) {
        try {
            val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
            val outputStream = socket.getOutputStream()

            val requestLine = reader.readLine() ?: return@withContext
            val parts = requestLine.split(" ")
            if (parts.size < 2) return@withContext

            val method = parts[0]
            val fullUrl = parts[1]
            val path = fullUrl.substringBefore('?')

            val headers = mutableMapOf<String, String>()
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                if (line.isNullOrBlank()) break
                val currentLine = line!!
                val headerParts = currentLine.split(":", limit = 2)
                if (headerParts.size == 2) {
                    headers[headerParts[0].trim().lowercase()] = headerParts[1].trim()
                }
            }

            if (method == "OPTIONS") {
                handleOptions(outputStream)
                return@withContext
            }

            val clientIp = socket.inetAddress?.hostAddress ?: "127.0.0.1"
            val userAgent = headers["user-agent"] ?: "GenPlay İstemci"

            // Route handler
            when {
                path == "/" || path == "/index.html" -> {
                    registerConnectedDevice(clientIp, userAgent)
                    handleWebIndex(outputStream)
                }
                path == "/api/v1/ping" -> {
                    registerConnectedDevice(clientIp, userAgent)
                    handlePing(outputStream)
                }
                path == "/api/v1/health" -> handleHealth(outputStream)
                path == "/api/v1/info" -> handleInfo(outputStream)
                path == "/api/v1/pair/challenge" && method == "POST" -> handlePairChallenge(outputStream)
                path == "/api/v1/pair/confirm" && method == "POST" -> handlePairConfirm(reader, outputStream)
                path.startsWith("/api/v1/media/") && path.endsWith("/stream") -> {
                    registerConnectedDevice(clientIp, userAgent)
                    handleMediaStream(method, path, headers, clientIp, userAgent, outputStream)
                }
                path == "/api/v1/items" -> handleGetItems(outputStream)
                path == "/api/v1/sessions" -> handleGetSessions(outputStream)
                path == "/api/v1/sessions/progress" && method == "GET" -> handleGetProgress(fullUrl, outputStream)
                path == "/api/v1/sessions/progress" && method == "POST" -> handlePostProgress(reader, headers, outputStream)
                path == "/api/v1/beam" && method == "POST" -> handleBeamPost(reader, headers, outputStream)
                path.startsWith("/api/v1/beam/poll") -> handleBeamPoll(fullUrl, outputStream)
                path == "/api/v1/ws" -> handleWebSocketHandshake(headers, outputStream)
                else -> sendJsonResponse(outputStream, 200, """{"status":"ok","api":1,"message":"GenPlay Server Active"}""")
            }
        } catch (_: Exception) {
        } finally {
            try { socket.close() } catch (_: Exception) {}
        }
    }

    private fun handleHealth(outputStream: OutputStream) {
        val json = """{"status":"ok","version":"2.0.0","api":1,"uptimeSeconds":3600,"pairingRequired":true}"""
        sendJsonResponse(outputStream, 200, json)
    }

    private fun handleInfo(outputStream: OutputStream) {
        val json = """{"serverName":"GenPlay Server","version":"2.0.0","capabilities":["sections","sessions","progress","settings"]}"""
        sendJsonResponse(outputStream, 200, json)
    }

    private fun handlePairChallenge(outputStream: OutputStream) {
        val challenge = AuthManager.generateChallenge()
        val expiresAt = System.currentTimeMillis() + 15000
        activeChallenges[challenge] = expiresAt

        val json = """{"challenge":"$challenge","expiresIn":15,"serverName":"GenPlay Server"}"""
        sendJsonResponse(outputStream, 200, json)
    }

    private suspend fun handlePairConfirm(reader: BufferedReader, outputStream: OutputStream) {
        val token = AuthManager.generateRandomToken()
        val tokenHash = AuthManager.hashToken(token)

        val deviceId = "tv_${System.currentTimeMillis()}"
        val deviceEntity = DeviceEntity(
            id = deviceId,
            deviceName = "Android TV İstemcisi",
            ipAddress = "192.168.1.100",
            isConnected = true
        )
        deviceRepository.addOrUpdateDevice(deviceEntity)

        val tokenEntity = ApiTokenEntity(
            id = "tok_${System.currentTimeMillis()}",
            tokenHash = tokenHash,
            deviceId = deviceId,
            userId = "admin"
        )
        deviceRepository.saveToken(tokenEntity)

        val json = """{"token":"$token","userId":"admin","deviceId":"$deviceId","expiresAt":null}"""
        sendJsonResponse(outputStream, 200, json)
    }

    private suspend fun registerConnectedDevice(clientIp: String, userAgent: String) {
        withContext(Dispatchers.IO) {
            try {
                val isTv = userAgent.contains("TV", ignoreCase = true) || userAgent.contains("BRAVIA", ignoreCase = true) || userAgent.contains("AFT", ignoreCase = true)
                val deviceName = if (isTv) "Android TV ($clientIp)" else if (userAgent.contains("Mozilla")) "Web Tarayıcı ($clientIp)" else "GenPlay Cihaz ($clientIp)"
                val deviceId = "dev_" + clientIp.replace(".", "_")
                val entity = DeviceEntity(
                    id = deviceId,
                    deviceName = deviceName,
                    ipAddress = clientIp,
                    port = 8471,
                    lastSeenMs = System.currentTimeMillis(),
                    isConnected = true,
                    clientVersion = "2.0.0",
                    role = if (isTv) "tv" else "web",
                    model = if (isTv) "Android TV" else "Web Tarayıcı"
                )
                deviceRepository.addOrUpdateDevice(entity)
            } catch (_: Exception) {}
        }
    }

    private fun updateSession(clientIp: String, mediaName: String, isPaused: Boolean) {
        scope.launch(Dispatchers.IO) {
            try {
                val deviceId = "dev_" + clientIp.replace(".", "_")
                val existing = deviceRepository.getDeviceById(deviceId)
                if (existing != null) {
                    deviceRepository.addOrUpdateDevice(
                        existing.copy(
                            lastSeenMs = System.currentTimeMillis(),
                            isConnected = !isPaused
                        )
                    )
                }
            } catch (_: Exception) {}
        }
    }

    private suspend fun handleMediaStream(
        method: String,
        path: String,
        headers: Map<String, String>,
        clientIp: String,
        userAgent: String,
        outputStream: OutputStream
    ) {
        if (activeStreamCount >= 8) {
            sendJsonResponse(outputStream, 503, """{"code":"TOO_MANY_STREAMS","message":"Eşzamanlı akış sınırı doldu","retryAfter":10}""")
            return
        }

        val itemId = path.substringAfter("/api/v1/media/").substringBefore("/stream")
        val item = mediaRepository.getItemById(itemId)
        if (item == null || item.path == null) {
            sendJsonResponse(outputStream, 404, """{"code":"NOT_FOUND","message":"Medya öğesi bulunamadı"}""")
            return
        }

        if (item.hasDrm) {
            sendJsonResponse(outputStream, 451, """{"code":"DRM_DETECTED","message":"Bu içerik DRM korumalı ve GenPlay tarafından oynatılamaz."}""")
            return
        }

        activeStreamCount++
        updateSession(clientIp, item.name, isPaused = false)

        try {
            val uri = Uri.parse(item.path)
            val pfd = context.contentResolver.openFileDescriptor(uri, "r")
            if (pfd == null) {
                sendJsonResponse(outputStream, 404, """{"code":"NOT_FOUND","message":"Dosya açılamadı"}""")
                return
            }

            val fileLength = pfd.statSize
            val rangeHeader = headers["range"]

            var start = 0L
            var end = fileLength - 1

            var isPartial = false
            if (rangeHeader != null && rangeHeader.startsWith("bytes=")) {
                val rangeValue = rangeHeader.substringAfter("bytes=").trim()
                val parts = rangeValue.split("-")
                start = parts[0].toLongOrNull() ?: 0L
                if (parts.size > 1 && parts[1].isNotEmpty()) {
                    end = parts[1].toLong()
                }
                isPartial = true
            }

            if (start >= fileLength) {
                val response = "HTTP/1.1 416 Range Not Satisfiable\r\nContent-Range: bytes */$fileLength\r\nAccess-Control-Allow-Origin: *\r\n\r\n"
                outputStream.write(response.toByteArray(Charsets.UTF_8))
                outputStream.flush()
                pfd.close()
                return
            }

            val contentLength = end - start + 1
            val statusCode = if (isPartial) 206 else 200
            val statusText = if (isPartial) "Partial Content" else "OK"

            val headerBuilder = StringBuilder()
            headerBuilder.append("HTTP/1.1 $statusCode $statusText\r\n")
            headerBuilder.append("Content-Type: ${item.mimeType ?: "video/mp4"}\r\n")
            headerBuilder.append("Content-Length: $contentLength\r\n")
            headerBuilder.append("Accept-Ranges: bytes\r\n")
            headerBuilder.append("Access-Control-Allow-Origin: *\r\n")
            headerBuilder.append("Access-Control-Allow-Methods: GET, HEAD, OPTIONS\r\n")
            headerBuilder.append("Access-Control-Allow-Headers: Range, Content-Type\r\n")
            if (isPartial) {
                headerBuilder.append("Content-Range: bytes $start-$end/$fileLength\r\n")
            }
            headerBuilder.append("Connection: keep-alive\r\n\r\n")

            outputStream.write(headerBuilder.toString().toByteArray(Charsets.UTF_8))
            outputStream.flush()

            if (method != "HEAD") {
                val fileChannel = FileInputStream(pfd.fileDescriptor).channel
                val targetChannel = java.nio.channels.Channels.newChannel(outputStream)
                var position = start
                var remaining = contentLength

                // 256KB chunks for smooth buffering without CPU spiking
                while (remaining > 0) {
                    val count = Math.min(remaining, 256L * 1024L)
                    val transferred = fileChannel.transferTo(position, count, targetChannel)
                    if (transferred <= 0) break
                    position += transferred
                    remaining -= transferred
                }
                fileChannel.close()
            }
            pfd.close()
        } catch (_: Exception) {
        } finally {
            activeStreamCount = Math.max(0, activeStreamCount - 1)
            updateSession(clientIp, item.name, isPaused = true)
        }
    }

    private suspend fun handleGetItems(outputStream: OutputStream) {
        var itemsJson = "[]"
        try {
            val latest = withContext(Dispatchers.IO) {
                mediaRepository.getLatestItemsList(50)
            }
            if (latest.isNotEmpty()) {
                val array = org.json.JSONArray()
                for (item in latest) {
                    val obj = org.json.JSONObject().apply {
                        put("Id", item.id)
                        put("Name", item.name)
                        put("SortName", item.sortName)
                        put("Type", item.type)
                        put("MediaType", item.mediaType)
                        item.productionYear?.let { put("ProductionYear", it) }
                        item.runTimeTicks?.let { put("RunTimeTicks", it) }
                        put("Overview", item.overview ?: "")
                        put("DateCreated", item.dateCreated)
                    }
                    array.put(obj)
                }
                itemsJson = array.toString()
            }
        } catch (_: Exception) {}

        val json = """{"Items":$itemsJson,"TotalRecordCount":${if (itemsJson == "[]") 0 else 1},"StartIndex":0}"""
        sendJsonResponse(outputStream, 200, json)
    }

    private fun handleGetSessions(outputStream: OutputStream) {
        val sessionsList = _activeSessions.value
        val json = if (sessionsList.isEmpty()) {
            "[]"
        } else {
            sessionsList.joinToString(prefix = "[", postfix = "]") { s ->
                """{"deviceId":"${s.deviceId}","deviceName":"${s.deviceName}","userName":"${s.userName}","nowPlayingTitle":"${s.nowPlayingTitle}","isPaused":${s.isPaused}}"""
            }
        }
        sendJsonResponse(outputStream, 200, json)
    }

    private suspend fun handleGetProgress(fullUrl: String, outputStream: OutputStream) {
        val itemId = fullUrl.substringAfter("itemId=", "").substringBefore("&")
        val progress = if (itemId.isNotEmpty()) {
            mediaRepository.getProgress(itemId)
        } else null

        val json = if (progress != null) {
            """{"itemId":"${progress.itemId}","playbackPositionTicks":${progress.playbackPositionTicks},"playedPercentage":${progress.playedPercentage},"isPlayed":${progress.isPlayed}}"""
        } else {
            """{"itemId":"$itemId","playbackPositionTicks":0,"playedPercentage":0.0,"isPlayed":false}"""
        }
        sendJsonResponse(outputStream, 200, json)
    }

    private suspend fun handlePostProgress(reader: BufferedReader, headers: Map<String, String>, outputStream: OutputStream) {
        val contentLength = headers["content-length"]?.toIntOrNull() ?: 0
        val body = if (contentLength > 0) {
            val chars = CharArray(contentLength)
            var read = 0
            while (read < contentLength) {
                val r = reader.read(chars, read, contentLength - read)
                if (r <= 0) break
                read += r
            }
            String(chars, 0, read)
        } else ""

        if (body.isNotEmpty()) {
            try {
                val json = org.json.JSONObject(body)
                val itemId = json.optString("itemId")
                val positionTicks = json.optLong("playbackPositionTicks", 0L)
                val percentage = json.optDouble("playedPercentage", 0.0).toFloat()
                val isPlayed = json.optBoolean("isPlayed", percentage >= 0.9f)

                if (itemId.isNotEmpty()) {
                    val entity = com.example.data.db.ProgressEntity(
                        id = "prog_${itemId}_admin",
                        userId = "admin",
                        itemId = itemId,
                        playbackPositionTicks = positionTicks,
                        playedPercentage = percentage,
                        isPlayed = isPlayed,
                        lastPlayedDate = System.currentTimeMillis()
                    )
                    mediaRepository.updateProgress(entity)
                }
            } catch (_: Exception) {}
        }
        sendJsonResponse(outputStream, 200, """{"status":"ok","synced":true}""")
    }

    private fun handleBeamPost(reader: BufferedReader, headers: Map<String, String>, outputStream: OutputStream) {
        val contentLength = headers["content-length"]?.toIntOrNull() ?: 0
        val body = if (contentLength > 0) {
            val chars = CharArray(contentLength)
            var read = 0
            while (read < contentLength) {
                val r = reader.read(chars, read, contentLength - read)
                if (r <= 0) break
                read += r
            }
            String(chars, 0, read)
        } else ""

        if (body.isNotEmpty()) {
            try {
                val json = org.json.JSONObject(body)
                val targetDeviceId = json.optString("targetDeviceId")
                val itemId = json.optString("itemId")
                val positionMs = json.optLong("positionMs", 0L)
                val title = json.optString("title", "")

                if (targetDeviceId.isNotEmpty() && itemId.isNotEmpty()) {
                    val payload = BeamPayload(targetDeviceId, itemId, positionMs, title)
                    pendingBeams[targetDeviceId] = payload
                    // Broadcast to web as well if web client is target
                    pendingBeams["web_client"] = payload
                }
            } catch (_: Exception) {}
        }
        sendJsonResponse(outputStream, 200, """{"status":"ok","beamed":true}""")
    }

    private fun handleBeamPoll(fullUrl: String, outputStream: OutputStream) {
        val deviceId = fullUrl.substringAfter("deviceId=", "").substringBefore("&")
        val payload = if (deviceId.isNotEmpty()) pendingBeams.remove(deviceId) else pendingBeams.remove("web_client")

        val json = if (payload != null) {
            """{"hasBeam":true,"targetDeviceId":"${payload.deviceId}","itemId":"${payload.itemId}","positionMs":${payload.positionMs},"title":"${payload.title}"}"""
        } else {
            """{"hasBeam":false}"""
        }
        sendJsonResponse(outputStream, 200, json)
    }

    private fun handleWebSocketHandshake(headers: Map<String, String>, outputStream: OutputStream) {
        val key = headers["sec-websocket-key"] ?: return
        val acceptKey = AuthManager.computeHmac(key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11", "genplay".toByteArray())

        val handshakeResponse = "HTTP/1.1 101 Switching Protocols\r\n" +
                "Upgrade: websocket\r\n" +
                "Connection: Upgrade\r\n" +
                "Sec-WebSocket-Accept: $acceptKey\r\n\r\n"

        outputStream.write(handshakeResponse.toByteArray(Charsets.UTF_8))
        outputStream.flush()
    }

    private fun handleOptions(outputStream: OutputStream) {
        val response = "HTTP/1.1 204 No Content\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Access-Control-Allow-Methods: GET, POST, OPTIONS, HEAD\r\n" +
                "Access-Control-Allow-Headers: Content-Type, Authorization, Range, X-Requested-With\r\n" +
                "Access-Control-Max-Age: 86400\r\n" +
                "Connection: close\r\n\r\n"
        outputStream.write(response.toByteArray(Charsets.UTF_8))
        outputStream.flush()
    }

    private fun handlePing(outputStream: OutputStream) {
        val json = """{"status":"ok","serverName":"GenPlay Server","version":"2.0.0","time":${System.currentTimeMillis()}}"""
        sendJsonResponse(outputStream, 200, json)
    }

    private fun handleWebIndex(outputStream: OutputStream) {
        try {
            val html = context.assets.open("web/index.html").bufferedReader().use { it.readText() }
            val bytes = html.toByteArray(Charsets.UTF_8)
            val header = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: text/html; charset=utf-8\r\n" +
                    "Content-Length: ${bytes.size}\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Connection: close\r\n\r\n"
            outputStream.write(header.toByteArray(Charsets.UTF_8))
            outputStream.write(bytes)
            outputStream.flush()
        } catch (_: Exception) {
            sendJsonResponse(outputStream, 200, "<h1>GenPlay Server Online</h1>")
        }
    }

    private fun sendJsonResponse(outputStream: OutputStream, code: Int, json: String) {
        val statusText = when (code) {
            200 -> "OK"
            400 -> "Bad Request"
            401 -> "Unauthorized"
            403 -> "Forbidden"
            404 -> "Not Found"
            451 -> "Unavailable For Legal Reasons"
            503 -> "Service Unavailable"
            else -> "OK"
        }
        val bytes = json.toByteArray(Charsets.UTF_8)
        val header = "HTTP/1.1 $code $statusText\r\n" +
                "Content-Type: application/json; charset=utf-8\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Access-Control-Allow-Methods: GET, POST, OPTIONS, HEAD\r\n" +
                "Access-Control-Allow-Headers: Content-Type, Authorization, Range, X-Requested-With\r\n" +
                "Connection: close\r\n\r\n"
        outputStream.write(header.toByteArray(Charsets.UTF_8))
        outputStream.write(bytes)
        outputStream.flush()
    }
}

data class BeamPayload(
    val deviceId: String,
    val itemId: String,
    val positionMs: Long,
    val title: String
)
