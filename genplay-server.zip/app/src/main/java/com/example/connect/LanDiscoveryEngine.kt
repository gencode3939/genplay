package com.example.connect

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

data class DiscoveredServer(
    val host: String,
    val port: Int,
    val serverName: String,
    val version: String,
    val latencyMs: Long,
    val uptimeSeconds: Long
)

object LanDiscoveryEngine {

    suspend fun discoverServers(activeLocalIp: String, port: Int = 8471): List<DiscoveredServer> = withContext(Dispatchers.IO) {
        val targets = mutableSetOf<String>()

        // 1. Always check loopback & Android emulator hosts
        targets.add("127.0.0.1")
        targets.add("10.0.2.2")

        // 2. Check device's own active IP
        if (activeLocalIp.isNotEmpty() && activeLocalIp != "127.0.0.1") {
            targets.add(activeLocalIp)
        }

        // 3. Scan the actual active subnet (e.g. 192.168.1.X or 10.0.0.X or 192.168.43.X hotspot)
        val subnet = if (activeLocalIp.contains(".")) {
            activeLocalIp.substringBeforeLast(".") + "."
        } else {
            "192.168.1."
        }

        // Probe high-probability host addresses
        for (i in 1..40) {
            targets.add("$subnet$i")
        }

        // Parallel probe with low timeout
        val deferredPings = targets.map { ip ->
            async {
                pingAndFetchServer(ip, port, timeoutMs = 350)
            }
        }

        deferredPings.awaitAll().filterNotNull()
    }

    suspend fun pingAndFetchServer(host: String, port: Int, timeoutMs: Int = 800): DiscoveredServer? = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), timeoutMs)
            }
            val latency = (System.currentTimeMillis() - startTime).coerceAtLeast(1L)

            // Fast ping verification
            val url = URL("http://$host:$port/api/v1/ping")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = timeoutMs
                readTimeout = timeoutMs
                requestMethod = "GET"
            }

            if (conn.responseCode == 200) {
                val responseText = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(responseText)
                val status = json.optString("status", "")
                if (status == "ok") {
                    val serverName = json.optString("serverName", "GenPlay Sunucu ($host)")
                    val version = json.optString("version", "2.0.0")
                    return@withContext DiscoveredServer(
                        host = host,
                        port = port,
                        serverName = serverName,
                        version = version,
                        latencyMs = latency,
                        uptimeSeconds = 3600L
                    )
                }
            }
        } catch (_: Exception) {
            // Ignored, host unreachable
        }
        null
    }
}
