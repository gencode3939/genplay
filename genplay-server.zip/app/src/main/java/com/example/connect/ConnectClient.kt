package com.example.connect

import com.example.data.db.MediaItemEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

class ConnectClient(
    val serverHost: String,
    val serverPort: Int
) {
    var authToken: String? = null
        private set

    fun getStreamUrl(itemId: String): String {
        return "http://$serverHost:$serverPort/api/v1/media/$itemId/stream"
    }

    suspend fun pairWithServer(deviceName: String): Boolean = withContext(Dispatchers.IO) {
        try {
            // Step 1: Challenge
            val challengeUrl = URL("http://$serverHost:$serverPort/api/v1/pair/challenge")
            val cConn = (challengeUrl.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 3000
                readTimeout = 3000
                doOutput = true
            }
            cConn.outputStream.use { os ->
                os.write("""{"deviceName":"$deviceName","role":"connect"}""".toByteArray(Charsets.UTF_8))
            }
            if (cConn.responseCode != 200) return@withContext false
            val cJson = JSONObject(cConn.inputStream.bufferedReader().use { it.readText() })
            val challenge = cJson.optString("challenge")

            // Step 2: Confirm
            val confirmUrl = URL("http://$serverHost:$serverPort/api/v1/pair/confirm")
            val confConn = (confirmUrl.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 3000
                readTimeout = 3000
                doOutput = true
            }
            confConn.outputStream.use { os ->
                os.write("""{"challenge":"$challenge","deviceName":"$deviceName"}""".toByteArray(Charsets.UTF_8))
            }
            if (confConn.responseCode == 200) {
                val confJson = JSONObject(confConn.inputStream.bufferedReader().use { it.readText() })
                authToken = confJson.optString("token")
                return@withContext true
            }
        } catch (_: Exception) {}
        false
    }

    suspend fun fetchLibraryItems(): List<MediaItemEntity> = withContext(Dispatchers.IO) {
        val result = mutableListOf<MediaItemEntity>()
        try {
            val url = URL("http://$serverHost:$serverPort/api/v1/items")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 3000
                readTimeout = 3000
                if (authToken != null) {
                    setRequestProperty("Authorization", "Bearer $authToken")
                }
            }
            if (conn.responseCode == 200) {
                val jsonStr = conn.inputStream.bufferedReader().use { it.readText() }
                val rootObj = JSONObject(jsonStr)
                val itemsArr = rootObj.optJSONArray("Items") ?: JSONArray()
                for (i in 0 until itemsArr.length()) {
                    val obj = itemsArr.getJSONObject(i)
                    result.add(
                        MediaItemEntity(
                            id = obj.optString("Id", "item_$i"),
                            name = obj.optString("Name", "İçerik"),
                            sortName = obj.optString("SortName", "icerik"),
                            type = obj.optString("Type", "Movie"),
                            mediaType = obj.optString("MediaType", "Video"),
                            productionYear = if (obj.has("ProductionYear")) obj.optInt("ProductionYear") else null,
                            runTimeTicks = if (obj.has("RunTimeTicks")) obj.optLong("RunTimeTicks") else null,
                            overview = obj.optString("Overview", null),
                            dateCreated = obj.optString("DateCreated", System.currentTimeMillis().toString()),
                            path = getStreamUrl(obj.optString("Id", "item_$i"))
                        )
                    )
                }
            }
        } catch (_: Exception) {}
        result
    }

    suspend fun fetchProgress(itemId: String): Long = withContext(Dispatchers.IO) {
        try {
            val url = URL("http://$serverHost:$serverPort/api/v1/sessions/progress?itemId=$itemId")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 3000
                readTimeout = 3000
            }
            if (conn.responseCode == 200) {
                val jsonStr = conn.inputStream.bufferedReader().use { it.readText() }
                val obj = JSONObject(jsonStr)
                val ticks = obj.optLong("playbackPositionTicks", 0L)
                return@withContext ticks / 10_000L // convert ticks to ms
            }
        } catch (_: Exception) {}
        0L
    }

    suspend fun syncProgress(itemId: String, positionMs: Long, durationMs: Long) = withContext(Dispatchers.IO) {
        try {
            val url = URL("http://$serverHost:$serverPort/api/v1/sessions/progress")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 3000
                readTimeout = 3000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
            val percentage = if (durationMs > 0) positionMs.toDouble() / durationMs.toDouble() else 0.0
            val ticks = positionMs * 10_000L
            val body = """{"itemId":"$itemId","playbackPositionTicks":$ticks,"playedPercentage":$percentage,"isPlayed":${percentage >= 0.9}}"""
            conn.outputStream.use { os ->
                os.write(body.toByteArray(Charsets.UTF_8))
            }
            conn.responseCode // execute
        } catch (_: Exception) {}
    }

    suspend fun beamToDevice(targetDeviceId: String, itemId: String, positionMs: Long, title: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val url = URL("http://$serverHost:$serverPort/api/v1/beam")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 3000
                readTimeout = 3000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
            val body = """{"targetDeviceId":"$targetDeviceId","itemId":"$itemId","positionMs":$positionMs,"title":"$title"}"""
            conn.outputStream.use { os -> os.write(body.toByteArray(Charsets.UTF_8)) }
            return@withContext conn.responseCode == 200
        } catch (_: Exception) { false }
    }

    suspend fun pollBeamCommand(deviceId: String): JSONObject? = withContext(Dispatchers.IO) {
        try {
            val url = URL("http://$serverHost:$serverPort/api/v1/beam/poll?deviceId=$deviceId")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 3000
                readTimeout = 3000
            }
            if (conn.responseCode == 200) {
                val jsonStr = conn.inputStream.bufferedReader().use { it.readText() }
                val obj = JSONObject(jsonStr)
                if (obj.optBoolean("hasBeam", false)) {
                    return@withContext obj
                }
            }
        } catch (_: Exception) {}
        null
    }
}
