package com.example.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.text.format.Formatter
import java.net.Inet4Address
import java.net.NetworkInterface

object NetworkUtils {

    fun getLocalIpAddress(context: Context): String {
        try {
            // First check Wi-Fi manager
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val wifiIp = wifiManager?.connectionInfo?.ipAddress ?: 0
            if (wifiIp != 0) {
                @Suppress("DEPRECATION")
                val ipString = Formatter.formatIpAddress(wifiIp)
                if (ipString != "0.0.0.0" && !ipString.startsWith("127.")) {
                    return ipString
                }
            }

            // Inspect network interfaces for active wlan or eth IPv4
            val interfaces = NetworkInterface.getNetworkInterfaces()
            var fallbackIp: String? = null

            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                if (!networkInterface.isUp || networkInterface.isLoopback) continue

                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (!address.isLoopbackAddress && address is Inet4Address) {
                        val hostAddress = address.hostAddress ?: continue
                        if (hostAddress.startsWith("192.168.") || hostAddress.startsWith("10.") || hostAddress.startsWith("172.")) {
                            return hostAddress
                        }
                        fallbackIp = hostAddress
                    }
                }
            }
            if (fallbackIp != null) return fallbackIp
        } catch (_: Exception) {}

        return "127.0.0.1"
    }

    fun buildServerUrl(context: Context, port: Int = 8471): String {
        val ip = getLocalIpAddress(context)
        return "http://$ip:$port"
    }

    fun copyToClipboard(context: Context, label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
    }

    fun shareServerAddress(context: Context, serverUrl: String) {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, "GenPlay Medya Sunucusu yayında:\n$serverUrl\nConnect istemcisinden bu adresi bağlayabilirsiniz.")
            type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, "Sunucu Adresini Paylaş")
        shareIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(shareIntent)
    }
}
