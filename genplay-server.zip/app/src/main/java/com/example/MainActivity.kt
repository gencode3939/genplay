package com.example

import android.app.UiModeManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.connect.ConnectClient
import com.example.data.db.GenPlayDatabase
import com.example.data.db.LibraryFolderEntity
import com.example.data.db.MediaItemEntity
import com.example.data.db.ProgressEntity
import com.example.data.repository.DeviceRepository
import com.example.data.repository.MediaRepository
import com.example.data.repository.SettingRepository
import com.example.scanner.SafMediaScanner
import com.example.service.GenPlayServerService
import com.example.ui.components.DesignSheet
import com.example.ui.components.DockTabItem
import com.example.ui.components.FloatingGlassDock
import com.example.ui.components.GenAirSheet
import com.example.ui.components.OnboardingSetupSheet
import com.example.ui.screens.*
import com.example.ui.theme.AppPalette
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.Dimens
import com.example.ui.theme.GenPlayTheme
import com.example.util.NetworkUtils
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class AppRole { SERVER, CONNECT }

class MainActivity : ComponentActivity() {

    private lateinit var db: GenPlayDatabase
    private lateinit var mediaRepo: MediaRepository
    private lateinit var deviceRepo: DeviceRepository
    private lateinit var settingRepo: SettingRepository
    private lateinit var scanner: SafMediaScanner

    private fun isTvMode(): Boolean {
        val uiModeManager = getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
        return uiModeManager?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        db = GenPlayDatabase.getInstance(this)
        mediaRepo = MediaRepository(db)
        deviceRepo = DeviceRepository(db)
        settingRepo = SettingRepository(db)
        scanner = SafMediaScanner(this, mediaRepo)

        val defaultRole = if (isTvMode()) AppRole.CONNECT else AppRole.SERVER

        setContent {
            var activeRole by remember { mutableStateOf(defaultRole) }
            var palette by remember { mutableStateOf(AppPalette.GENPLAY) }
            var themeMode by remember { mutableStateOf(AppThemeMode.DARK) }
            var showDesignSheet by remember { mutableStateOf(false) }
            var showRoleSheet by remember { mutableStateOf(false) }
            var showOnboardingSheet by remember { mutableStateOf(false) }
            var showGenAirSheet by remember { mutableStateOf(false) }
            var genAirCurrentPosMs by remember { mutableStateOf(0L) }

            val navController = rememberNavController()
            val coroutineScope = rememberCoroutineScope()

            val folders by mediaRepo.allFolders.collectAsStateWithLifecycle(initialValue = emptyList())
            val latestItems by mediaRepo.latestItems.collectAsStateWithLifecycle(initialValue = emptyList())
            val resumeItems by mediaRepo.getResumePoints("admin").collectAsStateWithLifecycle(initialValue = emptyList())
            val devices by deviceRepo.devices.collectAsStateWithLifecycle(initialValue = emptyList())
            val settingsMap by settingRepo.allSettings.collectAsStateWithLifecycle(initialValue = emptyMap())
            val scanProgress by scanner.progress.collectAsStateWithLifecycle()

            var isServerRunning by remember { mutableStateOf(false) }
            var dynamicServerUrl by remember { mutableStateOf(NetworkUtils.buildServerUrl(this@MainActivity, 8471)) }

            var searchQuery by remember { mutableStateOf("") }
            var searchResults by remember { mutableStateOf<List<MediaItemEntity>>(emptyList()) }
            var selectedDetailItem by remember { mutableStateOf<MediaItemEntity?>(null) }

            // Connect Mode state
            var connectedServerHost by remember { mutableStateOf<String?>(null) }
            var connectedServerPort by remember { mutableStateOf<Int?>(null) }
            var connectClient by remember { mutableStateOf<ConnectClient?>(null) }
            var remoteItems by remember { mutableStateOf<List<MediaItemEntity>>(emptyList()) }
            var isConnectLoading by remember { mutableStateOf(false) }

            // Video player state
            var playingItemId by remember { mutableStateOf<String?>(null) }
            var playingVideoUri by remember { mutableStateOf<String?>(null) }
            var playingVideoTitle by remember { mutableStateOf("") }
            var playingResumePosMs by remember { mutableStateOf(0L) }

            // Onboarding initial role check for non-TV mobile devices
            LaunchedEffect(Unit) {
                if (!isTvMode()) {
                    val configured = settingRepo.getSettingValue("app_role_configured")
                    if (configured.isBlank() || configured == "false") {
                        showOnboardingSheet = true
                    } else {
                        val savedRole = settingRepo.getSettingValue("app_role")
                        if (savedRole == "CONNECT") activeRole = AppRole.CONNECT
                        else if (savedRole == "SERVER") activeRole = AppRole.SERVER
                    }
                }
            }

            // Connect Mode Beam Listener (Auto-opens video beamed from phone)
            LaunchedEffect(connectClient) {
                val client = connectClient ?: return@LaunchedEffect
                val deviceId = "dev_" + NetworkUtils.getLocalIpAddress(this@MainActivity).replace(".", "_")
                while (true) {
                    val beam = client.pollBeamCommand(deviceId)
                    if (beam != null) {
                        val itemId = beam.optString("itemId")
                        val posMs = beam.optLong("positionMs", 0L)
                        val title = beam.optString("title", "Gen Air İçeriği")
                        if (itemId.isNotEmpty()) {
                            playingItemId = itemId
                            playingVideoUri = client.getStreamUrl(itemId)
                            playingVideoTitle = title
                            playingResumePosMs = posMs
                            navController.navigate("custom_player")
                        }
                    }
                    delay(2000)
                }
            }

            // SAF Folder Picker Launcher
            val safLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.OpenDocumentTree()
            ) { uri: Uri? ->
                if (uri != null) {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                    val folderName = uri.lastPathSegment?.substringAfterLast(':') ?: "Medya Klasörü"
                    val folderEntity = LibraryFolderEntity(
                        id = "folder_${System.currentTimeMillis()}",
                        treeUri = uri.toString(),
                        name = folderName
                    )
                    coroutineScope.launch {
                        mediaRepo.addFolder(folderEntity)
                        navController.navigate("scan_progress")
                        scanner.scanFolderTree(uri, folderEntity.id)
                    }
                }
            }

            GenPlayTheme(palette = palette, themeMode = themeMode) {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route ?: "home"

                Box(modifier = Modifier.fillMaxSize()) {
                    NavHost(
                        navController = navController,
                        startDestination = "home",
                        modifier = Modifier.fillMaxSize()
                    ) {
                        composable("home") {
                            if (activeRole == AppRole.SERVER) {
                                HomeScreen(
                                    isServerRunning = isServerRunning,
                                    serverAddress = dynamicServerUrl,
                                    deviceCount = devices.size,
                                    sessionCount = if (isServerRunning) 1 else 0,
                                    folders = folders,
                                    latestItems = latestItems,
                                    resumeItems = resumeItems,
                                    devices = devices,
                                    onToggleServer = {
                                        val serviceIntent = Intent(this@MainActivity, GenPlayServerService::class.java)
                                        if (isServerRunning) {
                                            serviceIntent.action = GenPlayServerService.ACTION_STOP
                                            startService(serviceIntent)
                                            isServerRunning = false
                                        } else {
                                            dynamicServerUrl = NetworkUtils.buildServerUrl(this@MainActivity, 8471)
                                            serviceIntent.action = GenPlayServerService.ACTION_START
                                            startService(serviceIntent)
                                            isServerRunning = true
                                        }
                                    },
                                    onCopyAddress = {
                                        NetworkUtils.copyToClipboard(this@MainActivity, "GenPlay Server", dynamicServerUrl)
                                        Toast.makeText(this@MainActivity, "Adres kopyalandı: $dynamicServerUrl", Toast.LENGTH_SHORT).show()
                                    },
                                    onShareAddress = {
                                        NetworkUtils.shareServerAddress(this@MainActivity, dynamicServerUrl)
                                    },
                                    onOpenSettings = { navController.navigate("settings") },
                                    onOpenPaletteSheet = { showDesignSheet = true },
                                    onOpenFolderSelect = { navController.navigate("folder_select") },
                                    onOpenScanScreen = { navController.navigate("scan_progress") },
                                    onOpenDevicesScreen = { navController.navigate("devices") },
                                    onOpenSearchScreen = { navController.navigate("search") },
                                    onOpenRoleSwitcher = { showRoleSheet = true },
                                    onItemClick = { itemId ->
                                        coroutineScope.launch {
                                            val item = mediaRepo.getItemById(itemId)
                                            selectedDetailItem = item
                                            if (item != null) {
                                                val progress = mediaRepo.getProgress(itemId)
                                                val startPos = if (progress != null && !progress.isPlayed) {
                                                    progress.playbackPositionTicks / 10_000L
                                                } else 0L

                                                playingItemId = item.id
                                                playingVideoUri = item.path
                                                playingVideoTitle = item.name
                                                playingResumePosMs = startPos
                                                navController.navigate("custom_player")
                                            }
                                        }
                                    }
                                )
                            } else {
                                ConnectHomeScreen(
                                    connectedServerHost = connectedServerHost,
                                    connectedServerPort = connectedServerPort,
                                    items = remoteItems.ifEmpty { latestItems },
                                    isLoading = isConnectLoading,
                                    onOpenDiscovery = { navController.navigate("discovery") },
                                    onOpenRoleSwitcher = { showRoleSheet = true },
                                    onOpenSettings = { navController.navigate("settings") },
                                    onOpenPaletteSheet = { showDesignSheet = true },
                                    onItemClick = { item ->
                                        coroutineScope.launch {
                                            val client = connectClient
                                            val remoteResumePos = client?.fetchProgress(item.id) ?: 0L
                                            playingItemId = item.id
                                            playingVideoUri = item.path
                                            playingVideoTitle = item.name
                                            playingResumePosMs = remoteResumePos
                                            navController.navigate("custom_player")
                                        }
                                    }
                                )
                            }
                        }

                        composable("discovery") {
                            ServerDiscoveryScreen(
                                currentHost = connectedServerHost,
                                onServerSelected = { host, port ->
                                    connectedServerHost = host
                                    connectedServerPort = port
                                    val client = ConnectClient(host, port)
                                    connectClient = client
                                    isConnectLoading = true
                                    coroutineScope.launch {
                                        client.pairWithServer("GenPlay Connect Cihazı")
                                        remoteItems = client.fetchLibraryItems()
                                        isConnectLoading = false
                                        navController.popBackStack()
                                    }
                                },
                                onBackClick = { navController.popBackStack() }
                            )
                        }

                        composable("libraries") {
                            LibraryListScreen(
                                items = latestItems,
                                totalCount = latestItems.size,
                                onItemClick = { itemId ->
                                    coroutineScope.launch {
                                        selectedDetailItem = mediaRepo.getItemById(itemId)
                                        navController.navigate("detail")
                                    }
                                }
                            )
                        }

                        composable("detail") {
                            LibraryDetailScreen(
                                item = selectedDetailItem,
                                onBackClick = { navController.popBackStack() },
                                onPlayClick = { itemId ->
                                    selectedDetailItem?.let { item ->
                                        coroutineScope.launch {
                                            val progress = mediaRepo.getProgress(item.id)
                                            val startPos = if (progress != null && !progress.isPlayed) {
                                                progress.playbackPositionTicks / 10_000L
                                            } else 0L

                                            playingItemId = item.id
                                            playingVideoUri = item.path
                                            playingVideoTitle = item.name
                                            playingResumePosMs = startPos
                                            navController.navigate("custom_player")
                                        }
                                    }
                                },
                                onGenAirClick = { itemId ->
                                    selectedDetailItem?.let { item ->
                                        coroutineScope.launch {
                                            val progress = mediaRepo.getProgress(item.id)
                                            val startPos = if (progress != null && !progress.isPlayed) {
                                                progress.playbackPositionTicks / 10_000L
                                            } else 0L

                                            playingItemId = item.id
                                            playingVideoUri = item.path
                                            playingVideoTitle = item.name
                                            genAirCurrentPosMs = startPos
                                            showGenAirSheet = true
                                        }
                                    }
                                }
                            )
                        }

                        composable("devices") {
                            DeviceListScreen(
                                devices = devices,
                                onRemoveDevice = { deviceId ->
                                    coroutineScope.launch { deviceRepo.removeDevice(deviceId) }
                                }
                            )
                        }

                        composable("settings") {
                            var revision by remember { mutableStateOf(0) }
                            LaunchedEffect(Unit) {
                                revision = settingRepo.getCurrentRevision()
                            }
                            SettingsScreen(
                                revision = revision,
                                onGroupClick = { groupId -> navController.navigate("settings_group/$groupId") }
                            )
                        }

                        composable("settings_group/{groupId}") { backStackEntry ->
                            val groupId = backStackEntry.arguments?.getString("groupId") ?: "look"
                            SettingGroupScreen(
                                groupId = groupId,
                                settingsMap = settingsMap,
                                onBackClick = { navController.popBackStack() },
                                onSettingChange = { key, value ->
                                    coroutineScope.launch {
                                        settingRepo.updateSetting(key, value.toString())
                                    }
                                }
                            )
                        }

                        composable("folder_select") {
                            FolderSelectScreen(
                                folders = folders,
                                onPickFolderClick = { safLauncher.launch(null) },
                                onStartScan = {
                                    if (folders.isNotEmpty()) {
                                        val firstFolder = folders.first()
                                        coroutineScope.launch {
                                            navController.navigate("scan_progress")
                                            scanner.scanFolderTree(Uri.parse(firstFolder.treeUri), firstFolder.id)
                                        }
                                    }
                                }
                            )
                        }

                        composable("scan_progress") {
                            ScanProgressScreen(
                                scanProgress = scanProgress,
                                onCancelScan = { scanner.cancelScan() },
                                onFinishScan = { navController.navigate("home") }
                            )
                        }

                        composable("custom_player") {
                            CustomPlayerScreen(
                                videoUriString = playingVideoUri,
                                videoTitle = playingVideoTitle,
                                initialPositionMs = playingResumePosMs,
                                onProgressUpdate = { positionMs, durationMs ->
                                    val currentId = playingItemId ?: return@CustomPlayerScreen
                                    coroutineScope.launch {
                                        val percentage = if (durationMs > 0) positionMs.toFloat() / durationMs.toFloat() else 0f
                                        val isFinished = percentage >= 0.90f
                                        val entity = ProgressEntity(
                                            id = "prog_${currentId}_admin",
                                            userId = "admin",
                                            itemId = currentId,
                                            playbackPositionTicks = positionMs * 10_000L,
                                            playedPercentage = percentage,
                                            isPlayed = isFinished,
                                            lastPlayedDate = System.currentTimeMillis()
                                        )
                                        mediaRepo.updateProgress(entity)

                                        // If connected to remote server, sync remotely too
                                        connectClient?.syncProgress(currentId, positionMs, durationMs)
                                    }
                                },
                                onGenAirClick = { posMs ->
                                    genAirCurrentPosMs = posMs
                                    showGenAirSheet = true
                                },
                                onBackClick = { navController.popBackStack() }
                            )
                        }

                        composable("search") {
                            SearchScreen(
                                searchResults = searchResults,
                                onQueryChange = { q ->
                                    searchQuery = q
                                    if (q.isNotEmpty()) {
                                        coroutineScope.launch {
                                            mediaRepo.searchItems(q).collect { results ->
                                                searchResults = results
                                            }
                                        }
                                    } else {
                                        searchResults = emptyList()
                                    }
                                },
                                onBackClick = { navController.popBackStack() },
                                onItemClick = { itemId ->
                                    coroutineScope.launch {
                                        val item = mediaRepo.getItemById(itemId)
                                        selectedDetailItem = item
                                        navController.navigate("detail")
                                    }
                                }
                            )
                        }
                    }

                    // Floating Glass Dock (Hidden when inside video player)
                    val showDock = currentRoute in listOf("home", "libraries", "devices", "settings")
                    if (showDock) {
                        val dockItems = if (activeRole == AppRole.SERVER) {
                            listOf(
                                DockTabItem("home", "Ana", Icons.Default.Home),
                                DockTabItem("libraries", "Kitaplık", Icons.Default.Folder),
                                DockTabItem("devices", "Cihazlar", Icons.Default.Tv),
                                DockTabItem("settings", "Ayarlar", Icons.Default.Settings)
                            )
                        } else {
                            listOf(
                                DockTabItem("home", "İzle", Icons.Default.Home),
                                DockTabItem("discovery", "Sunucu Bul", Icons.Default.Dns),
                                DockTabItem("settings", "Ayarlar", Icons.Default.Settings)
                            )
                        }

                        val isTv = isTvMode()
                        FloatingGlassDock(
                            items = dockItems,
                            selectedId = currentRoute,
                            isTvMode = isTv,
                            isVisible = true,
                            onItemSelected = { id ->
                                navController.navigate(id) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            modifier = Modifier.align(if (isTv) Alignment.TopCenter else Alignment.BottomCenter)
                        )
                    }

                    if (showDesignSheet) {
                        DesignSheet(
                            currentPalette = palette,
                            currentThemeMode = themeMode,
                            onPaletteSelect = { palette = it },
                            onThemeModeSelect = { themeMode = it },
                            onDismissRequest = { showDesignSheet = false }
                        )
                    }

                    // Role Switcher Modal
                    if (showRoleSheet) {
                        AlertDialog(
                            onDismissRequest = { showRoleSheet = false },
                            title = { Text("Çalışma Modu Seçin", fontWeight = FontWeight.Bold) },
                            text = {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Card(
                                        onClick = {
                                            activeRole = AppRole.SERVER
                                            showRoleSheet = false
                                        },
                                        shape = RoundedCornerShape(Dimens.RadiusMD),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (activeRole == AppRole.SERVER) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainer
                                        ),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Dns, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column {
                                                Text("Sunucu (Server)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                                Text("Medya dosyalarınızı ağda barındırın ve yayınlayın", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                    }

                                    Card(
                                        onClick = {
                                            activeRole = AppRole.CONNECT
                                            showRoleSheet = false
                                        },
                                        shape = RoundedCornerShape(Dimens.RadiusMD),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (activeRole == AppRole.CONNECT) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainer
                                        ),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Cast, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column {
                                                Text("Connect (İstemci / TV)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                                Text("Yerel ağdaki sunucuya bağlanıp doğrudan izleyin", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                    }
                                }
                            },
                            confirmButton = {
                                TextButton(onClick = { showRoleSheet = false }) { Text("Kapat") }
                            },
                            shape = RoundedCornerShape(Dimens.RadiusLG)
                        )
                    }

                    // First-run Onboarding Setup Wizard for mobile
                    if (showOnboardingSheet) {
                        OnboardingSetupSheet(
                            onRoleSelected = { role ->
                                activeRole = role
                                showOnboardingSheet = false
                                coroutineScope.launch {
                                    settingRepo.updateSetting("app_role", role.name)
                                    settingRepo.updateSetting("app_role_configured", "true")
                                }
                            },
                            onDismissRequest = { showOnboardingSheet = false }
                        )
                    }

                    // Gen Air Beam Sheet
                    if (showGenAirSheet) {
                        GenAirSheet(
                            devices = devices,
                            videoTitle = playingVideoTitle,
                            onDeviceSelected = { targetDevice ->
                                showGenAirSheet = false
                                val itemId = playingItemId ?: ""
                                coroutineScope.launch {
                                    val success = if (activeRole == AppRole.SERVER) {
                                        val client = ConnectClient("127.0.0.1", 8471)
                                        client.beamToDevice(targetDevice.id, itemId, genAirCurrentPosMs, playingVideoTitle)
                                    } else {
                                        connectClient?.beamToDevice(targetDevice.id, itemId, genAirCurrentPosMs, playingVideoTitle) ?: false
                                    }
                                    if (success) {
                                        Toast.makeText(this@MainActivity, "Gen Air ile ${targetDevice.deviceName} cihazına aktarıldı!", Toast.LENGTH_SHORT).show()
                                        navController.popBackStack()
                                    } else {
                                        Toast.makeText(this@MainActivity, "Aktarım başarısız. Cihazın bağlı olduğundan emin olun.", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            onDismissRequest = { showGenAirSheet = false }
                        )
                    }
                }
            }
        }
    }
}
