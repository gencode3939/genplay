package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.R
import com.example.data.db.GenPlayDatabase
import com.example.data.repository.DeviceRepository
import com.example.data.repository.MediaRepository
import com.example.data.repository.SettingRepository
import com.example.server.GenPlayHttpServer

class GenPlayServerService : Service() {
    companion object {
        const val CHANNEL_ID = "GenPlayServerChannel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START = "com.example.action.START_SERVER"
        const val ACTION_STOP = "com.example.action.STOP_SERVER"

        var serverInstance: GenPlayHttpServer? = null
            private set
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        val db = GenPlayDatabase.getInstance(this)
        val mediaRepo = MediaRepository(db)
        val deviceRepo = DeviceRepository(db)
        val settingRepo = SettingRepository(db)

        serverInstance = GenPlayHttpServer(this, mediaRepo, deviceRepo, settingRepo)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                serverInstance?.stopServer()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            else -> {
                startForeground(NOTIFICATION_ID, buildNotification())
                serverInstance?.startServer(8471)
            }
        }
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("GenPlay Server Açık")
            .setContentText("Yerel ağda HTTP & WebSocket yayını yapılıyor (Port 8471)")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "GenPlay Server Arka Plan Servisi",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "GenPlay Server yayın bildirim kanalı"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        serverInstance?.stopServer()
        serverInstance = null
        super.onDestroy()
    }
}
