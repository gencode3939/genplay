@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.media3.common.util.UnstableApi::class
)

package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.ui.components.OsdPlayerControls
import com.example.ui.theme.Dimens
import kotlinx.coroutines.delay

@Composable
fun CustomPlayerScreen(
    videoUriString: String?,
    videoTitle: String,
    initialPositionMs: Long = 0L,
    onProgressUpdate: ((positionMs: Long, durationMs: Long) -> Unit)? = null,
    onGenAirClick: ((currentPosMs: Long) -> Unit)? = null,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity

    // Immersive Mode
    DisposableEffect(Unit) {
        activity?.let { act ->
            val window = act.window
            val insetsController = WindowCompat.getInsetsController(window, window.decorView)
            insetsController.hide(WindowInsetsCompat.Type.systemBars())
            insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        onDispose {
            activity?.let { act ->
                val window = act.window
                val insetsController = WindowCompat.getInsetsController(window, window.decorView)
                insetsController.show(WindowInsetsCompat.Type.systemBars())
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }

    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }

    var currentVolume by remember { mutableStateOf(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)) }
    var currentBrightness by remember {
        val window = (context as? Activity)?.window
        val cur = window?.attributes?.screenBrightness ?: 0.5f
        mutableStateOf(if (cur < 0) 0.5f else cur)
    }

    var gestureIndicatorText by remember { mutableStateOf<String?>(null) }
    var gestureIndicatorIcon by remember { mutableStateOf<androidx.compose.ui.graphics.vector.ImageVector?>(null) }

    var isPlaying by remember { mutableStateOf(false) }
    var currentPositionMs by remember { mutableStateOf(0L) }
    var durationMs by remember { mutableStateOf(0L) }
    var showOsd by remember { mutableStateOf(true) }

    val aspectModes = listOf(
        "Uyacak (Fit)" to AspectRatioFrameLayout.RESIZE_MODE_FIT,
        "Doldur (Crop)" to AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        "16:9" to AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH,
        "4:3" to AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
    )
    var currentAspectIndex by remember { mutableStateOf(0) }

    val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
    var currentSpeedIndex by remember { mutableStateOf(2) }

    var showTrackDialog by remember { mutableStateOf<String?>(null) }

    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            videoScalingMode = androidx.media3.common.C.VIDEO_SCALING_MODE_SCALE_TO_FIT
        }
    }

    DisposableEffect(videoUriString) {
        if (!videoUriString.isNullOrBlank()) {
            val mediaItem = MediaItem.fromUri(Uri.parse(videoUriString))
            exoPlayer.setMediaItem(mediaItem)
            // Pre-seek before prepare so decoder starts directly at the saved second!
            if (initialPositionMs > 0) {
                exoPlayer.seekTo(initialPositionMs)
                currentPositionMs = initialPositionMs
            }
            exoPlayer.prepare()
            exoPlayer.playWhenReady = true
        }

        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                if (!playing && exoPlayer.duration > 0) {
                    onProgressUpdate?.invoke(exoPlayer.currentPosition, exoPlayer.duration)
                }
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    durationMs = exoPlayer.duration.coerceAtLeast(0L)
                    currentPositionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
                }
            }
        }
        exoPlayer.addListener(listener)

        onDispose {
            if (exoPlayer.duration > 0) {
                onProgressUpdate?.invoke(exoPlayer.currentPosition, exoPlayer.duration)
            }
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    // Auto-hide OSD
    LaunchedEffect(showOsd, isPlaying) {
        if (showOsd && isPlaying) {
            delay(3500)
            showOsd = false
        }
    }

    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
            currentPositionMs = pos
            if (exoPlayer.duration > 0) {
                onProgressUpdate?.invoke(pos, exoPlayer.duration)
            }
            delay(1500)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { showOsd = !showOsd },
                    onDoubleTap = { offset ->
                        val screenWidth = size.width
                        if (offset.x < screenWidth / 2) {
                            // Seek back 10s
                            exoPlayer.seekTo((exoPlayer.currentPosition - 10000).coerceAtLeast(0))
                            gestureIndicatorText = "-10 sn"
                        } else {
                            // Seek forward 10s
                            exoPlayer.seekTo((exoPlayer.currentPosition + 10000).coerceAtMost(exoPlayer.duration))
                            gestureIndicatorText = "+10 sn"
                        }
                    }
                )
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset ->
                        val screenWidth = size.width
                        if (offset.x < screenWidth / 2) {
                            gestureIndicatorIcon = Icons.Default.BrightnessMedium
                        } else {
                            gestureIndicatorIcon = Icons.Default.VolumeUp
                        }
                    },
                    onDragEnd = {
                        gestureIndicatorText = null
                        gestureIndicatorIcon = null
                    },
                    onDragCancel = {
                        gestureIndicatorText = null
                        gestureIndicatorIcon = null
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val screenWidth = size.width
                        if (change.position.x < screenWidth / 2) {
                            // Left side: Brightness
                            val delta = -dragAmount.y / 600f
                            currentBrightness = (currentBrightness + delta).coerceIn(0.05f, 1f)
                            activity?.window?.let { win ->
                                val lp = win.attributes
                                lp.screenBrightness = currentBrightness
                                win.attributes = lp
                            }
                            gestureIndicatorText = "Parlaklık: %${(currentBrightness * 100).toInt()}"
                            gestureIndicatorIcon = Icons.Default.BrightnessMedium
                        } else {
                            // Right side: Volume
                            val delta = -dragAmount.y / 40f
                            val newVol = (currentVolume + delta.toInt()).coerceIn(0, maxVolume)
                            if (newVol != currentVolume) {
                                currentVolume = newVol
                                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, currentVolume, 0)
                            }
                            gestureIndicatorText = "Ses: %${((currentVolume.toFloat() / maxVolume) * 100).toInt()}"
                            gestureIndicatorIcon = Icons.Default.VolumeUp
                        }
                    }
                )
            }
    ) {
        if (!videoUriString.isNullOrBlank()) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = exoPlayer
                        useController = false
                        resizeMode = aspectModes[currentAspectIndex].second
                    }
                },
                update = { view ->
                    view.resizeMode = aspectModes[currentAspectIndex].second
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Medya URL'si bulunamadı.", color = Color.White)
            }
        }

        // Gesture feedback HUD
        if (gestureIndicatorText != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(Dimens.RadiusLG))
                    .background(Color.Black.copy(alpha = 0.8f))
                    .padding(horizontal = 24.dp, vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    gestureIndicatorIcon?.let { icon ->
                        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                    }
                    Text(
                        text = gestureIndicatorText ?: "",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Top App Bar
        AnimatedVisibility(
            visible = showOsd,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.65f))
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = videoTitle,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
                if (onGenAirClick != null) {
                    IconButton(
                        onClick = { onGenAirClick(currentPositionMs) }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Cast,
                            contentDescription = "Gen Air Aktar",
                            tint = com.example.ui.theme.SoftAccent
                        )
                    }
                }
            }
        }

        // Floating Glass Dock OSD
        AnimatedVisibility(
            visible = showOsd,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(Dimens.ScreenEdge)
        ) {
            OsdPlayerControls(
                title = videoTitle,
                isPlaying = isPlaying,
                currentPositionMs = currentPositionMs,
                durationMs = durationMs,
                aspectRatioName = aspectModes[currentAspectIndex].first,
                playbackSpeed = speeds[currentSpeedIndex],
                onPlayPauseToggle = {
                    if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                },
                onSkipBack = {
                    exoPlayer.seekTo((exoPlayer.currentPosition - 10000).coerceAtLeast(0))
                },
                onSkipForward = {
                    exoPlayer.seekTo((exoPlayer.currentPosition + 30000).coerceAtMost(exoPlayer.duration))
                },
                onSeek = { fraction ->
                    val targetMs = (durationMs * fraction).toLong()
                    exoPlayer.seekTo(targetMs)
                    currentPositionMs = targetMs
                },
                onToggleAspectRatio = {
                    currentAspectIndex = (currentAspectIndex + 1) % aspectModes.size
                },
                onCyclePlaybackSpeed = {
                    currentSpeedIndex = (currentSpeedIndex + 1) % speeds.size
                    exoPlayer.setPlaybackSpeed(speeds[currentSpeedIndex])
                },
                onOpenAudioTracks = { showTrackDialog = "audio" },
                onOpenSubtitleTracks = { showTrackDialog = "subtitle" },
                onGenAirClick = if (onGenAirClick != null) { { onGenAirClick(currentPositionMs) } } else null
            )
        }

        if (showTrackDialog != null) {
            AlertDialog(
                onDismissRequest = { showTrackDialog = null },
                title = { Text(if (showTrackDialog == "audio") "Ses Akışı" else "Altyazılar", fontWeight = FontWeight.Bold) },
                text = { Text("Otomatik Varsayılan Akış", style = MaterialTheme.typography.bodyMedium) },
                confirmButton = {
                    TextButton(onClick = { showTrackDialog = null }) { Text("Tamam") }
                },
                shape = RoundedCornerShape(Dimens.RadiusLG)
            )
        }
    }
}
