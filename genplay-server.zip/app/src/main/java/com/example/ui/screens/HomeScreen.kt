package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.db.DeviceEntity
import com.example.data.db.LibraryFolderEntity
import com.example.data.db.MediaItemEntity
import com.example.model.CardShape
import com.example.model.MediaItem
import com.example.ui.components.GenPlayCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusCard
import com.example.ui.theme.Dimens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    isServerRunning: Boolean,
    serverAddress: String,
    deviceCount: Int,
    sessionCount: Int,
    folders: List<LibraryFolderEntity>,
    latestItems: List<MediaItemEntity>,
    resumeItems: List<com.example.data.db.ProgressEntity> = emptyList(),
    devices: List<DeviceEntity>,
    onToggleServer: () -> Unit,
    onCopyAddress: () -> Unit,
    onShareAddress: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenPaletteSheet: () -> Unit,
    onOpenFolderSelect: () -> Unit,
    onOpenScanScreen: () -> Unit,
    onOpenDevicesScreen: () -> Unit,
    onOpenSearchScreen: () -> Unit,
    onOpenRoleSwitcher: () -> Unit,
    onItemClick: (String) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "GenPlay",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(Dimens.RadiusFull))
                                    .background(MaterialTheme.colorScheme.primaryContainer)
                                    .clickable { onOpenRoleSwitcher() }
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "Sunucu",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Text(
                            text = "Kontrol merkezi v2.0",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = onOpenSearchScreen,
                        modifier = Modifier.testTag("home_search_btn")
                    ) {
                        Icon(Icons.Default.Search, contentDescription = "Arama")
                    }
                    IconButton(
                        onClick = onOpenPaletteSheet,
                        modifier = Modifier.testTag("home_palette_btn")
                    ) {
                        Icon(Icons.Default.Palette, contentDescription = "Görünüm")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        }
    ) { innerPadding ->
        com.example.ui.theme.AmbientHaloBackground(
            modifier = Modifier.padding(innerPadding)
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = Dimens.FloatingDockHeight + 16.dp)
            ) {
            item {
                StatusCard(
                    isServerRunning = isServerRunning,
                    serverAddress = serverAddress,
                    deviceCount = deviceCount,
                    sessionCount = sessionCount,
                    onToggleServer = onToggleServer,
                    onCopyAddress = onCopyAddress,
                    onShareAddress = onShareAddress,
                    onSettingsClick = onOpenSettings
                )
            }

            item {
                Spacer(modifier = Modifier.height(Dimens.Spacing16))
                if (folders.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = Dimens.ScreenEdge)
                            .clip(RoundedCornerShape(Dimens.RadiusMD))
                            .background(MaterialTheme.colorScheme.surfaceContainer)
                            .padding(Dimens.Spacing16)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Info,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(Dimens.Spacing12))
                            Text(
                                text = "Kütüphane henüz taranmadı. Klasör seçilince otomatik başlar.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // Kütüphaneler Section
            item {
                SectionHeader(title = "Kütüphaneler", actionText = "Klasör Ekle →", onActionClick = onOpenFolderSelect)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = Dimens.ScreenEdge)
                        .clip(RoundedCornerShape(Dimens.RadiusLG))
                        .background(MaterialTheme.colorScheme.surfaceContainer)
                ) {
                    if (folders.isEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(onClick = onOpenFolderSelect)
                                .padding(Dimens.Spacing16),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Folder,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.width(Dimens.Spacing12))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Kütüphane eklenmedi",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Klasör seçimi yapmak için dokunun",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text("›", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        Column {
                            folders.forEach { folder ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable(onClick = onOpenFolderSelect)
                                        .padding(Dimens.Spacing16),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Folder, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(Dimens.Spacing12))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = folder.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        Text(text = "${folder.itemCount} öğe indekste", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // İzlemeye Devam Et (Kaldığın Yerden) Section
            if (resumeItems.isNotEmpty()) {
                item {
                    SectionHeader(title = "İzlemeye Devam Et")
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = Dimens.ScreenEdge),
                        horizontalArrangement = Arrangement.spacedBy(Dimens.Spacing12)
                    ) {
                        items(resumeItems) { prog ->
                            val itemMatch = latestItems.find { it.id == prog.itemId }
                            val model = MediaItem(
                                id = prog.itemId,
                                name = itemMatch?.name ?: "İzlenen Medya",
                                type = itemMatch?.type ?: "Movie",
                                productionYear = itemMatch?.productionYear
                            )
                            GenPlayCard(
                                item = model,
                                shape = CardShape.BACKDROP,
                                progressPercent = prog.playedPercentage,
                                badgeText = "%${(prog.playedPercentage * 100).toInt()}",
                                onClick = { onItemClick(prog.itemId) }
                            )
                        }
                    }
                }
            }

            // Son Eklenenler Section
            item {
                SectionHeader(title = "Son Eklenenler")
                if (latestItems.isEmpty()) {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = Dimens.ScreenEdge),
                        horizontalArrangement = Arrangement.spacedBy(Dimens.Spacing12)
                    ) {
                        items(4) {
                            GenPlayCard(item = null, shape = CardShape.PORTRAIT, isLoading = true)
                        }
                    }
                } else {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = Dimens.ScreenEdge),
                        horizontalArrangement = Arrangement.spacedBy(Dimens.Spacing12)
                    ) {
                        items(latestItems) { entity ->
                            val model = MediaItem(id = entity.id, name = entity.name, type = entity.type, productionYear = entity.productionYear)
                            GenPlayCard(item = model, shape = CardShape.PORTRAIT, onClick = { onItemClick(entity.id) })
                        }
                    }
                }
            }

            // Cihazlar Section
            item {
                SectionHeader(title = "Cihazlar", actionText = "Tümü →", onActionClick = onOpenDevicesScreen)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = Dimens.ScreenEdge)
                        .clip(RoundedCornerShape(Dimens.RadiusLG))
                        .background(MaterialTheme.colorScheme.surfaceContainer)
                        .padding(Dimens.Spacing16)
                ) {
                    if (devices.isEmpty()) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Tv, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Spacer(modifier = Modifier.height(Dimens.Spacing8))
                            Text(
                                text = "Bağlı TV cihazı yok",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "TV cihazınız aynı Wi-Fi ağından bağlandığında otomatik görünür.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        Column {
                            devices.forEach { dev ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Tv, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = dev.deviceName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        Text(text = dev.ipAddress, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
}
