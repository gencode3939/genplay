package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Seed Colors for Palettes
val GenPlaySeed = Color(0xFF5B8DEF)
val SinemaSeed = Color(0xFFC4553B)
val OrmanSeed = Color(0xFF2E7D5B)

// GenPlay Dark Colors
val GenPlayDarkPrimary = Color(0xFF8EB2FF)
val GenPlayDarkOnPrimary = Color(0xFF002B6F)
val GenPlayDarkPrimaryContainer = Color(0xFF284687)
val GenPlayDarkOnPrimaryContainer = Color(0xFFD8E2FF)
val GenPlayDarkSecondary = Color(0xFFC3C6CF)
val GenPlayDarkSurface = Color(0xFF0B101D)
val GenPlayDarkSurfaceLow = Color(0xFF131826)
val GenPlayDarkSurfaceContainer = Color(0xFF181F30)
val GenPlayDarkSurfaceHigh = Color(0xFF21293D)
val GenPlayDarkSurfaceHighest = Color(0xFF2D364D)
val GenPlayDarkOnSurface = Color(0xFFE2E2E9)
val GenPlayDarkOnSurfaceVariant = Color(0xFFA0A7B8)
val GenPlayDarkOutline = Color(0xFF6F7788)
val GenPlayDarkOutlineVariant = Color(0xFF2F374A)

// Sinema Dark Colors
val SinemaDarkPrimary = Color(0xFFFFB4A5)
val SinemaDarkOnPrimary = Color(0xFF5F1508)
val SinemaDarkPrimaryContainer = Color(0xFF812C1C)
val SinemaDarkOnPrimaryContainer = Color(0xFFFFDAD3)
val SinemaDarkSurface = Color(0xFF190C09)
val SinemaDarkSurfaceLow = Color(0xFF241410)
val SinemaDarkSurfaceContainer = Color(0xFF2D1B16)
val SinemaDarkSurfaceHigh = Color(0xFF382520)
val SinemaDarkSurfaceHighest = Color(0xFF45302B)
val SinemaDarkOnSurface = Color(0xFFF0DFDC)
val SinemaDarkOnSurfaceVariant = Color(0xFFD8C2BD)
val SinemaDarkOutline = Color(0xFFA08C87)
val SinemaDarkOutlineVariant = Color(0xFF3D2A26)

// Orman Dark Colors
val OrmanDarkPrimary = Color(0xFF88D9B0)
val OrmanDarkOnPrimary = Color(0xFF003822)
val OrmanDarkPrimaryContainer = Color(0xFF0D5135)
val OrmanDarkOnPrimaryContainer = Color(0xFFA4F5CC)
val OrmanDarkSurface = Color(0xFF0A130E)
val OrmanDarkSurfaceLow = Color(0xFF121C16)
val OrmanDarkSurfaceContainer = Color(0xFF1A261F)
val OrmanDarkSurfaceHigh = Color(0xFF233129)
val OrmanDarkSurfaceHighest = Color(0xFF2E3D34)
val OrmanDarkOnSurface = Color(0xFFDEE4DF)
val OrmanDarkOnSurfaceVariant = Color(0xFFBFC9C2)
val OrmanDarkOutline = Color(0xFF8A938C)
val OrmanDarkOutlineVariant = Color(0xFF28352D)

// Status Colors
val SuccessGreen = Color(0xFF34C759)
val ErrorRed = Color(0xFFFF453A)
val WarningOrange = Color(0xFFFF9F0A)
