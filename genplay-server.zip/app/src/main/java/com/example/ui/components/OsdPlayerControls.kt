@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.Forward30
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.Dimens
import com.example.ui.theme.SoftAccent

@Composable
fun OsdPlayerControls(
    title: String,
    isPlaying: Boolean,
    currentPositionMs: Long,
    durationMs: Long,
    aspectRatioName: String,
    playbackSpeed: Float,
    onPlayPauseToggle: () -> Unit,
    onSkipBack: () -> Unit,
    onSkipForward: () -> Unit,
    onSeek: (Float) -> Unit,
    onToggleAspectRatio: () -> Unit,
    onCyclePlaybackSpeed: () -> Unit,
    onOpenAudioTracks: () -> Unit,
    onOpenSubtitleTracks: () -> Unit,
    onGenAirClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Dimens.RadiusLG))
            .background(MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.94f))
            .padding(Dimens.Spacing16)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    // Aspect ratio chip
                    AssistChip(
                        onClick = onToggleAspectRatio,
                        label = { Text(aspectRatioName) },
                        leadingIcon = { Icon(Icons.Default.AspectRatio, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        modifier = Modifier.testTag("osd_aspect_chip")
                    )

                    // Speed chip
                    AssistChip(
                        onClick = onCyclePlaybackSpeed,
                        label = { Text("${playbackSpeed}x") },
                        leadingIcon = { Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        modifier = Modifier.testTag("osd_speed_chip")
                    )
                }
            }

            Spacer(modifier = Modifier.height(Dimens.Spacing4))

            val progress = if (durationMs > 0) currentPositionMs.toFloat() / durationMs.toFloat() else 0f
            Slider(
                value = progress.coerceIn(0f, 1f),
                onValueChange = onSeek,
                colors = SliderDefaults.colors(
                    thumbColor = MaterialTheme.colorScheme.primary,
                    activeTrackColor = MaterialTheme.colorScheme.primary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("osd_slider")
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = formatMs(currentPositionMs),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = formatMs(durationMs),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(Dimens.Spacing12))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = onOpenAudioTracks) {
                        Icon(Icons.Default.VolumeUp, contentDescription = "Ses Dili", tint = MaterialTheme.colorScheme.onSurface)
                    }
                    IconButton(onClick = onOpenSubtitleTracks) {
                        Icon(Icons.Default.ClosedCaption, contentDescription = "Altyazılar", tint = MaterialTheme.colorScheme.onSurface)
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(Dimens.Spacing12),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onSkipBack,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                            .testTag("osd_skip_back")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Replay10,
                            contentDescription = "10s Geri",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    IconButton(
                        onClick = onPlayPauseToggle,
                        modifier = Modifier
                            .size(58.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                            .testTag("osd_play_pause")
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Duraklat" else "Oynat",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(34.dp)
                        )
                    }

                    IconButton(
                        onClick = onSkipForward,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                            .testTag("osd_skip_forward")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Forward30,
                            contentDescription = "30s İleri",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                if (onGenAirClick != null) {
                    IconButton(
                        onClick = onGenAirClick,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(SoftAccent.copy(alpha = 0.20f))
                            .testTag("osd_gen_air_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Cast,
                            contentDescription = "Gen Air Aktar",
                            tint = SoftAccent
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.width(36.dp))
                }
            }
        }
    }
}

private fun formatMs(ms: Long): String {
    val totalSec = ms / 1000
    val hours = totalSec / 3600
    val min = (totalSec % 3600) / 60
    val sec = totalSec % 60
    return if (hours > 0) {
        "%d:%02d:%02d".format(hours, min, sec)
    } else {
        "%02d:%02d".format(min, sec)
    }
}
