package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.Dimens

data class SettingGroupInfo(
    val id: String,
    val nameTr: String,
    val descTr: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    revision: Int,
    onGroupClick: (String) -> Unit
) {
    val groups = listOf(
        SettingGroupInfo("look", "Görünüm", "Tema, palet, tipografi ve animasyonlar", Icons.Default.Tune),
        SettingGroupInfo("net", "Sunucu & Ağ", "Port, eşzamanlı akış ve yerel ağ keşfi", Icons.Default.Dns),
        SettingGroupInfo("lib", "Kitaplık", "Klasör yönetimi, taranan medyalar ve kurallar", Icons.Default.Folder),
        SettingGroupInfo("dev", "Cihazlar & İstemciler", "Eşleşmiş TV ve web istemcileri", Icons.Default.Tv),
        SettingGroupInfo("play", "Oynatma", "Altyazı, ses, atlama ve otomatik devam", Icons.Default.PlayCircle),
        SettingGroupInfo("priv", "Gizlilik & Sistem", "Günlük seviyesi, güvenlik ve veri yönetimi", Icons.Default.Shield)
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ayarlar", fontWeight = FontWeight.Bold) }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(Dimens.ScreenEdge),
            verticalArrangement = Arrangement.spacedBy(Dimens.Spacing12)
        ) {
            items(groups) { g ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_group_${g.id}")
                        .clickable { onGroupClick(g.id) },
                    shape = RoundedCornerShape(Dimens.RadiusLG),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
                ) {
                    Row(
                        modifier = Modifier.padding(Dimens.Spacing16),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(g.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(Dimens.Spacing16))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = g.nameTr, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Text(text = g.descTr, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(Dimens.Spacing8))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(Dimens.RadiusLG),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
                ) {
                    Column(modifier = Modifier.padding(Dimens.Spacing16)) {
                        Text(text = "Hakkında", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(Dimens.Spacing8))
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(text = "Sunucu Sürümü", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = "GenPlay v2.0.0", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(text = "Akış Motoru", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = "Fluid NIO Direct Core", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(Dimens.Spacing8))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(Dimens.Spacing8))
                    Text(
                        text = "Tüm ayarlar anlık kaydedilir ve ağdaki bağlı TV ile Web cihazlarına canlı uygulanır.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
