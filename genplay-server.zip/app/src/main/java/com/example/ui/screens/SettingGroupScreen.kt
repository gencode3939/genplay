package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import com.example.model.SettingDef
import com.example.model.SettingSchema
import com.example.model.SettingType
import com.example.ui.components.SettingRow
import com.example.ui.theme.Dimens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingGroupScreen(
    groupId: String,
    settingsMap: Map<String, String>,
    onBackClick: () -> Unit,
    onSettingChange: (String, Any) -> Unit
) {
    val groupDefs = SettingSchema.ALL.filter { it.group == groupId }
    val groupTitle = when (groupId) {
        "look" -> "Görünüm Ayarları"
        "net" -> "Sunucu & Ağ Ayarları"
        "lib" -> "Kitaplık Ayarları"
        "dev" -> "Cihaz Ayarları"
        "play" -> "Oynatma Ayarları"
        "priv" -> "Gizlilik & Sistem"
        else -> "Ayarlar"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(groupTitle, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            items(groupDefs) { def ->
                val currentValueStr = settingsMap[def.key] ?: def.defaultValue.toString()

                when (def.type) {
                    SettingType.BOOL -> {
                        val isChecked = currentValueStr.toBooleanStrictOrNull() ?: (def.defaultValue as Boolean)
                        SettingRow(
                            title = def.nameTr,
                            description = def.descTr,
                            isSwitch = true,
                            switchChecked = isChecked,
                            onSwitchChange = { onSettingChange(def.key, it) }
                        )
                    }
                    SettingType.ENUM -> {
                        SettingRow(
                            title = def.nameTr,
                            description = def.descTr,
                            valueText = currentValueStr,
                            onClick = {
                                val nextIndex = (def.options.indexOf(currentValueStr) + 1) % def.options.size
                                onSettingChange(def.key, def.options[nextIndex])
                            }
                        )
                    }
                    SettingType.INT -> {
                        SettingRow(
                            title = def.nameTr,
                            description = def.descTr,
                            valueText = currentValueStr,
                            onClick = {
                                val range = def.rangeInt ?: (0..100)
                                val currentVal = currentValueStr.toIntOrNull() ?: (def.defaultValue as Int)
                                val nextVal = if (currentVal >= range.last) range.first else currentVal + 1
                                onSettingChange(def.key, nextVal)
                            }
                        )
                    }
                    SettingType.STRING -> {
                        SettingRow(
                            title = def.nameTr,
                            description = def.descTr,
                            valueText = currentValueStr,
                            onClick = {}
                        )
                    }
                }
                Divider(color = MaterialTheme.colorScheme.outlineVariant)
            }
        }
    }
}
