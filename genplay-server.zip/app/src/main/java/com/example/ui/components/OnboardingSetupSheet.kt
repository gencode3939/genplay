package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.AppRole
import com.example.ui.theme.Dimens
import com.example.ui.theme.SoftAccent
import com.example.ui.theme.fluidGlassLens

@Composable
fun OnboardingSetupSheet(
    onRoleSelected: (AppRole) -> Unit,
    onDismissRequest: () -> Unit
) {
    var selectedRole by remember { mutableStateOf(AppRole.SERVER) }

    AlertDialog(
        onDismissRequest = onDismissRequest,
        confirmButton = {
            Button(
                onClick = { onRoleSelected(selectedRole) },
                colors = ButtonDefaults.buttonColors(containerColor = SoftAccent),
                shape = RoundedCornerShape(Dimens.RadiusMD),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("onboarding_confirm_btn")
            ) {
                Icon(androidx.compose.material.icons.Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Kurulumu Tamamla", fontWeight = FontWeight.Bold)
            }
        },
        title = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(Dimens.RadiusMD))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    SoftAccent.copy(alpha = 0.25f),
                                    Color(0xFF406DDF).copy(alpha = 0.15f)
                                )
                            )
                        )
                        .border(1.dp, SoftAccent.copy(alpha = 0.40f), RoundedCornerShape(Dimens.RadiusMD)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = androidx.compose.material.icons.Icons.Default.AutoAwesome,
                        contentDescription = "GenPlay Setup",
                        tint = SoftAccent,
                        modifier = Modifier.size(28.dp)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "GenPlay'e Hoş Geldiniz",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Bu cihazda GenPlay'i hangi modda kullanmak istersiniz? İstediğiniz zaman ayarlardan değiştirebilirsiniz.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.padding(top = 8.dp)
            ) {
                // Option 1: Server Mode
                val isServer = selectedRole == AppRole.SERVER
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(Dimens.RadiusMD))
                        .background(
                            if (isServer) SoftAccent.copy(alpha = 0.16f) else MaterialTheme.colorScheme.surfaceContainer
                        )
                        .border(
                            width = if (isServer) 1.5.dp else 1.dp,
                            color = if (isServer) SoftAccent else Color.White.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(Dimens.RadiusMD)
                        )
                        .clickable { selectedRole = AppRole.SERVER }
                        .padding(16.dp)
                        .testTag("onboarding_role_server")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(Dimens.RadiusSM))
                                .background(SoftAccent.copy(alpha = 0.20f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Dns, contentDescription = null, tint = SoftAccent)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Sunucu Modu (Server)",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "Medya klasörlerinizi tara, yerel ağda yayınla ve TV'lere akış sağla.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Option 2: Connect Mode
                val isConnect = selectedRole == AppRole.CONNECT
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(Dimens.RadiusMD))
                        .background(
                            if (isConnect) SoftAccent.copy(alpha = 0.16f) else MaterialTheme.colorScheme.surfaceContainer
                        )
                        .border(
                            width = if (isConnect) 1.5.dp else 1.dp,
                            color = if (isConnect) SoftAccent else Color.White.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(Dimens.RadiusMD)
                        )
                        .clickable { selectedRole = AppRole.CONNECT }
                        .padding(16.dp)
                        .testTag("onboarding_role_connect")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(Dimens.RadiusSM))
                                .background(SoftAccent.copy(alpha = 0.20f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Cast, contentDescription = null, tint = SoftAccent)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Oynatıcı Modu (Connect / İstemci)",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "Ağdaki sunucuya bağlan, kütüphaneyi tara ve TV/web cihazlarına yayın aktar.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        },
        shape = RoundedCornerShape(Dimens.RadiusLG),
        containerColor = Color(0xFF101728)
    )
}
