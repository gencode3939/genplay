package com.example.ui.theme

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

object Dimens {
    val Spacing2: Dp = 2.dp
    val Spacing4: Dp = 4.dp
    val Spacing8: Dp = 8.dp
    val Spacing12: Dp = 12.dp
    val Spacing16: Dp = 16.dp
    val Spacing20: Dp = 20.dp
    val Spacing24: Dp = 24.dp
    val Spacing32: Dp = 32.dp
    val Spacing40: Dp = 40.dp
    val Spacing48: Dp = 48.dp
    val Spacing56: Dp = 56.dp

    // Ultra-soft rounded architecture
    val RadiusXS: Dp = 10.dp
    val RadiusSM: Dp = 18.dp
    val RadiusMD: Dp = 26.dp
    val RadiusLG: Dp = 34.dp
    val RadiusXL: Dp = 44.dp
    val RadiusFull: Dp = 999.dp

    val FloatingDockHeight: Dp = 68.dp
    val FloatingDockBottomPadding: Dp = 20.dp
    val ScreenEdge: Dp = 18.dp
}

object GenPlaySprings {
    val Bouncy = spring<Float>(
        dampingRatio = Spring.DampingRatioLowBouncy,
        stiffness = Spring.StiffnessMediumLow
    )
    val Snappy = spring<Float>(
        dampingRatio = Spring.DampingRatioNoBouncy,
        stiffness = Spring.StiffnessMedium
    )
    val Gentle = spring<Float>(
        dampingRatio = Spring.DampingRatioNoBouncy,
        stiffness = Spring.StiffnessLow
    )
}
