package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.db.MediaItemEntity
import com.example.model.CardShape
import com.example.model.MediaItem
import com.example.ui.components.GenPlayCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.AmbientHaloBackground
import com.example.ui.theme.Dimens
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.fluidGlassLens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConnectHomeScreen(
    connectedServerHost: String?,
    connectedServerPort: Int?,
    items: List<MediaItemEntity>,
    isLoading: Boolean,
    onOpenDiscovery: () -> Unit,
    onOpenRoleSwitcher: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenPaletteSheet: () -> Unit,
    onItemClick: (MediaItemEntity) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_genplay_symbol),
                                contentDescription = "GenPlay Logo",
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(RoundedCornerShape(Dimens.RadiusXS))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("GenPlay", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(Dimens.RadiusFull))
                                    .background(com.example.ui.theme.SoftAccent.copy(alpha = 0.16f))
                                    .clickable { onOpenRoleSwitcher() }
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("Connect", style = MaterialTheme.typography.labelSmall, color = com.example.ui.theme.SoftAccent, fontWeight = FontWeight.Bold)
                            }
                        }
                        if (connectedServerHost != null) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                                Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(SuccessGreen))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "$connectedServerHost:$connectedServerPort",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                },
                actions = {
                    IconButton(onClick = onOpenDiscovery, modifier = Modifier.testTag("connect_switch_server_btn")) {
                        Icon(Icons.Default.Dns, contentDescription = "Sunucu Seç")
                    }
                    IconButton(onClick = onOpenPaletteSheet) {
                        Icon(Icons.Default.Palette, contentDescription = "Görünüm")
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Ayarlar")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        }
    ) { innerPadding ->
        AmbientHaloBackground(
            modifier = Modifier.padding(innerPadding)
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = Dimens.FloatingDockHeight + 40.dp)
            ) {
                // Hero Spotlight Card with Fluid Glass
                item {
                    val heroItem = items.firstOrNull()
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = Dimens.ScreenEdge)
                            .fluidGlassLens(
                                shape = RoundedCornerShape(Dimens.RadiusLG),
                                elevation = 8.dp,
                                tintAlpha = 0.85f,
                                borderAlpha = 0.45f
                            )
                            .clickable(enabled = heroItem != null) { heroItem?.let { onItemClick(it) } }
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(210.dp)
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            com.example.ui.theme.SoftAccent.copy(alpha = 0.12f),
                                            Color(0xFF0F172A).copy(alpha = 0.90f)
                                        )
                                    )
                                )
                                .padding(Dimens.Spacing20),
                            contentAlignment = Alignment.BottomStart
                        ) {
                            Column {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(Dimens.RadiusFull))
                                        .background(com.example.ui.theme.SoftAccent)
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = if (connectedServerHost != null) "ÖNE ÇIKAN" else "BAĞLANTI BEKLENİYOR",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = heroItem?.name ?: if (connectedServerHost != null) "İçerik Yükleniyor..." else "Bir GenPlay Sunucusuna Bağlanın",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = heroItem?.overview ?: "Yerel ağdaki filmlerinizi ve dizilerinizi doğrudan TV ve tabletinizde 4K kalitesinde izleyin.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }

                // Quick Connect Banner if not connected
                if (connectedServerHost == null) {
                    item {
                        Spacer(modifier = Modifier.height(Dimens.Spacing16))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = Dimens.ScreenEdge)
                                .fluidGlassLens(
                                    shape = RoundedCornerShape(Dimens.RadiusMD),
                                    elevation = 4.dp,
                                    tintAlpha = 0.75f,
                                    borderAlpha = 0.35f
                                )
                                .clickable { onOpenDiscovery() }
                                .padding(Dimens.Spacing16)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Sync, contentDescription = null, tint = com.example.ui.theme.SoftAccent)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Yerel Ağ Sunucusu Seçin", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                    Text("Ağdaki sunucuları taramak için dokunun", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text("Tara ›", style = MaterialTheme.typography.labelMedium, color = com.example.ui.theme.SoftAccent, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Movies / Videos Row
                item {
                    SectionHeader(title = "İzlemeye Devam Et")
                    if (isLoading) {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = Dimens.ScreenEdge),
                            horizontalArrangement = Arrangement.spacedBy(Dimens.Spacing12)
                        ) {
                            items(3) {
                                GenPlayCard(item = null, shape = CardShape.BACKDROP, isLoading = true)
                            }
                        }
                    } else if (items.isNotEmpty()) {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = Dimens.ScreenEdge),
                            horizontalArrangement = Arrangement.spacedBy(Dimens.Spacing12)
                        ) {
                            items(items) { entity ->
                                val model = MediaItem(id = entity.id, name = entity.name, type = entity.type, productionYear = entity.productionYear)
                                GenPlayCard(item = model, shape = CardShape.BACKDROP, onClick = { onItemClick(entity) })
                            }
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = Dimens.ScreenEdge)
                                .clip(RoundedCornerShape(Dimens.RadiusMD))
                                .background(Color(0xFF1E293B).copy(alpha = 0.5f))
                                .padding(Dimens.Spacing16),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (connectedServerHost != null) "Bu sunucuda henüz taranmış medya yok." else "Sunucuya bağlanınca içerikler burada listelenir.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // All Catalog Grid Section
                item {
                    SectionHeader(title = "Tüm Kütüphane")
                    if (items.isNotEmpty()) {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = Dimens.ScreenEdge),
                            horizontalArrangement = Arrangement.spacedBy(Dimens.Spacing12)
                        ) {
                            items(items) { entity ->
                                val model = MediaItem(id = entity.id, name = entity.name, type = entity.type, productionYear = entity.productionYear)
                                GenPlayCard(item = model, shape = CardShape.PORTRAIT, onClick = { onItemClick(entity) })
                            }
                        }
                    }
                }
            }
        }
    }
}
