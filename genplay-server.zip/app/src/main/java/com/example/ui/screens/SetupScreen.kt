package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.Dimens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupScreen(
    onSelectFolder: () -> Unit,
    onStartScan: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("İlk Kurulum", fontWeight = FontWeight.Bold) }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(Dimens.ScreenEdge)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(Dimens.RadiusLG),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Column {
                    SetupStepRow(
                        step = "1",
                        title = "1 · Rol seç",
                        desc = "Bu cihaz sunucu olarak belirlendi",
                        icon = Icons.Default.Tune,
                        onClick = {}
                    )
                    Divider(color = MaterialTheme.colorScheme.outlineVariant)
                    SetupStepRow(
                        step = "2",
                        title = "2 · Klasör seç",
                        desc = "Medya klasörlerinizi SAF ile bağlayın",
                        icon = Icons.Default.Folder,
                        onClick = onSelectFolder,
                        modifier = Modifier.testTag("setup_step_folder")
                    )
                    Divider(color = MaterialTheme.colorScheme.outlineVariant)
                    SetupStepRow(
                        step = "3",
                        title = "3 · Tara",
                        desc = "Kütüphane dizini ve indeks oluşturulur",
                        icon = Icons.Default.Refresh,
                        onClick = onStartScan,
                        modifier = Modifier.testTag("setup_step_scan")
                    )
                }
            }

            Spacer(modifier = Modifier.height(Dimens.Spacing16))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(Dimens.RadiusMD))
                    .background(MaterialTheme.colorScheme.surfaceContainer)
                    .padding(Dimens.Spacing16)
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(
                        Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(Dimens.Spacing12))
                    Text(
                        text = "Hiçbir adım önceden doldurulmaz. Varsayılan adres, kullanıcı veya sahte içerik bulunmaz (Y-12).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun SetupStepRow(
    step: String,
    title: String,
    desc: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(Dimens.Spacing16),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(Dimens.Spacing16))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text(text = desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
