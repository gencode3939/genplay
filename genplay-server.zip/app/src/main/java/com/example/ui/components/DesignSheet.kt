package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AppPalette
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.Dimens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DesignSheet(
    currentPalette: AppPalette,
    currentThemeMode: AppThemeMode,
    onPaletteSelect: (AppPalette) -> Unit,
    onThemeModeSelect: (AppThemeMode) -> Unit,
    onDismissRequest: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        containerColor = MaterialTheme.colorScheme.surfaceContainer,
        shape = RoundedCornerShape(topStart = Dimens.RadiusXL, topEnd = Dimens.RadiusXL)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = Dimens.ScreenEdge, vertical = Dimens.Spacing16)
        ) {
            Text(
                text = "Görünüm ve Tema",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Galeri 3 palet × 3 mod = 9 kombinasyon.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(Dimens.Spacing16))

            Text(
                text = "PALET",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(Dimens.Spacing8))

            Row(horizontalArrangement = Arrangement.spacedBy(Dimens.Spacing8)) {
                PaletteOptionChip(
                    name = "GenPlay",
                    color = Color(0xFF5B8DEF),
                    isSelected = currentPalette == AppPalette.GENPLAY,
                    onClick = { onPaletteSelect(AppPalette.GENPLAY) }
                )
                PaletteOptionChip(
                    name = "Sinema",
                    color = Color(0xFFC4553B),
                    isSelected = currentPalette == AppPalette.SINEMA,
                    onClick = { onPaletteSelect(AppPalette.SINEMA) }
                )
                PaletteOptionChip(
                    name = "Orman",
                    color = Color(0xFF2E7D5B),
                    isSelected = currentPalette == AppPalette.ORMAN,
                    onClick = { onPaletteSelect(AppPalette.ORMAN) }
                )
            }

            Spacer(modifier = Modifier.height(Dimens.Spacing16))

            Text(
                text = "MOD",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(Dimens.Spacing8))

            Row(horizontalArrangement = Arrangement.spacedBy(Dimens.Spacing8)) {
                FilterChip(
                    selected = currentThemeMode == AppThemeMode.DARK,
                    onClick = { onThemeModeSelect(AppThemeMode.DARK) },
                    label = { Text("Koyu") },
                    modifier = Modifier.testTag("mode_dark")
                )
                FilterChip(
                    selected = currentThemeMode == AppThemeMode.LIGHT,
                    onClick = { onThemeModeSelect(AppThemeMode.LIGHT) },
                    label = { Text("Açık") },
                    modifier = Modifier.testTag("mode_light")
                )
                FilterChip(
                    selected = currentThemeMode == AppThemeMode.AMOLED,
                    onClick = { onThemeModeSelect(AppThemeMode.AMOLED) },
                    label = { Text("AMOLED") },
                    modifier = Modifier.testTag("mode_amoled")
                )
            }

            Spacer(modifier = Modifier.height(Dimens.Spacing24))
        }
    }
}

@Composable
fun PaletteOptionChip(
    name: String,
    color: Color,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(CircleShape)
            .background(
                if (isSelected) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.surfaceContainerHigh
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = name,
                style = MaterialTheme.typography.labelMedium,
                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
