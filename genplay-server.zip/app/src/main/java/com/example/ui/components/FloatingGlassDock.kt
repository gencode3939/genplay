package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.Dimens
import com.example.ui.theme.FluidMotion

data class DockTabItem(
    val id: String,
    val title: String,
    val icon: ImageVector
)

@Composable
fun FloatingGlassDock(
    items: List<DockTabItem>,
    selectedId: String,
    onItemSelected: (String) -> Unit,
    isTvMode: Boolean = false,
    isVisible: Boolean = true,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = isVisible,
        enter = if (isTvMode) slideInVertically { -it } + fadeIn() else slideInVertically { it } + fadeIn(),
        exit = if (isTvMode) slideOutVertically { -it } + fadeOut() else slideOutVertically { it } + fadeOut(),
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = Dimens.ScreenEdge)
                .padding(
                    top = if (isTvMode) 16.dp else 0.dp,
                    bottom = if (isTvMode) 0.dp else Dimens.FloatingDockBottomPadding
                ),
            contentAlignment = if (isTvMode) Alignment.TopCenter else Alignment.BottomCenter
        ) {
            Row(
                modifier = Modifier
                    .height(Dimens.FloatingDockHeight)
                    .shadow(
                        elevation = 12.dp,
                        shape = RoundedCornerShape(Dimens.RadiusFull),
                        ambientColor = Color.Black.copy(alpha = 0.8f),
                        spotColor = com.example.ui.theme.SoftAccentGlow.copy(alpha = 0.2f)
                    )
                    .clip(RoundedCornerShape(Dimens.RadiusFull))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF1E283E).copy(alpha = 0.88f),
                                Color(0xFF0A0F1D).copy(alpha = 0.95f)
                            )
                        )
                    )
                    .border(
                        width = 1.dp,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.40f),
                                com.example.ui.theme.SoftAccent.copy(alpha = 0.20f),
                                Color.White.copy(alpha = 0.08f)
                            )
                        ),
                        shape = RoundedCornerShape(Dimens.RadiusFull)
                    )
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                items.forEach { item ->
                    val isSelected = item.id == selectedId
                    val interactionSource = remember { MutableInteractionSource() }
                    val isPressed by interactionSource.collectIsPressedAsState()
                    var isFocused by remember { mutableStateOf(false) }

                    val scale by animateFloatAsState(
                        targetValue = when {
                            isPressed -> 0.91f
                            isFocused -> 1.08f
                            isSelected -> 1.05f
                            else -> 1.0f
                        },
                        animationSpec = FluidMotion.LensSpring,
                        label = "dock_scale"
                    )

                    val bgColor by animateColorAsState(
                        targetValue = when {
                            isFocused -> com.example.ui.theme.SoftAccent.copy(alpha = 0.30f)
                            isSelected -> com.example.ui.theme.SoftAccent.copy(alpha = 0.16f)
                            else -> Color.Transparent
                        },
                        label = "dock_bg"
                    )

                    val contentColor by animateColorAsState(
                        targetValue = if (isSelected || isFocused) com.example.ui.theme.SoftAccent else MaterialTheme.colorScheme.onSurfaceVariant,
                        label = "dock_color"
                    )

                    Box(
                        modifier = Modifier
                            .scale(scale)
                            .clip(RoundedCornerShape(Dimens.RadiusFull))
                            .background(bgColor)
                            .border(
                                width = if (isFocused) 1.5.dp else if (isSelected) 1.dp else 0.dp,
                                color = if (isFocused) com.example.ui.theme.SoftAccent else if (isSelected) com.example.ui.theme.SoftAccent.copy(alpha = 0.35f) else Color.Transparent,
                                shape = RoundedCornerShape(Dimens.RadiusFull)
                            )
                            .onFocusChanged { isFocused = it.isFocused }
                            .focusable()
                            .clickable(
                                interactionSource = interactionSource,
                                indication = null,
                                onClick = { onItemSelected(item.id) }
                            )
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .testTag("dock_tab_${item.id}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.title,
                                tint = contentColor,
                                modifier = Modifier.size(20.dp)
                            )
                            if (isSelected || (isTvMode && isFocused)) {
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = contentColor
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
