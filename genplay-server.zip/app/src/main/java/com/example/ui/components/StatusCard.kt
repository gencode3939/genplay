package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.Dimens
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.fluidGlassLens

@Composable
fun StatusCard(
    isServerRunning: Boolean,
    serverAddress: String,
    deviceCount: Int,
    sessionCount: Int,
    onToggleServer: () -> Unit,
    onCopyAddress: () -> Unit,
    onShareAddress: () -> Unit,
    onSettingsClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = Dimens.ScreenEdge)
            .fluidGlassLens(
                shape = RoundedCornerShape(Dimens.RadiusLG),
                elevation = 8.dp,
                tintAlpha = 0.82f,
                borderAlpha = 0.45f
            )
            .padding(Dimens.Spacing20)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_genplay_symbol),
                        contentDescription = "GenPlay Logo",
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(Dimens.RadiusSM))
                    )
                    Spacer(modifier = Modifier.width(Dimens.Spacing12))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(if (isServerRunning) SuccessGreen else ErrorRed)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isServerRunning) "Sunucu Yayında" else "Sunucu Kapalı",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Text(
                            text = if (isServerRunning) "0.0.0.0:8471 HTTP & WS Aktif" else "Yayın durduruldu",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(Dimens.RadiusFull))
                        .background(
                            if (isServerRunning) com.example.ui.theme.SoftAccent.copy(alpha = 0.16f)
                            else Color.White.copy(alpha = 0.08f)
                        )
                        .border(
                            1.dp,
                            if (isServerRunning) com.example.ui.theme.SoftAccent.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.15f),
                            RoundedCornerShape(Dimens.RadiusFull)
                        )
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isServerRunning) "CANLI" else "BEKLEMEDE",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isServerRunning) com.example.ui.theme.SoftAccent else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(Dimens.Spacing16))

            // Dynamic Address Box with Copy and Share Action
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(Dimens.RadiusSM))
                    .background(Color(0xFF0F172A).copy(alpha = 0.75f))
                    .border(0.5.dp, com.example.ui.theme.SoftAccent.copy(alpha = 0.25f), RoundedCornerShape(Dimens.RadiusSM))
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "YEREL AĞ ADRESİ (WEB PORTAL)",
                            style = MaterialTheme.typography.labelSmall,
                            color = com.example.ui.theme.SoftAccent,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (isServerRunning) serverAddress else "Sunucu başlatılınca IP atanır",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    if (isServerRunning) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            IconButton(
                                onClick = onCopyAddress,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.10f))
                                    .testTag("copy_ip_btn")
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Kopyala", modifier = Modifier.size(16.dp), tint = Color.White)
                            }
                            IconButton(
                                onClick = onShareAddress,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.10f))
                                    .testTag("share_ip_btn")
                            ) {
                                Icon(Icons.Default.Share, contentDescription = "Paylaş", modifier = Modifier.size(16.dp), tint = Color.White)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(Dimens.Spacing16))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(Dimens.Spacing8)
            ) {
                MetricBox(label = "BAĞLI CİHAZ", value = if (isServerRunning) deviceCount.toString() else "—", modifier = Modifier.weight(1f))
                MetricBox(label = "AKTİF OTURUM", value = if (isServerRunning) sessionCount.toString() else "—", modifier = Modifier.weight(1f))
                MetricBox(label = "AKIŞ KANALI", value = if (isServerRunning) "$sessionCount / 4" else "—", modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(Dimens.Spacing16))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(Dimens.Spacing12)
            ) {
                Button(
                    onClick = onToggleServer,
                    shape = RoundedCornerShape(Dimens.RadiusFull),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isServerRunning) ErrorRed else com.example.ui.theme.SoftAccent,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("toggle_server_btn")
                ) {
                    Icon(
                        imageVector = if (isServerRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isServerRunning) "Sunucuyu Durdur" else "Sunucuyu Başlat",
                        fontWeight = FontWeight.Bold
                    )
                }

                IconButton(
                    onClick = onSettingsClick,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.08f))
                        .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape)
                        .testTag("server_settings_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Ayarlar",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun MetricBox(label: String, value: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(Dimens.RadiusSM))
            .background(Color(0xFF0F172A).copy(alpha = 0.65f))
            .border(0.5.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(Dimens.RadiusSM))
            .padding(vertical = 10.dp, horizontal = 12.dp)
    ) {
        Column {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
