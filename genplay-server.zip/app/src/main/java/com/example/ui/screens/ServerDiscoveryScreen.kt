package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.connect.DiscoveredServer
import com.example.connect.LanDiscoveryEngine
import com.example.ui.theme.Dimens
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SuccessGreen
import com.example.util.NetworkUtils
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServerDiscoveryScreen(
    currentHost: String? = null,
    onServerSelected: (host: String, port: Int) -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isScanning by remember { mutableStateOf(false) }
    var discoveredServers by remember { mutableStateOf<List<DiscoveredServer>>(emptyList()) }
    var showManualDialog by remember { mutableStateOf(false) }

    val localIp = remember { NetworkUtils.getLocalIpAddress(context) }
    var manualHost by remember { mutableStateOf(if (localIp != "127.0.0.1") localIp else "192.168.1.100") }
    var manualPort by remember { mutableStateOf("8471") }
    var isTestingConnection by remember { mutableStateOf(false) }
    var testResultError by remember { mutableStateOf<String?>(null) }

    fun startDiscovery() {
        isScanning = true
        coroutineScope.launch {
            val results = LanDiscoveryEngine.discoverServers(localIp)
            discoveredServers = results
            isScanning = false
        }
    }

    LaunchedEffect(Unit) {
        startDiscovery()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Sunucu Bul & Bağlan", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                actions = {
                    IconButton(onClick = { startDiscovery() }, enabled = !isScanning) {
                        Icon(Icons.Default.Refresh, contentDescription = "Yenile")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    testResultError = null
                    showManualDialog = true
                },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("IP ile Bağlan") },
                shape = RoundedCornerShape(Dimens.RadiusFull),
                modifier = Modifier.testTag("manual_ip_fab")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(Dimens.ScreenEdge)
        ) {
            // Sonar Animated Radar Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(Dimens.RadiusXL))
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                                MaterialTheme.colorScheme.surfaceContainer
                            )
                        )
                    )
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(Dimens.RadiusXL)),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(Dimens.Spacing24),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val transition = rememberInfiniteTransition(label = "radar")
                    val pulseScale by transition.animateFloat(
                        initialValue = 0.85f,
                        targetValue = 1.15f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(1200),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "pulse"
                    )

                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .scale(if (isScanning) pulseScale else 1f)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sensors,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(38.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(Dimens.Spacing16))

                    Text(
                        text = if (isScanning) "Yerel Ağ Taranıyor..." else "Tarama Tamamlandı",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Alt ağ: $localIp:8471 aranıyor",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(Dimens.Spacing20))

            Text(
                text = "Bulunan Sunucular (${discoveredServers.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(Dimens.Spacing12))

            if (discoveredServers.isEmpty() && !isScanning) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Ağda aktif sunucu bulunamadı.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Sunucu cihazınızda 'Sunucuyu Başlat' butonuna bastığınızdan emin olun.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = {
                                testResultError = null
                                showManualDialog = true
                            },
                            shape = RoundedCornerShape(Dimens.RadiusFull)
                        ) {
                            Text("Sunucu IP'sini Elle Girin")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(Dimens.Spacing12)
                ) {
                    items(discoveredServers) { server ->
                        val isCurrent = currentHost == server.host
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(Dimens.RadiusLG))
                                .border(
                                    width = if (isCurrent) 1.5.dp else 1.dp,
                                    color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                                    shape = RoundedCornerShape(Dimens.RadiusLG)
                                )
                                .clickable { onServerSelected(server.host, server.port) },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
                        ) {
                            Row(
                                modifier = Modifier.padding(Dimens.Spacing16),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primaryContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Dns,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }

                                Spacer(modifier = Modifier.width(Dimens.Spacing16))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = server.serverName,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "http://${server.host}:${server.port} · v${server.version}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(SuccessGreen)
                                    )
                                    Text(
                                        text = "${server.latencyMs}ms",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SuccessGreen,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showManualDialog) {
            AlertDialog(
                onDismissRequest = { if (!isTestingConnection) showManualDialog = false },
                title = { Text("Manuel Sunucu Bağlantısı", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Sunucu ekranında gördüğünüz IP adresini yazın:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedTextField(
                            value = manualHost,
                            onValueChange = {
                                manualHost = it.trim().removePrefix("http://").removePrefix("https://").substringBefore(":")
                                testResultError = null
                            },
                            label = { Text("IP Adresi (Örn: 192.168.1.35)") },
                            singleLine = true,
                            shape = RoundedCornerShape(Dimens.RadiusSM),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = manualPort,
                            onValueChange = {
                                manualPort = it.trim()
                                testResultError = null
                            },
                            label = { Text("Port") },
                            singleLine = true,
                            shape = RoundedCornerShape(Dimens.RadiusSM),
                            modifier = Modifier.fillMaxWidth()
                        )

                        if (testResultError != null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Error, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = testResultError!!,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = ErrorRed
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val portInt = manualPort.toIntOrNull() ?: 8471
                            isTestingConnection = true
                            testResultError = null

                            coroutineScope.launch {
                                val pingRes = LanDiscoveryEngine.pingAndFetchServer(manualHost, portInt, timeoutMs = 1200)
                                isTestingConnection = false
                                if (pingRes != null) {
                                    showManualDialog = false
                                    onServerSelected(manualHost, portInt)
                                } else {
                                    testResultError = "Bağlanılamadı. IP adresinin doğruluğunu ve sunucunun açık olduğunu kontrol edin."
                                }
                            }
                        },
                        enabled = !isTestingConnection && manualHost.isNotBlank(),
                        shape = RoundedCornerShape(Dimens.RadiusFull)
                    ) {
                        if (isTestingConnection) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Test Ediliyor...")
                        } else {
                            Text("Test Et & Bağlan")
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showManualDialog = false }, enabled = !isTestingConnection) {
                        Text("İptal")
                    }
                },
                shape = RoundedCornerShape(Dimens.RadiusLG)
            )
        }
    }
}
