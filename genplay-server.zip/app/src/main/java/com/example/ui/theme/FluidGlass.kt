package com.example.ui.theme

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// Harmonious soft accent color shared across all fluid glass components
val SoftAccent = Color(0xFF6C9BFF)
val SoftAccentGlow = Color(0xFF4C75D0)

object FluidMotion {
    val LensSpring = spring<Float>(
        dampingRatio = 0.72f,
        stiffness = 380f
    )
    val SnappySpring = spring<Float>(
        dampingRatio = Spring.DampingRatioNoBouncy,
        stiffness = 450f
    )
}

fun Modifier.fluidGlassLens(
    shape: Shape,
    elevation: Dp = 4.dp,
    tintAlpha: Float = 0.76f,
    borderAlpha: Float = 0.35f
): Modifier = this
    .shadow(
        elevation = elevation,
        shape = shape,
        ambientColor = Color.Black.copy(alpha = 0.5f),
        spotColor = SoftAccentGlow.copy(alpha = 0.15f)
    )
    .clip(shape)
    .background(
        Brush.linearGradient(
            colors = listOf(
                Color(0xFF181F30).copy(alpha = tintAlpha),
                Color(0xFF0F1422).copy(alpha = (tintAlpha + 0.10f).coerceAtMost(0.95f))
            ),
            start = Offset(0f, 0f),
            end = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
        )
    )
    .border(
        width = 1.dp,
        brush = Brush.linearGradient(
            colors = listOf(
                Color.White.copy(alpha = borderAlpha),
                SoftAccent.copy(alpha = borderAlpha * 0.45f),
                Color.White.copy(alpha = borderAlpha * 0.10f)
            ),
            start = Offset(0f, 0f),
            end = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
        ),
        shape = shape
    )

@Composable
fun AmbientHaloBackground(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "halo_ambient")
    val pulseAnim by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(4500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "halo_pulse"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0B101D))
    ) {
        // Soft Harmonious Halos (Gentle sapphire & warm slate)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF4C75D0).copy(alpha = 0.07f * pulseAnim),
                            Color(0xFF2E3A59).copy(alpha = 0.03f),
                            Color.Transparent
                        ),
                        center = Offset(160f, 260f),
                        radius = 850f * pulseAnim
                    )
                )
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF384B70).copy(alpha = 0.06f),
                            Color(0xFF283A52).copy(alpha = 0.02f * pulseAnim),
                            Color.Transparent
                        ),
                        center = Offset(900f, 1600f),
                        radius = 950f
                    )
                )
        )

        content()
    }
}
