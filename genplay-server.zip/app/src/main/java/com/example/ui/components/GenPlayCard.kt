package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.CardShape
import com.example.model.MediaItem
import com.example.ui.theme.Dimens
import com.example.ui.theme.FluidMotion
import com.example.ui.theme.fluidGlassLens

@Composable
fun GenPlayCard(
    item: MediaItem?,
    shape: CardShape = CardShape.PORTRAIT,
    isLoading: Boolean = false,
    badgeText: String? = null,
    progressPercent: Float = 0f,
    onClick: () -> Unit = {}
) {
    val (width: Dp, aspectRatio: Float) = when (shape) {
        CardShape.PORTRAIT -> Pair(132.dp, 2f / 3f)
        CardShape.BACKDROP -> Pair(228.dp, 16f / 9f)
        CardShape.FOUR_THREE -> Pair(168.dp, 4f / 3f)
        CardShape.SQUARE -> Pair(132.dp, 1f / 1f)
        CardShape.SIDE_FOOTER -> Pair(164.dp, 1f / 1f)
        CardShape.SPOTLIGHT -> Pair(310.dp, 16f / 9f)
        CardShape.AUTO_WIDTH -> Pair(228.dp, 16f / 9f)
    }

    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    var isFocused by remember { mutableStateOf(false) }

    val currentScale by animateFloatAsState(
        targetValue = when {
            isPressed -> 0.94f
            isFocused -> 1.08f
            else -> 1f
        },
        animationSpec = FluidMotion.LensSpring,
        label = "fluid_card_scale"
    )

    Column(
        modifier = Modifier
            .width(width)
            .scale(currentScale)
            .testTag("card_${item?.id ?: "skeleton"}")
            .onFocusChanged { isFocused = it.isFocused }
            .focusable(enabled = !isLoading && item != null)
            .clickable(
                enabled = !isLoading && item != null,
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(aspectRatio)
                .fluidGlassLens(
                    shape = RoundedCornerShape(Dimens.RadiusMD),
                    elevation = if (isFocused) 12.dp else if (isPressed) 2.dp else 6.dp,
                    tintAlpha = if (isFocused) 0.90f else 0.80f,
                    borderAlpha = if (isFocused) 0.85f else if (isPressed) 0.65f else 0.40f
                )
                .then(
                    if (isFocused) {
                        Modifier.border(
                            width = 2.dp,
                            brush = Brush.horizontalGradient(
                                colors = listOf(
                                    com.example.ui.theme.SoftAccent,
                                    Color(0xFF8EB2FF)
                                )
                            ),
                            shape = RoundedCornerShape(Dimens.RadiusMD)
                        )
                    } else Modifier
                )
        ) {
            if (isLoading) {
                ShimmerEffect()
            } else if (item != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF1E293B).copy(alpha = 0.85f),
                                    Color(0xFF0F172A).copy(alpha = 0.95f)
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = item.name.take(1).uppercase(),
                        style = MaterialTheme.typography.displayLarge,
                        color = com.example.ui.theme.SoftAccent.copy(alpha = 0.35f),
                        fontWeight = FontWeight.Bold
                    )

                    // Subtle Specular Light Sweep
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        Color.White.copy(alpha = 0.12f),
                                        Color.Transparent,
                                        Color.Transparent
                                    )
                                )
                            )
                    )
                }
            }

            if (badgeText != null) {
                Box(
                    modifier = Modifier
                        .padding(8.dp)
                        .align(Alignment.TopStart)
                        .clip(RoundedCornerShape(Dimens.RadiusFull))
                        .background(Color(0xFF0F172A).copy(alpha = 0.85f))
                        .border(0.5.dp, com.example.ui.theme.SoftAccent.copy(alpha = 0.35f), RoundedCornerShape(Dimens.RadiusFull))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = badgeText,
                        style = MaterialTheme.typography.labelSmall,
                        color = com.example.ui.theme.SoftAccent,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (progressPercent > 0f) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .align(Alignment.BottomStart)
                        .background(Color.White.copy(alpha = 0.15f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(progressPercent.coerceIn(0f, 1f))
                            .clip(RoundedCornerShape(Dimens.RadiusFull))
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        com.example.ui.theme.SoftAccent,
                                        Color(0xFF8EB2FF)
                                    )
                                )
                            )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .height(12.dp)
                    .clip(RoundedCornerShape(Dimens.RadiusXS))
                    .background(Color.White.copy(alpha = 0.1f))
            )
            Spacer(modifier = Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.5f)
                    .height(10.dp)
                    .clip(RoundedCornerShape(Dimens.RadiusXS))
                    .background(Color.White.copy(alpha = 0.08f))
            )
        } else if (item != null) {
            Text(
                text = item.name,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            val subText = item.productionYear?.toString() ?: item.type
            Text(
                text = subText,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun ShimmerEffect() {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val translateAnim by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_anim"
    )

    val brush = Brush.linearGradient(
        colors = listOf(
            Color.Transparent,
            Color.White.copy(alpha = 0.15f),
            Color.Transparent
        ),
        start = androidx.compose.ui.geometry.Offset(translateAnim - 250f, translateAnim - 250f),
        end = androidx.compose.ui.geometry.Offset(translateAnim, translateAnim)
    )

    Spacer(
        modifier = Modifier
            .fillMaxSize()
            .background(brush)
    )
}
