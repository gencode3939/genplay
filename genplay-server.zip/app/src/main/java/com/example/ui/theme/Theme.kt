package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

enum class AppPalette { GENPLAY, SINEMA, ORMAN }
enum class AppThemeMode { DARK, LIGHT, AMOLED }

private val GenPlayDarkScheme = darkColorScheme(
    primary = GenPlayDarkPrimary,
    onPrimary = GenPlayDarkOnPrimary,
    primaryContainer = GenPlayDarkPrimaryContainer,
    onPrimaryContainer = GenPlayDarkOnPrimaryContainer,
    secondary = GenPlayDarkSecondary,
    surface = GenPlayDarkSurface,
    surfaceVariant = GenPlayDarkSurfaceLow,
    surfaceContainer = GenPlayDarkSurfaceContainer,
    surfaceContainerHigh = GenPlayDarkSurfaceHigh,
    surfaceContainerHighest = GenPlayDarkSurfaceHighest,
    onSurface = GenPlayDarkOnSurface,
    onSurfaceVariant = GenPlayDarkOnSurfaceVariant,
    outline = GenPlayDarkOutline,
    outlineVariant = GenPlayDarkOutlineVariant
)

private val SinemaDarkScheme = darkColorScheme(
    primary = SinemaDarkPrimary,
    onPrimary = SinemaDarkOnPrimary,
    primaryContainer = SinemaDarkPrimaryContainer,
    onPrimaryContainer = SinemaDarkOnPrimaryContainer,
    surface = SinemaDarkSurface,
    surfaceVariant = SinemaDarkSurfaceLow,
    surfaceContainer = SinemaDarkSurfaceContainer,
    surfaceContainerHigh = SinemaDarkSurfaceHigh,
    surfaceContainerHighest = SinemaDarkSurfaceHighest,
    onSurface = SinemaDarkOnSurface,
    onSurfaceVariant = SinemaDarkOnSurfaceVariant,
    outline = SinemaDarkOutline,
    outlineVariant = SinemaDarkOutlineVariant
)

private val OrmanDarkScheme = darkColorScheme(
    primary = OrmanDarkPrimary,
    onPrimary = OrmanDarkOnPrimary,
    primaryContainer = OrmanDarkPrimaryContainer,
    onPrimaryContainer = OrmanDarkOnPrimaryContainer,
    surface = OrmanDarkSurface,
    surfaceVariant = OrmanDarkSurfaceLow,
    surfaceContainer = OrmanDarkSurfaceContainer,
    surfaceContainerHigh = OrmanDarkSurfaceHigh,
    surfaceContainerHighest = OrmanDarkSurfaceHighest,
    onSurface = OrmanDarkOnSurface,
    onSurfaceVariant = OrmanDarkOnSurfaceVariant,
    outline = OrmanDarkOutline,
    outlineVariant = OrmanDarkOutlineVariant
)

private val AmoledScheme = darkColorScheme(
    primary = GenPlayDarkPrimary,
    onPrimary = Color(0xFF001844),
    primaryContainer = Color(0xFF142B59),
    onPrimaryContainer = Color(0xFFD8E2FF),
    surface = Color(0xFF000000),
    surfaceVariant = Color(0xFF0A0A0A),
    surfaceContainer = Color(0xFF121212),
    surfaceContainerHigh = Color(0xFF1A1A1A),
    surfaceContainerHighest = Color(0xFF232323),
    onSurface = Color(0xFFE2E2E9),
    onSurfaceVariant = Color(0xFFA0A7B8),
    outline = Color(0xFF525969),
    outlineVariant = Color(0xFF242A36)
)

private val GenPlayLightScheme = lightColorScheme(
    primary = Color(0xFF2358C2),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD8E2FF),
    onPrimaryContainer = Color(0xFF001A4B),
    surface = Color(0xFFF8F9FF),
    surfaceVariant = Color(0xFFF0F3FA),
    surfaceContainer = Color(0xFFE6EAFA),
    surfaceContainerHigh = Color(0xFFDCE1F2),
    surfaceContainerHighest = Color(0xFFD0D7EC),
    onSurface = Color(0xFF181C24),
    onSurfaceVariant = Color(0xFF434753),
    outline = Color(0xFF747784),
    outlineVariant = Color(0xFFC4C6D4)
)

@Composable
fun GenPlayTheme(
    palette: AppPalette = AppPalette.GENPLAY,
    themeMode: AppThemeMode = AppThemeMode.DARK,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode) {
        AppThemeMode.AMOLED -> AmoledScheme
        AppThemeMode.LIGHT -> GenPlayLightScheme
        AppThemeMode.DARK -> when (palette) {
            AppPalette.GENPLAY -> GenPlayDarkScheme
            AppPalette.SINEMA -> SinemaDarkScheme
            AppPalette.ORMAN -> OrmanDarkScheme
        }
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.surface.toArgb()
            window.navigationBarColor = colorScheme.surfaceContainer.toArgb()
            val isLight = themeMode == AppThemeMode.LIGHT
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = isLight
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = isLight
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        content = content
    )
}
