package com.example.scanner

import java.util.Locale

data class ParsedTitle(
    val title: String,
    val sortName: String,
    val year: Int?,
    val season: Int?,
    val episode: Int?
)

object TitleParser {
    private val TURKISH_LOCALE = Locale("tr", "TR")

    private val QUALITY_TAGS = listOf(
        "1080p", "720p", "4k", "2160p", "bluray", "web-dl", "webdl", "hdrip",
        "x264", "x265", "hevc", "aac", "dts", "10bit", "dual", "tr", "en"
    )

    private val SEASON_EPISODE_REGEX = Regex("""(?i)[sS](\d{1,2})[eE](\d{1,2})|(\d{1,2})x(\d{1,2})|(\d{1,2})\.\s*sezon\s*(\d{1,2})\.\s*bölüm""")
    private val YEAR_REGEX = Regex("""\b(19\d{2}|20\d{2})\b""")

    fun parseFilename(filename: String): ParsedTitle {
        var clean = filename.substringBeforeLast('.')
            .replace('.', ' ')
            .replace('_', ' ')
            .replace('-', ' ')

        var season: Int? = null
        var episode: Int? = null

        val seMatch = SEASON_EPISODE_REGEX.find(clean)
        if (seMatch != null) {
            val groups = seMatch.groupValues
            if (groups[1].isNotEmpty() && groups[2].isNotEmpty()) {
                season = groups[1].toIntOrNull()
                episode = groups[2].toIntOrNull()
            } else if (groups[3].isNotEmpty() && groups[4].isNotEmpty()) {
                season = groups[3].toIntOrNull()
                episode = groups[4].toIntOrNull()
            } else if (groups[5].isNotEmpty() && groups[6].isNotEmpty()) {
                season = groups[5].toIntOrNull()
                episode = groups[6].toIntOrNull()
            }
            clean = clean.replace(seMatch.value, "")
        }

        var year: Int? = null
        val yearMatch = YEAR_REGEX.find(clean)
        if (yearMatch != null) {
            year = yearMatch.value.toIntOrNull()
            clean = clean.replace(yearMatch.value, "")
        }

        // Remove quality tags
        for (tag in QUALITY_TAGS) {
            clean = clean.replace(Regex("(?i)\\b$tag\\b"), "")
        }

        val displayTitle = clean.replace(Regex("""\s+"""), " ").trim()
        val sortName = displayTitle.lowercase(TURKISH_LOCALE)
            .replace('ı', 'i')
            .replace('ğ', 'g')
            .replace('ü', 'u')
            .replace('ş', 's')
            .replace('ö', 'o')
            .replace('ç', 'c')

        return ParsedTitle(
            title = if (displayTitle.isNotBlank()) displayTitle else filename,
            sortName = sortName,
            year = year,
            season = season,
            episode = episode
        )
    }
}
