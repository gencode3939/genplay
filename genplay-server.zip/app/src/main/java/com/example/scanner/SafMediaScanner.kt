package com.example.scanner

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.example.data.db.MediaItemEntity
import com.example.data.repository.MediaRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.security.MessageDigest

data class ScanProgress(
    val isScanning: Boolean = false,
    val currentFile: String = "",
    val scannedCount: Int = 0,
    val totalCount: Int = 0,
    val isCancelled: Boolean = false
)

class SafMediaScanner(
    private val context: Context,
    private val mediaRepository: MediaRepository
) {
    private val _progress = MutableStateFlow(ScanProgress())
    val progress: StateFlow<ScanProgress> = _progress

    private var cancelRequested = false

    fun cancelScan() {
        cancelRequested = true
    }

    suspend fun scanFolderTree(treeUri: Uri, folderId: String) = withContext(Dispatchers.IO) {
        cancelRequested = false
        _progress.value = ScanProgress(isScanning = true, currentFile = "Klasör taranıyor...")

        val rootDoc = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext
        val itemsToSave = mutableListOf<MediaItemEntity>()

        var count = 0
        val queue = ArrayDeque<DocumentFile>()
        queue.add(rootDoc)

        while (queue.isNotEmpty() && !cancelRequested) {
            val currentDir = queue.removeFirst()
            val files = currentDir.listFiles()

            for (file in files) {
                if (cancelRequested) break

                if (file.isDirectory) {
                    queue.add(file)
                    val parsedDir = TitleParser.parseFilename(file.name ?: "Folder")
                    val dirEntity = MediaItemEntity(
                        id = generateDeterministicId("${file.uri}_dir"),
                        parentId = folderId,
                        type = "Folder",
                        mediaType = "Folder",
                        name = parsedDir.title,
                        sortName = parsedDir.sortName,
                        dateCreated = System.currentTimeMillis().toString(),
                        isFolder = true,
                        path = file.uri.toString()
                    )
                    itemsToSave.add(dirEntity)
                } else if (file.isFile && isSupportedMediaFile(file.name ?: "")) {
                    count++
                    val fileName = file.name ?: "Unknown"
                    _progress.value = ScanProgress(
                        isScanning = true,
                        currentFile = fileName,
                        scannedCount = count,
                        totalCount = count
                    )

                    val parsed = TitleParser.parseFilename(fileName)
                    val mimeType = context.contentResolver.getType(file.uri) ?: getMimeTypeFromExt(fileName)
                    val isAudio = mimeType.startsWith("audio/")

                    var runTimeTicks: Long? = null
                    try {
                        val mmr = MediaMetadataRetriever()
                        mmr.setDataSource(context, file.uri)
                        val durationMsStr = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                        val durationMs = durationMsStr?.toLongOrNull() ?: 0L
                        runTimeTicks = durationMs * 10_000L
                        mmr.release()
                    } catch (_: Exception) {}

                    val itemEntity = MediaItemEntity(
                        id = generateDeterministicId("${file.uri}_file_${file.length()}"),
                        parentId = folderId,
                        type = if (isAudio) "Audio" else if (parsed.season != null) "Episode" else "Movie",
                        mediaType = if (isAudio) "Audio" else "Video",
                        name = parsed.title,
                        sortName = parsed.sortName,
                        indexNumber = parsed.episode,
                        parentIndexNumber = parsed.season,
                        productionYear = parsed.year,
                        dateCreated = System.currentTimeMillis().toString(),
                        runTimeTicks = runTimeTicks,
                        isFolder = false,
                        path = file.uri.toString(),
                        fileSize = file.length(),
                        mimeType = mimeType
                    )
                    itemsToSave.add(itemEntity)

                    if (itemsToSave.size >= 50) {
                        mediaRepository.saveMediaItems(itemsToSave)
                        itemsToSave.clear()
                    }
                }
            }
        }

        if (itemsToSave.isNotEmpty() && !cancelRequested) {
            mediaRepository.saveMediaItems(itemsToSave)
        }

        _progress.value = ScanProgress(
            isScanning = false,
            scannedCount = count,
            isCancelled = cancelRequested
        )
    }

    private fun isSupportedMediaFile(filename: String): Boolean {
        val ext = filename.substringAfterLast('.').lowercase()
        return listOf("mp4", "mkv", "avi", "mov", "webm", "mp3", "m4a", "flac", "ogg", "wav", "aac").contains(ext)
    }

    private fun getMimeTypeFromExt(filename: String): String {
        val ext = filename.substringAfterLast('.').lowercase()
        return when (ext) {
            "mp4" -> "video/mp4"
            "mkv" -> "video/x-matroska"
            "avi" -> "video/x-msvideo"
            "mov" -> "video/quicktime"
            "webm" -> "video/webm"
            "mp3" -> "audio/mpeg"
            "m4a", "aac" -> "audio/mp4"
            "flac" -> "audio/flac"
            "ogg" -> "audio/ogg"
            "wav" -> "audio/wav"
            else -> "video/mp4"
        }
    }

    private fun generateDeterministicId(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(input.toByteArray(Charsets.UTF_8))
        return hashBytes.take(16).joinToString("") { "%02x".format(it) }
    }
}
