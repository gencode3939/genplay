# GENPLAY SERVER — Uygulama Şartnamesi ve Prompt Kitabı

### Telefon uygulaması · medya sunucusu · TV dağıtıcısı

> **Bu doküman tek bir uygulamayı tanımlar:** `app.genplay.server`. Telefonda çalışır, kütüphaneyi barındırır, HTTP/WebSocket sunar, **GenPlay Connect**'i TV'lere ADB ile kurar ve yönetir.
>
> Kardeş doküman: **`genplay-connect.md`** → TV istemcisi. İki dokümanın **§0.4 PAYLAŞILAN SÖZLEŞME** bölümü **birebir aynıdır**. Arayüz belirteçleri (renk, tipografi, boşluk, motion) da **birebir aynıdır** — iki uygulama aynı görünmek zorunda.

---

## 0. ÖNSÖZ

### 0.1 İki uygulama, tek ürün

```
┌─────────────────────────────────────┐        ┌─────────────────────────────────────┐
│  GENPLAY SERVER                     │        │  GENPLAY CONNECT                    │
│  app.genplay.server                 │        │  app.genplay.connect                │
│  ─────────────────────────────────  │        │  ─────────────────────────────────  │
│  • Telefon / tablet                 │◀─────▶ │  • Android TV / TV Box              │
│  • KÜTÜPHANEYİ barındırır           │  HTTP  │  • Kütüphaneyi GÖRÜNTÜLER           │
│  • Dosyaları okur, indeksler        │  + WS  │  • Oynatır                          │
│  • HTTP + WebSocket sunar           │        │  • Kütüphane YOK — saf istemci      │
│  • ADB ile Connect'i kurar          │──ADB──▶│  • Ayarları SERVER'dan alır         │
│  • Ayar paneli, cihaz yönetimi      │        │  • D-pad ile tam kumanda            │
│  • Kendi kütüphanesini oynatır      │        │                                     │
└─────────────────────────────────────┘        └─────────────────────────────────────┘
        ↑ "sunucu" = veri sahibi                        ↑ "istemci" = veri tüketicisi
```

**Kritik ayrım:** Connect'in **veritabanı yoktur**, **tarama yapmaz**, **dosya okumaz**. Sadece HTTP isteği atar ve geleni çizer. Bu, TV APK'sını **10 MB'ın altında** tutmanın tek yolu (K-12).

**Server'ın ise hem sunucusu hem istemcisi vardır:** telefon kendi kütüphanesini tarar, sunar **ve** kendi ekranında oynatır. Yani Server, Connect'in yaptığı her şeyi **kendi içinde** de yapar — ama kendi verisine doğrudan eriştiği için HTTP'ye çıkmaz.

### 0.2 `genplay.md` ile ilişki

| `genplay.md` | Bu doküman | Ne oldu |
|---|---|---|
| §1–§6 (APK analizleri) | **referans** | Aynen geçerli, burada tekrar edilmez |
| §7 (ürün sözleşmesi) | **§1** | İki uygulamaya **bölündü** |
| §8 (mimari) | **§2** | Modül sınırı netleşti: `server` vs `connect` |
| §9 (veri modeli) | **§3** + Connect §3 | 19 tablo **yalnızca Server'da** |
| §10 (HTTP/WS + eşleştirme) | **§0.4 (ORTAK)** | **Birebir aynı**, iki dosyada |
| §11 (ADB dağıtımı) | **§4** | **Yalnızca Server'da** |
| §12–§18 (arayüz) | **§5** + Connect §5 | `genplayui.md`'den, platforma göre ayrıldı |
| §19–§23 (güvenlik/test) | **§6–§7** | Platforma göre ayrıldı |
| §24–§25 (build/prompt kuralı) | **§8** | |
| §26–§29 (14 prompt) | **§9** (8 prompt) + Connect §9 (7 prompt) | 14 → **15'e** bölündü |
| §30–§34 | referans | Aynen geçerli |

### 0.3 `genplayui.md` ile ilişki — arayüzün tek kaynağı

`genplayui.md` iki APK'nın (Emby Android TV 2.5.03g + Fladder 0.11.1) analizinden çıkan **ortak tasarım sistemini** tanımlar. Bu doküman onu **uygulamaz**, **tüketir**:

| `genplayui.md` | Bu doküman kullanır | Connect kullanır |
|---|---|---|
| §4 Tasarım token'ları (24 renk, 15 tipografi, 9 boşluk, 6 radius, 6 motion) | ✅ **birebir** | ✅ **birebir** |
| §5 Kart sistemi (10 şekil, `GenPlayCard`) | ✅ | ✅ |
| §6 Bölüm motoru (12 `SectionType`) | ✅ (5 bölüm) | ✅ (6 bölüm) |
| §7 Odak/D-pad | ⚠️ kısmi (dokunma ağırlıklı) | ✅ **tam** |
| §8 Ekran kataloğu (26 ekran) | 13 ekran alır | 13 ekran alır |
| §9 `:core:design` modülü | ✅ **ortak modül** | ✅ **ortak modül** |

**`genplayui.md` §4 ve §9 her iki uygulamada da birebir aynı kodu üretir.** Bu, "arayüzleri aynı yap" talebinin teknik karşılığıdır.

---

### 0.4 PAYLAŞILAN SÖZLEŞME

> ⚠️ **Bu bölüm kardeş dokümanın §0.4'ü ile BİREBİR AYNIDIR.** Değiştirirseniz ikisini birlikte değiştirin. CI'da `diff` kapısı vardır (§7.4).

#### 0.4.1 Y-1…Y-12 — Değiştirilemez yasaklar

Bu 12 kural **pazarlık konusu değil**. Her prompt bu listeyi taşır, her PR CI'da denetlenir (K-13).

| # | Yasak | Ölçülebilir denetim |
|---|---|---|
| **Y-1** | **Demo modu yok** | Kod tabanında `demo`, `sample`, `mock`, `fake`, `dummy`, `lorem` geçmez. Sahte film, örnek kütüphane, mock API yok |
| **Y-2** | **Sabit IP/port yok** | `192.168.*`, `10.*`, `172.16.*`, `:8096`, `:8080` literal olarak hiçbir yerde yazmaz |
| **Y-3** | **Test medyası APK'de yok** | `assets/` içinde örnek video/ses/görsel yok |
| **Y-4** | **İnternet/bulut/röle yok** | İstek yalnızca RFC 1918 + link-local + loopback'a. Telemetri, hesap, senkron, güncelleme kontrolü yok |
| **Y-5** | **Hesap yok** | Kayıt, giriş, e-posta, şifre sıfırlama, abonelik, lisans anahtarı, ücretli katman yok |
| **Y-6** | **Cast yok** | Google Cast, Chromecast, DLNA, UPnP, Miracast, AirPlay yok |
| **Y-7** | **v1'de transcoding yok** | ffmpeg, ffprobe, MediaCodec transcode boru hattı, HLS segment üretimi yok |
| **Y-8** | **DRM kırma yok** | Widevine/PlayReady çözme yok. DRM'li içerik **tespit edilip reddedilir** (`451`) |
| **Y-9** | **Boş tık yok** | İşlevi olmayan düğme/menü/ayar yok. Bir özellik yoksa UI'ı da yok |
| **Y-10** | **Sahte başarı yok** | Başarısız işlemde kullanıcıya gerçek sebep. "Tamamlandı" deyip yapmamak yasak |
| **Y-11** | **Token sızıntısı yok** | Bearer token yalnızca `Authorization` başlığında. URL, QR, log, dosya adı, bildirim metninde asla |
| **Y-12** | **Sabit demo yapılandırması yok** | Varsayılan sunucu adresi, önceden doldurulmuş kullanıcı, "hemen dene" düğmesi yok |

**Platforma özgü ek yasaklar** bu tabloda **değil**, her uygulamanın kendi §1.3'ünde listelenir:

| Doküman | Bölüm | İçerik |
|---|---|---|
| `genplay-server.md` | **§1.3** | YS-1, YS-2 (dosya erişimi ve token saklama) |
| `genplay-connect.md` | **§1.3** | YC-1, YC-2, YC-3 (veritabanı/tarama/ayar yazma yasağı) |

#### 0.4.2 K-1…K-16 — Kabul kriterleri

| # | Kriter | Hedef | Ölçüm | Hangi uygulama |
|---|---|---|---|---|
| **K-1** | Soğuk açılış (telefon, boş kütüphane) | ≤ **1,8 sn** ilk kare | `ColdStartupMetric`, 20 tekrar, medyan | Server |
| **K-2** | Soğuk açılış (TV, bağlı) | ≤ **2,5 sn** ilk kare | `ColdStartupMetric` | Connect |
| **K-3** | TV'ye APK kurulumu (100 Mb/s Wi-Fi) | ≤ **90 sn** | `PlanJournal` zaman damgaları | Server |
| **K-4** | Tek ayar canlı düzenleme | ≤ **600 ms** | Compose test + `elapsedRealtimeNanos` | Server |
| **K-5** | Oynatma başlatma (doğrudan, yerel) | ≤ **800 ms** | seçim → ilk kare | İkisi |
| **K-6** | `Range` isteği ilk bayt | ≤ **120 ms** | `curl -w '%{time_starttransfer}'` | Server |
| **K-7** | Ana ekran bölüm sırası değişimi | ≤ **250 ms** | bırakma → görsel tamamlanma | Connect |
| **K-8** | 5.000 öğelik kütüphanede kaydırma | **≥ 55 fps**, jank ≤ %2 | Macrobenchmark `FrameTimingMetric` | İkisi |
| **K-9** | Arama (5.000 öğe, FTS4) | ≤ **150 ms** | `Trace` bölümü | Server |
| **K-10** | Bellek (TV, 1 saat oynatma) | ≤ **320 MB** PSS, artış **sıfır** | `dumpsys meminfo` 60 sn'de bir | Connect |
| **K-11** | Telefon APK boyutu | ≤ **25 MB** | `stat` | Server |
| **K-12** | TV APK boyutu | ≤ **10 MB** | `stat` | Connect |
| **K-13** | Y-1…Y-12 denetimi | **12/12 geçer** | CI `forbidden-literals.sh` | İkisi |
| **K-14** | Ambilight CPU maliyeti | ≤ **%6** tek çekirdek, gecikme ≤ 120 ms | `Trace` + `Top` | Connect |
| **K-15** | Birim test kapsamı | `:core:*` için ≥ **%80** | JaCoCo | İkisi |
| **K-16** | Çökme oranı | ≤ **%0,1** | ⚠️ **Y-4 ile çelişir** → §7.3 | İkisi |

#### 0.4.3 HTTP protokolü — 25 uç nokta

**Tüm uç noktalar `/api/v1` öneki taşır.** Alt yol son eki (`/emby`) **yoktur**.

| # | Metot | Yol | Kimlik | Ne döner |
|---|---|---|:--:|---|
| 1 | `GET` | `/api/v1/health` | ✗ | `{status, version, api, uptimeSeconds, pairingRequired}` |
| 2 | `GET` | `/api/v1/info` | ✗ | Sunucu bilgisi + yetenek listesi |
| 3 | `POST` | `/api/v1/pair/challenge` | ✗ | `{challenge, expiresAt}` |
| 4 | `POST` | `/api/v1/pair/confirm` | ✗ | `{token, userId, deviceId}` |
| 5 | `GET` | `/api/v1/users` | ✓ | Kullanıcı listesi |
| 6 | `GET` | `/api/v1/users/me` | ✓ | Etkin kullanıcı + politika |
| 7 | `GET` | `/api/v1/library` | ✓ | Kütüphane kökleri |
| 8 | `GET` | `/api/v1/items` | ✓ | Sayfalı öğe listesi (§0.4.5) |
| 9 | `GET` | `/api/v1/items/{id}` | ✓ | Tek öğe (tam DTO §0.4.6) |
| 10 | `GET` | `/api/v1/items/{id}/ancestors` | ✓ | Üst zincir (breadcrumb) |
| 11 | `GET` | `/api/v1/items/latest` | ✓ | Son eklenenler |
| 12 | `GET` | `/api/v1/items/resume` | ✓ | Yarım kalanlar |
| 13 | `GET`/`HEAD` | `/api/v1/media/{id}/stream` | ✓ | ⭐ **Range/206** (§0.4.7) |
| 14 | `GET` | `/api/v1/media/{id}/artwork` | ✓ | Görsel (`type`, `width`, `quality`, `tag`) |
| 15 | `GET` | `/api/v1/media/{id}/subtitles` | ✓ | Altyazı listesi |
| 16 | `GET` | `/api/v1/media/{id}/subtitles/{idx}` | ✓ | Altyazı gövdesi (VTT) |
| 17 | `POST` | `/api/v1/progress/{id}` | ✓ | İlerleme yaz (idempotent) |
| 18 | ⭐ `GET` | `/api/v1/home/sections` | ✓ | **Bölüm listesi (sıralı)** |
| 19 | ⭐ `POST` | `/api/v1/home/sections` | ✓ | Bölüm kaydet/ekle |
| 20 | ⭐ `POST` | `/api/v1/home/sections/move` | ✓ | **Sıra değiştir** |
| 21 | ⭐ `DELETE` | `/api/v1/home/sections/{id}` | ✓ | Bölüm sil |
| 22 | ⭐ `GET` | `/api/v1/home/sections/{id}/items` | ✓ | **Bir bölümün öğeleri** |
| 23 | `GET` | `/api/v1/sessions` | ✓ | Etkin oturumlar (kim ne izliyor) |
| 24 | `WS` | `/api/v1/ws` | ✓ | ⭐ WebSocket (§0.4.8) |
| 25 | `GET` | `/api/v1/search` | ✓ | FTS4 arama |

**Genel yanıtlar:**

| Durum | Ne zaman | Gövde |
|---|---|---|
| `200 OK` | Başarılı | İstenen JSON |
| `206 Partial Content` | `Range` geçerli | Bayt aralığı |
| `304 Not Modified` | `If-None-Match` ETag eşleşti | boş |
| `400 Bad Request` | Geçersiz parametre | `{code, message, param}` |
| `401 Unauthorized` | Token yok/geçersiz/iptal | `{code:"UNAUTHORIZED"}` |
| `403 Forbidden` | Yetki yok | `{code:"FORBIDDEN"}` |
| `404 Not Found` | Öğe yok | `{code:"NOT_FOUND"}` |
| `416 Range Not Satisfiable` | Aralık aşıyor | `Content-Range: bytes */N` |
| `451 Unavailable For Legal Reasons` | DRM tespit (Y-8) | `{code:"DRM_DETECTED"}` |
| `503 Service Unavailable` | Eşzamanlı akış sınırı | `{code:"TOO_MANY_STREAMS"}` + `Retry-After` |

**Hata gövdesi:** `message` **her zaman kullanıcıya gösterilebilir** Türkçe metin (Y-10). `code` **sabit, İngilizce, makine için**.

```json
{ "code": "DRM_DETECTED",
  "message": "Bu içerik DRM korumalı ve GenPlay tarafından oynatılamaz.",
  "itemId": "a1b2c3d4e5f60718293a4b5c6d7e8f90",
  "retryAfter": null }
```

#### 0.4.4 Eşleştirme protokolü — T-1…T-9

```
TV (Connect)                               Telefon (Server)
 │                                              │
 │── GET /api/v1/health ───────────────────────▶│
 │◀─ {status:"ok", api:1, pairingRequired:true}─│
 │                                              │
 │── POST /api/v1/pair/challenge ──────────────▶│
 │   {deviceId, deviceName:"Salon TV",           │  ⭐ Telefon EKRANINDA onay diyaloğu:
 │    role:"tv", clientVersion, nonce}           │     "Salon TV bağlanmak istiyor"
 │                                              │     [İzin Ver] [Reddet]  15 sn
 │◀─ {challenge, expiresIn:15, serverName} ─────│
 │                                              │
 │── POST /api/v1/pair/confirm ────────────────▶│
 │   {challenge, nonce,                          │
 │    response: HMAC-SHA256(challenge‖nonce, K)} │  K = AUTH_SECRET
 │◀─ 200 {token, userId, deviceId, expiresAt:null}
 │                                              │
 │  Token ARTIK yalnızca Authorization başlığında (Y-11)
```

| # | Kural |
|---|---|
| **T-1** | Token **256-bit kriptografik rastgele**, `base64url` (43 karakter, `=` dolgu yok) |
| **T-2** | JWT **değil** — opak. Sunucu kendi üretir, kendi DB'sinde saklar |
| **T-3** | Sunucuda **Argon2id hash'i** saklanır, düz token değil |
| **T-4** | Süre sonu **yok** (`expiresAt: null`); **iptal** var: `revoked_at` |
| **T-5** | Her cihaz için **ayrı** token. Cihaz kaldırılınca iptal |
| **T-6** | Token **hiçbir zaman** loglanmaz, URL'ye konmaz, QR'a yazılmaz, bildirime girmez, düz metin yazılmaz |
| **T-7** | `pair/challenge` **15 sn** içinde `confirm` edilmezse geçersiz |
| **T-8** | Aynı `deviceId` için **3 başarısız** `confirm` → 60 sn kilit + telefonda uyarı |
| **T-9** | Onay diyaloğu **telefonda** gösterilir, TV'de değil |

#### 0.4.5 `GET /api/v1/items` — tam parametreler

| Parametre | Tip | Varsayılan | Açıklama |
|---|---|---|---|
| `parentId` | string | — | Klasör kökü |
| `includeItemTypes` | csv | — | `Movie,Series,Episode,BoxSet,Playlist,Audio,Album` |
| `excludeItemTypes` | csv | — | |
| `recursive` | bool | `false` | Alt klasörleri dahil et |
| `sortBy` | csv | `SortName` | `SortName,DateCreated,ProductionYear,CommunityRating,Random` |
| `sortOrder` | enum | `Ascending` | `Ascending,Descending` |
| `startIndex` | int | `0` | Sayfalama |
| `limit` | int | `100` | `0` = sınırsız (max 500 zorunlu) |
| `searchTerm` | string | — | |
| `genres` | csv | — | |
| `years` | csv | — | |
| `isPlayed` | bool | — | |
| `minCommunityRating` | float | — | |
| `fields` | csv | — | `Overview,People,MediaSources,MediaStreams,Chapters,Genres` |
| `imageTypeLimit` | int | `1` | |
| `enableImages` | bool | `true` | |

**Yanıt:** `{ Items:[MediaItem], TotalRecordCount:int, StartIndex:int }`

#### 0.4.6 `MediaItem` DTO — tel biçimi

```json
{
  "Id": "32 hex",
  "ParentId": "32 hex|null",
  "Type": "Movie|Series|Season|Episode|Video|Album|MusicArtist|Audio|BoxSet|Playlist|Folder|Photo",
  "MediaType": "Video|Audio|Photo",
  "Name": "string 1..512",
  "OriginalTitle": "string|null",
  "SortName": "string",
  "IndexNumber": "int|null",
  "ParentIndexNumber": "int|null",
  "ProductionYear": "1870..2100|null",
  "PremiereDate": "date-time|null",
  "DateCreated": "date-time",
  "Overview": "string|null max 8192",
  "Tagline": "string|null max 512",
  "OfficialRating": "string|null",
  "CommunityRating": "0..10|null",
  "RunTimeTicks": "int|null  // 1 sn = 10.000.000",
  "IsFolder": "bool",
  "HasDrm": "bool",          // true → oynatma REDDEDİLİR (Y-8)
  "Genres": ["string"]       // max 16
  "People": [{ "Name", "Type":"Actor|Director|Writer|Producer", "Role" }],
  "MediaSources": [MediaSource] // 1..8
  "ImageTags": { "Primary":"etag", "Backdrop":"etag", … },
  "BackdropImageTags": ["etag"],
  "PrimaryImageAspectRatio": "number|null",
  "UserData": { "PlayedPercentage", "PlaybackPositionTicks", "IsPlayed", "IsFavorite", "PlayCount" },
  "Chapters": [{ "StartTicks", "Name", "ImageTag" }],
  "MediaStreams": [{ "Type":"Video|Audio|Subtitle", "Index", "Codec", "Language", "IsDefault", "IsForced" }],
  "Path": "string|null"
}
```

#### 0.4.7 `Range` şartnamesi — `GET /api/v1/media/{id}/stream`

| Durum | Kural |
|---|---|
| `Range` yok | `200`, tam gövde, `Accept-Ranges: bytes`, `Content-Length: N` |
| `Range: bytes=0-` | `206`, `Content-Range: bytes 0-{N-1}/{N}` |
| `Range: bytes={a}-{b}` | `206`, `Content-Range: bytes {a}-{b}/{N}`, `Content-Length: b-a+1` |
| `Range: bytes={N}-` | `416`, `Content-Range: bytes */{N}` |
| `Range: bytes=-{k}` (suffix) | `206`, son `k` bayt |
| Çoklu aralık | `200` tam gövde (çoklu aralık **desteklenmez**) |
| `If-Range` | ETag eşleşmezse `200` tam gövde |
| `HEAD` | `200`, gövde yok, `Content-Length` + `Accept-Ranges` |

**`Accept-Ranges: bytes` her zaman gönderilir.** İlk bayt ≤ **120 ms** (K-6). Sıfır kopya: `RandomAccessFile` → `FileChannel.transferTo(…)` — `ByteArray` tahsisi yok (§2.5).

#### 0.4.8 WebSocket — `/api/v1/ws`

**Bağlantı:** `GET /api/v1/ws` → `Upgrade: websocket`. Token **ilk mesajda**, URL'de **değil** (Y-11).

```json
→ { "MessageType": "Identity",
    "Data": { "Token": "<base64url>", "DeviceId": "…",
              "ClientVersion": "1.0.0", "Role": "tv" } }

← { "MessageType": "IdentityAck",
    "Data": { "SessionId": "…", "ServerVersion": "1.0.0", "Api": 1,
              "Capabilities": ["sections","sessions","progress","settings"],
              "KeepAliveSeconds": 30 } }
```

**Zarf (tüm mesajlar):**
```json
{ "MessageType": "LibraryChanged",
  "MessageId": "01J9ZK7Q3M5X8Y2N4P6R7T9VWB",   // ULID, 26 karakter
  "ServerTime": 1761638400123,
  "Data": { } }
```

| Yön | MessageType | Data | Tetikleyici |
|---|---|---|---|
| ← | `LibraryChanged` | `{ItemsAdded, ItemsRemoved, ItemsUpdated, FoldersRemovedFrom}` | Tarama bitti |
| ← | `UserDataChanged` | `{UserId, UserDataList:[{ItemId, PlaybackPositionTicks, IsPlayed}]}` | İlerleme yazıldı |
| ← | `Sessions` | `[{DeviceId, DeviceName, UserName, NowPlaying}]` | Kim izliyor |
| ← | `SettingsChanged` | `{Revision, Changed:[{Key, Value}]}` | Ayar değişti |
| → | `KeepAlive` | `{}` | 30 sn'de bir |
| ← | `KeepAliveAck` | `{}` | |

**Kimlik doğrulama başarısızsa:** `← {MessageType:"IdentityReject", Data:{code:"UNAUTHORIZED"}}` + bağlantı **1008 (Policy Violation)** ile kapanır. HTTP `401` **değil** — yükseltme zaten yapılmıştır.

#### 0.4.9 12 `SectionType` — ortak sözlük

| # | `SectionType` | Türkçe başlık | Server | Connect |
|---|---|---|:--:|:--:|
| 1 | `SPOTLIGHT` | *(başlık yok)* | — | ✅ |
| 2 | `RESUME` | Devam Et | ✅ | ✅ |
| 3 | `NEXT_UP` | Sıradaki | ✅ | ✅ |
| 4 | `LATEST_MEDIA` | Son Eklenenler | ✅ | ✅ |
| 5 | `DISCOVER` | Keşfet | — | ✅ |
| 6 | `USER_VIEWS` | Kütüphanelerim | ✅ | ✅ |
| 7 | `DEVICES` | Cihazlar | ✅ | — |
| 8 | `SCAN` | Tarama | ✅ | — |
| 9 | `LIBRARIES` | Kütüphaneler | ✅ | — |
| 10 | `LATEST_AUDIO` | Son Eklenen Müzik | ✅ | — |
| 11 | `PLAYLISTS` | Çalma Listeleri | ✅ | — |
| 12 | `COLLECTIONS` | Koleksiyonlar | ✅ | — |

**`resolveCardShape()` 3 katmanlı öncelik** (her iki uygulamada aynı kod):
1. **Kullanıcı tercihi** (bölüm başına, sunucuda saklı)
2. **Gerçek veriden** (ilk öğenin tipi + backdrop varlığı)
3. **Bölüm varsayılanı**

⚠️ Hiçbir koşulda `BANNER`, `SMALL_SIDE_FOOTER`, `THUMB` döndürmez (`genplayui.md` UI-T08).

#### 0.4.10 40 alanlı `SettingSchema` — iki uygulamanın ortak ayar sözlüğü

**Server yazar, Connect okur.** Connect hiçbir ayarı değiştiremez (YC-3) — yalnızca ana ekran sırasını değiştirebilir (§5.6, istisna).

```kotlin
object SettingSchema {
    val ALL: List<SettingDef> = listOf(
        // ── GÖRÜNÜM (9) ────────────────────────────────────
        def("theme",               ENUM,   "dark",     listOf("dark","black","light")),
        def("palette",             ENUM,   "genplay",  listOf("genplay","sinema","orman")),
        def("card_size_adjust",    INT,    0,          range = -2..2),
        def("home_orientation",    ENUM,   "vertical", listOf("vertical","horizontal")),
        def("folder_outlines",     BOOL,   true),
        def("show_runtime_badge",  BOOL,   true),
        def("focus_preview",       BOOL,   false),
        def("animations",          BOOL,   true),
        def("font_scale",          ENUM,   "normal",   listOf("small","normal","large","xlarge")),

        // ── OYNATMA (9) ────────────────────────────────────
        def("autoplay_next",       BOOL,   true),
        def("autoplay_delay_ms",   INT,    8000,       range = 3000..30000),
        def("resume_threshold",    INT,    90,         range = 50..99),
        def("intro_skip_enabled",  BOOL,   false),
        def("skip_back_seconds",   INT,    10,         range = 5..30),
        def("skip_forward_seconds",INT,    30,         range = 10..120),
        def("audio_boost",         BOOL,   false),
        def("refresh_rate_match",  BOOL,   true),
        def("max_bitrate_mbps",    INT,    0,          range = 0..400),

        // ── ALTYAZI (8) ────────────────────────────────────
        def("subtitle_enabled",    BOOL,   false),
        def("subtitle_language",   STRING, "tr"),
        def("subtitle_size",       ENUM,   "medium",   listOf("small","medium","large","xlarge")),
        def("subtitle_color",      ENUM,   "white",    listOf("white","yellow","cyan")),
        def("subtitle_background", ENUM,   "translucent", listOf("none","translucent","opaque")),
        def("subtitle_position",   ENUM,   "bottom",   listOf("bottom","top")),
        def("subtitle_on_skipback",BOOL,   true),
        def("subtitle_force_override",BOOL,false),

        // ── SES/EFEKT (3) ──────────────────────────────────
        def("sound_effects",       BOOL,   false),
        def("volume_step",         INT,    5,          range = 1..20),
        def("ambilight_enabled",   BOOL,   true),      // ⚠ cihaz destekliyorsa

        // ── BOŞTA / EKRAN KORUYUCU (5) ─────────────────────
        def("screensaver_enabled", BOOL,   true),
        def("screensaver_delay_min",INT,   15,         range = 1..120),
        def("screensaver_source",  ENUM,   "backdrops",listOf("backdrops","clock","off")),
        def("screensaver_text",    BOOL,   true),
        def("still_watching_min",  INT,    180,        range = 30..600),

        // ── GİZLİLİK / TEŞHİS (3) ──────────────────────────
        def("show_stats_overlay",  BOOL,   false),
        def("show_file_path",      BOOL,   false,      adminOnly = true),
        def("log_level",           ENUM,   "warn",     listOf("error","warn","info"), adminOnly = true),

        // ── ERİŞİLEBİLİRLİK (3) ────────────────────────────
        def("reduce_motion",       BOOL,   false),
        def("high_contrast",       BOOL,   false),
        def("screen_reader_hints", BOOL,   true),

        // ── SİSTEM (3) ─────────────────────────────────────
        def("boot_autostart",      BOOL,   false),     // ⭐ varsayılan KAPALI
        def("language",            ENUM,   "tr",       listOf("tr","en")),
        def("config_revision",     INT,    0,          readOnly = true),
    )
}
```

**Sayım: 40 alan.** `requiresRestart = true` olanlar: `boot_autostart`, `language`, `log_level` — **3 alan**.

#### 0.4.11 `AUTH_SECRET` — ADB üzerinden paylaşılan giz

| Kural | Değer |
|---|---|
| Uzunluk | **32 bayt** (256 bit) kriptografik rastgele |
| Üretim | Server ilk kurulumda üretir |
| Saklama (Server) | AES-256-GCM, `noBackupFilesDir()/auth.bin`, StrongBox → TEE → yazılım anahtarı |
| İletim | **Yalnızca ADB `exec:` kanalıyla**, kurulum sırasında bir kez |
| Saklama (Connect) | AES-256-GCM, `getNoBackupFilesDir()` |
| Kullanım | `HMAC-SHA256(challenge‖nonce, K)` (§0.4.4) |
| Yenileme | Cihaz kaldırılıp yeniden eklenince yeni `AUTH_SECRET` — **eski geçersiz** |

---

---

## 1. ÜRÜN TANIMI — GenPlay Server

### 1.1 Tek cümle

> **Telefonunuzdaki medya kütüphanesini kendi Wi-Fi ağınızda bir sunucuya dönüştüren, TV'nize uygulamayı kendisi kuran ve bütün ayarları tek tek telefondan düzenleyebilen Android uygulaması.**

### 1.2 Ne yapar — 7 yetenek

| # | Yetenek | Ölçülebilir sonuç |
|---|---|---|
| **1** | **Kütüphane barındırma** | SAF `treeUri` ile seçilen klasörü indeksler, 19 tabloya yazar |
| **2** | **HTTP sunucu** | 25 uç nokta, `Range`/206 destekli akış, 4 eşzamanlı akış |
| **3** | **WebSocket** | 5 mesaj tipi, 30 sn keep-alive, ULID zarf |
| **4** | **TV dağıtımı** | Saf Kotlin ADB-over-TCP ile Connect APK'sını kurar (K-3 ≤ 90 sn) |
| **5** | **Adres enjeksiyonu** | Kurulum sonrası TV'ye sunucu adresini + token'ı iletir |
| **6** | **Canlı ayar düzenleme** | 40 alanın her biri TV'de ≤ 600 ms içinde uygulanır (K-4) |
| **7** | **Kendi kütüphanesini oynatma** | Telefonda da tam oynatıcı (Connect ile aynı `:core:player`) |

### 1.3 Ne yapmaz — 8 sınır

| Yapmaz | Neden |
|---|---|
| İnternete çıkmaz | Y-4 |
| Hesap/abonelik istemez | Y-5 |
| Transcoding yapmaz | Y-7 — doğrudan oynatma veya reddet |
| DRM çözmez | Y-8 — `451 DRM_DETECTED` |
| Cast yapmaz | Y-6 |
| Buluta yedeklemez | Y-4 |
| Reklam göstermez | — |
| Telemetri toplamaz | Y-4 |

### 1.4 Kullanıcı hikâyeleri — 12

| # | Hikâye | Kabul |
|---|---|---|
| **S-1** | "İlk açılışta klasörümü seçip kütüphanemi oluşturmak istiyorum" | 3 adımda tamamlanır, tarama ilerlemesi görünür |
| **S-2** | "TV'me uygulamayı tek dokunuşla kurmak istiyorum" | Cihaz seç → Kur → ≤ 90 sn |
| **S-3** | "TV'de hangi ayarın ne olduğunu telefondan değiştirmek istiyorum" | ≤ 600 ms, TV'de ● yeşil onay |
| **S-4** | "Kütüphanemde ne var, ne kadar yer kaplıyor görmek istiyorum" | Kütüphane ekranı: öğe sayısı, boyut, son tarama |
| **S-5** | "TV'de kim ne izliyor görmek istiyorum" | Oturumlar ekranı, 5 sn'de bir tazelenir |
| **S-6** | "Telefonumda da film izlemek istiyorum" | Aynı oynatıcı, aynı OSD |
| **S-7** | "Aynı Wi-Fi'da olmayan TV'ye nasıl kuracağımı bilmek istiyorum" | Açık hata + çözüm adımları |
| **S-8** | "Bir TV'yi kaldırmak istiyorum" | Cihaz sil → token iptal + TV'de 401 |
| **S-9** | "Kütüphanemi yeniden taramak istiyorum" | Tarama ekranı, iptal edilebilir |
| **S-10** | "Aradığım filmi hızlı bulmak istiyorum" | ≤ 150 ms (K-9) |
| **S-11** | "TV'de oynatma takılırsa nedenini görmek istiyorum" | Oturum detayında akış bilgisi + hata kodu |
| **S-12** | "Sunucuyu kapatmak/başlatmak istiyorum" | Ana ekranda tek anahtar, kalıcı bildirim |

---

## 2. MİMARİ — GenPlay Server

### 2.1 Modül grafiği — 17 modül (7 `:feature:`, 9 `:core:`, 1 `:app:`)

```
app.genplay.server  (APK, ~22 MB hedef)
├─ :app:server                    ui + navigation + DI
├─ :feature:setup                 S-1, S-7
├─ :feature:home                  kontrol merkezi
├─ :feature:libraries             S-4
├─ :feature:devices               S-2, S-8, ADB
├─ :feature:settings              S-3, 40 alan
├─ :feature:sessions              S-5
├─ :feature:player                S-6 ← ORTAK, Connect de kullanır
│
├─ :core:server                   Ktor Netty, 25 uç nokta
├─ :core:data                     Room 2.8.1, 19 tablo
├─ :core:scan                     SAF tarayıcı, ad ayrıştırma
├─ :core:deploy  ⭐ YALNIZCA SERVER  ADB-over-TCP
├─ :core:network                  Ktor client + NSD keşif
├─ :core:security                 Argon2id, AES-GCM, HMAC
├─ :core:model                    DTO + SettingSchema
├─ :core:design    ⭐ ORTAK       genplayui.md §9
└─ :core:ui        ⭐ ORTAK       kart, bölüm, odak bileşenleri
```

**Ortak modüller (`:core:player`, `:core:model`, `:core:design`, `:core:ui`) her iki APK'da da derlenir.** Connect'te **12 modül** vardır. Server'a özgü **9 modül**: `:core:server`, `:core:data`, `:core:scan`, `:core:deploy`, `:core:security`, `:feature:setup`, `:feature:libraries`, `:feature:devices`, `:feature:sessions`. Connect'e özgü **3 modül**: `:feature:onboarding`, `:feature:library`, `:feature:details`. Ortak **8 modül**: `:core:design`, `:core:ui`, `:core:model`, `:core:network`, `:core:player`, `:feature:home`, `:feature:player`, `:feature:settings`. Kaynak kodu **tek**, APK'lar **iki**.

### 2.2 Katmanlar — K1…K12

| Katman | İçerik | Kural |
|---|---|---|
| **K1** Veri | Room 19 tablo, DAO | Ana iş parçacığında DB erişimi yasak |
| **K2** Depo | Repository, `Flow` tabanlı | UI asla DAO görmez |
| **K3** Alan | Use-case (saf Kotlin) | Android bağımlılığı yok |
| **K4** Ağ | Ktor server + client | Sıfır kopya akış |
| **K5** Dağıtım | ADB istemcisi | `<1 saniye` durum makinesi adımı |
| **K6** Güvenlik | Crypto, token, HMAC | Anahtar `noBackupFilesDir` |
| **K7** Tarama | SAF + MediaMetadataRetriever | İptal edilebilir |
| **K8** UI | Compose + `:core:design` | `isTv=false` |
| **K9** Navigasyon | type-safe route | Derin bağlantı yok |
| **K10** DI | Koin 4.1.1 | Modül başına tek |
| **K11** Log | Timber 5.0.1 + 3 katman hijyen | Token asla loglanmaz |
| **K12** Ayarlar | `SettingSchema` + DataStore | `config_revision` monotonik |

**KR-1…KR-6 — mimari yasaklar:**

| # | Yasak |
|---|---|
| **KR-1** | `:core:deploy` **yalnızca** `:app:server`'a bağlanabilir — Connect'te bulunamaz |
| **KR-2** | `:core:data` `:core:server`'a bağımlı **olamaz** (ters yön) |
| **KR-3** | UI katmanı `HttpClient` göremez |
| **KR-4** | `System.currentTimeMillis()` iş mantığında kullanılmaz — `Clock` enjekte edilir |
| **KR-5** | `GlobalScope` yasak |
| **KR-6** | `runBlocking` UI thread'de yasak |

### 2.3 Ekran → yetenek matrisi

| Ekran | S-1 | S-2 | S-3 | S-4 | S-5 | S-6 | S-8 | S-9 | S-12 |
|---|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|
| 1 Rol seçici | ● | | | | | | | | |
| 2 İlk kurulum | ● | | | | | | | | |
| 3 Klasör seçimi | ● | | | | | | | ● | |
| 4 Tarama | ● | | | | | | | ● | |
| 5 Ana ekran | | ● | ● | | ● | | | | ● |
| 6 Kütüphaneler | | | | ● | | | | ● | |
| 7 Kütüphane detay | | | | ● | | ● | | ● | |
| 8 Cihazlar | | ● | ● | | | | ● | | |
| 9 Cihaz kurulum | | ● | | | | | ● | | |
| 10 Ayarlar (7 grup) | | | ● | | | | | | |
| 11 Ayar alt sayfa | | | ● | | | | | | |
| 12 Oturumlar | | | | | ● | | ● | | |
| 13 Oynatıcı | | | | | | ● | | | |
| 14 Arama | | | | ● | | ● | | | |

### 2.4 Server'ın HTTP yüzeyi — nerede koşar

| Ayar | Değer | Not |
|---|---|---|
| Motor | **Ktor 3.3.0 + Netty** | CIO değil — Netty daha iyi `Range` |
| Port | **Varsayılan 8471**, kullanıcı değiştirebilir | Y-2: sabit değil, ayarlanabilir |
| Bağlama | `0.0.0.0` (tüm arayüzler) | LAN erişimi için |
| Servis | `GenPlayServerService` | `foregroundServiceType=mediaPlayback|dataSync`, bildirim id 1001 |
| Eşzamanlı akış | **4** | 5.'de `503 TOO_MANY_STREAMS` |
| Buffer | **8 MiB** | `transferTo` için |
| Keep-alive | 30 sn | |
| TLS | **Yok** (LAN, v1) | ⚠️ §6.4'te gerekçe + gelecek planı |

### 2.5 Sıfır kopya akış boru hattı

```
SAF InputStream  →  ParcelFileDescriptor  →  RandomAccessFile
                                                    ↓
                                            FileChannel
                                                    ↓
                                    Ktor respondOutputStream
                                                    ↓
                              FileChannel.transferTo(position, count, channel)
                                                    ↓
                                             TCP soket
```

**Kural:** `ByteArray` tahsisi **yok**. 8 MiB buffer yalnızca `transferTo` desteklemediği durumda (SAF `openFileDescriptor` `null` dönerse) yedek yol olarak kullanılır.

### 2.6 ADB dağıtım yığını — `:core:deploy`

`genplay.md` §11'deki CleanYourTV analizinden çıkan katman. **Saf Kotlin, süreç içi ADB-over-TCP.**

| Bileşen | Sorumluluk |
|---|---|
| `AdbConnection` | TCP, 24-B LE başlık, `CNXN`/`AUTH`/`OPEN`/`OKAY`/`WRTE`/`CLSE` |
| `AdbAuth` | 524-B adbkey (`len=64,n0inv,n,rr,exponent`), `Base64(struct)+" genplay"` |
| `AdbShell` | `shell,v2,raw:` (fail-closed) |
| `AdbSync` | 8-B başlık, push mod 420, `DONE` mtime taşır |
| `AdbExec` | `exec:cmd package install -S <size>` |
| `DeployPlanner` | 7 fazlı plan üretir |
| `PlanJournal` | JSONL, `json+" "+sha256+"\n"`, `force(false)` |
| `RollbackWatchdog` | ⭐ CleanYourTV'de **yok** — GenPlay ekliyor |

**Durum makinesi `[APK-STATIC]` — 7 faz:**

```
F1 Bağlan     TCP → CNXN → AUTH → (anahtar yoksa üret) → OKAY
F2 Doğrula    GETPROP ro.product.cpu.abi · ro.build.version.sdk · ro.serialno
F3 Push       sync: → SEND "genplay-connect-<ver>.apk" → DATA×n → DONE
F4 Kur        exec:cmd package install -S <size>  (1 ≤ size < 209.715.201)
F5 Başlat     shell:am start -n app.genplay.connect/.MainActivity
F6 Enjekte    exec:echo → AUTH_SECRET + sunucu adresi + token
F7 Doğrula    shell:dumpsys package | grep versionCode
```

**Kritik davranış `[APK-STATIC]`:** Her `WRTE` **`OKAY` bekler** (stop-and-wait). `OKAY` atlanırsa 200 MB push **kilitlenir** — bu, CleanYourTV'de doğrulanmış bir tuzak.

**19 `DeployError` türü** (`genplay.md` §11.16) — her biri Türkçe kullanıcı mesajı + çözüm adımı taşır (Y-10).

### 2.7 Veri modeli — 19 tablo (yalnızca Server'da)

| # | Tablo | Sorumluluk |
|---|---|---|
| 1 | `library_folder` | SAF `treeUri` kökleri |
| 2 | `media_item` | Ana katalog, FTS4 katlanmış `sortName` |
| 3 | `media_image` | ImageType → ETag + yerel önbellek yolu |
| 4 | `subtitle_track` | Dil, codec, gömülü/harici |
| 5 | `chapter` | Başlangıç + isim |
| 6 | `collection` | BoxSet |
| 7 | `collection_item` | N:N |
| 8 | `genre` | |
| 9 | `genre_item` | N:N |
| 10 | `person` | |
| 11 | `person_credit` | N:N + rol |
| 12 | `user` | Çoklu kullanıcı (aile) |
| 13 | `home_section` | ⭐ Bölüm sırası, **kullanıcı başına** |
| 14 | `progress` | İlerleme, `PlayedPercentage` |
| 15 | `device` | Connect cihazları |
| 16 | `device_setting` | Cihaz başına ayar geçersiz kılma |
| 17 | `api_token` | **Argon2id hash** (T-3) |
| 18 | `scan_cursor` | Artımlı tarama durumu |
| 19 | `setting` | 40 alan + `config_revision` |

**Kimlik üretimi:** deterministik 128-bit = `sha256(relPath + "|" + fileSize + "|" + mtime)[0..16]` → 32 hex. Yeniden tarama aynı ID'yi üretir.

---

## 3. VERİ AKIŞLARI — Server

### 3.1 Tarama akışı (S-1, S-9)

```
Kullanıcı klasör seçer (SAF)
    ↓  treeUri + persistable permission
ScanWorker (WorkManager, kısıt: pil > %15)
    ↓  MediaStore → SAF DocumentFile yürüyüşü
Ad ayrıştırma (§3.2)
    ↓
media_item upsert (deterministik ID)
    ↓  arka planda: MediaMetadataRetriever (süre, çözünürlük, codec)
    ↓  arka planda: kapak çıkarma (gömülü → yerel önbellek)
Yazma: 500'lük partiler, tek transaction
    ↓
WS: LibraryChanged {ItemsAdded, ItemsUpdated}
    ↓
FTS4 gölge sütun güncelle
```

**İptal edilebilir:** Her 500'lükte `ensureActive()`. İptalde `scan_cursor` kalır, sonraki tarama kaldığı yerden devam eder.

### 3.2 Ad ayrıştırma — Türkçe kuralları

| Kural | Örnek |
|---|---|
| Nokta/alt çizgi → boşluk | `The.Matrix.1999` → `The Matrix 1999` |
| Yıl ayıklama | `(1999)` veya `1999` sonda → `ProductionYear` |
| Kalite etiketleri atılır | `1080p`, `BluRay`, `x264`, `WEB-DL` |
| Sezon/bölüm | `S01E02`, `1x02`, `1. Sezon 2. Bölüm` |
| **Türkçe katlama** | `Ispanak` → arama `ispanak`, `ıhlamur` → arama `ihlamur` |
| **`sortName` üretimi** | `String.lowercase(Locale("tr"))` — **yersiz asla** |

⚠️ **Kritik:** `lowercase()` yersiz çağrılırsa `"ISTIKLAL"` → `"ıstıklal"` (yanlış). Her zaman `Locale("tr")` açık geçirilir. Detekt kuralı ile zorlanır.

### 3.3 Ayar yayını (S-3, K-4)

```
Kullanıcı ayarı değiştirir (telefon)
    ↓  optimistic UI (anahtar anında döner)
debounce 400 ms
    ↓
SettingSchema.isValid(key, value)  →  geçersizse 400 + snackbar
    ↓
setting tablosu upsert + config_revision++
    ↓
WS: SettingsChanged {Revision, Changed:[{Key, Value}]}
    ↓
Connect uygular → ● yeşil onay (WS ack) → telefon ≤ 600 ms'de görür (K-4)
```

**Neden HMAC gerekli `[APK-STATIC]`:** CleanYourTV `signature` korumalı bir broadcast receiver kullanıyor — ama `adb shell am broadcast` **shell UID**'den gelir ve bu koruma **çalışmaz**. Bu yüzden GenPlay canlı ayar için **HMAC-SHA256(key|value|ts)** imzalı mesaj kullanır (ADB `exec:echo` kanalıyla, §2.6 F6).

### 3.4 Çakışma çözümü — `config_revision`

```
Telefon: rev=42, theme=dark yazmak istiyor
Sunucu:  rev=43 (başka bir cihaz black yazdı)
    ↓
409 CONFLICT { currentRevision: 43, changed: {theme: "black"} }
    ↓
Telefonda: "Başka bir cihaz tema ayarını değiştirdi" + [Yine de yaz] [Vazgeç]
```

**Kural:** `readOnly` alanlar (`config_revision`) yazılamaz. `adminOnly` alanlar (`show_file_path`, `log_level`) yalnızca yönetici kullanıcı.

---

## 4. ADB DAĞITIM — kullanıcı akışı

### 4.1 İlk kurulum (S-2)

```
┌────────────────────────────────────────────────────────────────┐
│  ← Cihazlar                                                    │
│                                                                │
│  GenPlay Connect'i TV'nize kurun                              │
│                                                                │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  1  TV'de Geliştirici Seçenekleri'ni açın            ✓   │  │
│  │  2  USB Hata Ayıklama'yı açın                        ✓   │  │
│  │  3  Aynı Wi-Fi ağında olun                           ✓   │  │
│  │  4  TV'nin IP adresini öğrenin                       →   │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                │
│  [ Ağda TV Ara ]        [ IP Gir ]                            │
│                                                                │
│  Bulunan cihazlar                                              │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  📺  Salon TV          192.168.x.x    Android 12         │  │
│  │      Chromecast GTV                    [ Kurulum Yap ]   │  │
│  └──────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────┘
```

**Adımlar 1–3 kullanıcının kendi yapması gereken şeyler** — uygulama bunları **yapamaz** ve **yapmış gibi davranmaz** (Y-10). Onay kutuları kullanıcı işaretler, uygulama doğrulamaz; sadece akışı netleştirir.

### 4.2 Kurulum ilerlemesi — 7 faz

```
F1 Bağlanıyor      ████░░░░░░░░░░░░░░░░  5%
F2 Cihaz doğrulanıyor  ██████░░░░░░░░░░░░░  12%
F3 APK gönderiliyor    ████████████░░░░░░░  48%   8,4 MB / 9,2 MB
F4 Kuruluyor           ███████████████░░░░  85%
F5 Başlatılıyor        ████████████████░░░  92%
F6 Adres iletiliyor    ██████████████████░  96%
F7 Doğrulanıyor        ███████████████████  100%
```

| Kural | Değer |
|---|---|
| Toplam süre hedefi | **≤ 90 sn** (K-3) |
| Yeniden denenebilir fazlar | F1, F3, F7 |
| Geri alınamaz fazlar | F4 (kurulum başladıysa beklenmelidir) |
| Hata | Faz numarası + 19 `DeployError`'dan biri + çözüm |
| Günlük | `PlanJournal` JSONL — her satır `json+" "+sha256` |
| Sürdürülebilir | Uygulama öldürülürse aynı fazdan devam |
| Geri alma | `RollbackWatchdog` — F4 sonrası 60 sn içinde F5 başarısızsa APK kaldırılır |

### 4.3 Kurulum sonrası adres enjeksiyonu (F6)

| Ne gönderilir | Nasıl | Neden güvenli |
|---|---|---|
| Sunucu IP + port | `exec:echo` → Connect `noBackupFilesDir()/bootstrap.json` | LAN içi, tek seferlik |
| `AUTH_SECRET` (32 B) | Aynı kanal, ayrı dosya | ADB kanalı zaten kimlik doğrulanmış |
| Kullanıcı ID | Aynı kanal | |
| Token | **GÖNDERİLMEZ** | Token eşleştirmede (§0.4.4) üretilir — Y-11 |

**Neden token gönderilmiyor:** ADB kanalı ele geçirilirse token da ele geçerdi. Bunun yerine Connect, `AUTH_SECRET` ile **kendi** challenge'ını imzalar → token'ı **hak ederek** alır. Bu, `genplay.md` §11.12'nin temel güvenlik kararıdır.

---

## 5. ARAYÜZ — GenPlay Server (14 ekran)

> Tüm ölçüler `genplayui.md` §4'teki token'lardan gelir. `isTv = false` — telefonda odak halkası **yoktur**, dokunma ve gesture vardır.

### 5.1 Ekran haritası

| # | Ekran | Route | Yetenek |
|---|---|---|---|
| 1 | Rol seçici | `role` | — |
| 2 | İlk kurulum | `setup` | S-1 |
| 3 | Klasör seçimi | `setup/folder` | S-1 |
| 4 | Tarama | `setup/scan` | S-1, S-9 |
| 5 | **Ana ekran** | `home` | S-3, S-5, S-12 |
| 6 | Kütüphaneler | `libraries` | S-4 |
| 7 | Kütüphane detay | `libraries/{id}` | S-4, S-6 |
| 8 | Cihazlar | `devices` | S-2, S-8 |
| 9 | Cihaz kurulum | `devices/{id}/deploy` | S-2 |
| 10 | Ayarlar (7 grup) | `settings` | S-3 |
| 11 | Ayar alt sayfa | `settings/{group}` | S-3 |
| 12 | Oturumlar | `sessions` | S-5 |
| 13 | Oynatıcı | `player/{id}` | S-6 |
| 14 | Arama | `search` | S-10 |

### 5.2 Ekran 5 — Ana ekran (kontrol merkezi)

`genplayui.md` §6.1'deki telefon sırası (5 bölüm) **korunuyor**, ama **Server'ın kendi işlevleri** öne çıkıyor:

```
╔══════════════════════════════════════╗
║  GenPlay Server              ⚙  👤   ║  ← 56 dp
╠══════════════════════════════════════╣
║                                      ║
║  ┌────────────────────────────────┐  ║
║  │  ● Sunucu açık                 │  ║  ← durum kartı 88 dp
║  │  192.168.x.x:8471              │  ║
║  │  3 cihaz · 2 oturum            │  ║
║  │                        [Kapat] │  ║
║  └────────────────────────────────┘  ║
║  16 dp                               ║
║  ── Cihazlar ─────────────  Tümü →   ║  ← SIDE_FOOTER 88 dp
║  ┌────────────────────────────────┐  ║
║  │ 📺 Salon TV        ● bağlı   ›│  ║
║  ├────────────────────────────────┤  ║
║  │ 📺 Yatak Odası     ● bağlı   ›│  ║
║  ├────────────────────────────────┤  ║
║  │ ＋ Yeni cihaz ekle             │  ║
║  └────────────────────────────────┘  ║
║  16 dp                               ║
║  ── Son Eklenenler ───────  Tümü →   ║  ← PORTRAIT 120×180
║  ┌──────┐ ┌──────┐ ┌──────┐         ║
║  │      │ │      │ │      │         ║
║  └──────┘ └──────┘ └──────┘         ║
║  16 dp                               ║
║  ── Tarama ──────────────────────    ║  ← AUTO_WIDTH
║  ┌────────────────────────────────┐  ║
║  │ ↻ Son tarama: 2 saat önce      │  ║
║  │   1.284 öğe · 412 GB           │  ║
║  │                    [Yeniden]   │  ║
║  └────────────────────────────────┘  ║
║  16 dp                               ║
║  ── Kütüphaneler ──────────  Tümü →  ║  ← SIDE_FOOTER 72 dp
║  ┌────────────────────────────────┐  ║
║  │ 🎬 Filmler        742 öğe    ›│  ║
║  │ 📺 Diziler        312 öğe    ›│  ║
║  │ 🎵 Müzik          230 öğe    ›│  ║
║  └────────────────────────────────┘  ║
║  16 dp                               ║
║  ── Devam Et ─────────────  Tümü →   ║  ← BACKDROP 213×120
║  ┌─────────┐ ┌─────────┐             ║
║  │         │ │         │             ║
║  └─────────┘ └─────────┘             ║
╠══════════════════════════════════════╣
║  🏠      📚       📺       ⚙         ║  ← dock 80 dp
║  Ana   Kütüphane  Cihazlar  Ayarlar  ║
╚══════════════════════════════════════╝
```

**Ölçüler:**

| Öğe | Değer | Token |
|---|---|---|
| Durum kartı | 88 dp yükseklik, `radiusMd` | — |
| Durum noktası | 8 dp daire, `primary` / `error` | — |
| Bölüm arası | 16 dp | `space16` |
| Ekran kenarı | 16 dp | `space16` |
| Cihaz satırı | 64 dp | — |
| Dock | 80 dp | `dockHeight` |

**"Sunucu açık/kapalı" anahtarı:** Kapalıyken HTTP yüzeyi **404 döner** ve `GenPlayServerService` durur. Bildirim kalkar. Connect'te "sunucuya ulaşılamıyor" gerçek hatası görünür (Y-10 — sahte "çevrimdışı mod" yok).

### 5.3 Ekran 10 — Ayarlar, 7 grup

`genplayui.md` §8.4'teki yapı **birebir**, ama **Server'ın gruplarıyla**:

```
╔══════════════════════════════════════╗
║  ← Ayarlar                           ║
╠══════════════════════════════════════╣
║  🎨  Görünüm                       › ║  9 alan
║      Tema, palet, kart boyutu,     ║
║      animasyon, yazı boyutu         ║
║  ──────────────────────────────────  ║
║  📡  Sunucu                        › ║  ← SERVER'A ÖZGÜ
║      Port, eşzamanlı akış,         ║
║      keşif, otomatik başlat         ║
║  ──────────────────────────────────  ║
║  🗂  Kütüphane                     › ║  ← SERVER'A ÖZGÜ
║      Klasörler, tarama, dışlama,   ║
║      ad ayrıştırma kuralları        ║
║  ──────────────────────────────────  ║
║  📱  Cihazlar ve Dağıtım           › ║  ← SERVER'A ÖZGÜ
║      ADB, APK sürümü, otomatik      ║
║      güncelleme, cihaz listesi      ║
║  ──────────────────────────────────  ║
║  ▶   Oynatma                       › ║  17 alan (ortak)
║      Altyazı, ses, atlama,          ║
║      ekran koruyucu, hız            ║
║  ──────────────────────────────────  ║
║  🔒  Gizlilik                      › ║  3 alan
║      Günlük seviyesi, dosya yolu,   ║
║      istatistik katmanı             ║
║  ──────────────────────────────────  ║
║  ℹ   Hakkında                      › ║
║      Sürüm, yasak listesi,          ║
║      kanıt dizini, lisanslar        ║
╚══════════════════════════════════════╝
```

**40 alanın 7 gruba dağılımı:**

| Grup | Alan | Sayı |
|---|---|---|
| Görünüm | `theme`, `palette`, `card_size_adjust`, `home_orientation`, `folder_outlines`, `show_runtime_badge`, `focus_preview`, `animations`, `font_scale` | **9** |
| Sunucu ⭐ | `server_port`, `max_streams`, `discovery_enabled`, `boot_autostart`, `language` | **5** |
| Kütüphane ⭐ | `scan_on_start`, `scan_wifi_only`, `hide_played_latest`, `exclude_patterns`, `sort_language` | **5** |
| Cihazlar ⭐ | `auto_update_connect`, `adb_timeout_s`, `keep_orphan_tokens`, `deploy_verify` | **4** |
| Oynatma | `autoplay_next`, `autoplay_delay_ms`, `resume_threshold`, `intro_skip_enabled`, `skip_back_seconds`, `skip_forward_seconds`, `audio_boost`, `refresh_rate_match`, `max_bitrate_mbps`, `subtitle_*` ×8 | **17** |
| Gizlilik | `show_stats_overlay`, `show_file_path`, `log_level` | **3** |
| Sistem | `config_revision` (salt okunur, Hakkında'da gösterilir) | **1** |
| **Toplam** | | **44**  |

⚠️ **Not:** `genplay.md` §11.12'deki 40 alan **temel** kümedir. Server 4 alan **ekler** (`server_port`, `max_streams`, `discovery_enabled`, `scan_wifi_only`) ve Connect bunları **okur ama değiştiremez** (YC-3). Nihai `SettingSchema` **44 alan**. Bu, §0.4.10'daki tabloya **4 satır eklemek** demektir — iki dokümanda birlikte güncellenir.

### 5.4 Ekran 8 — Cihazlar

```
╔══════════════════════════════════════╗
║  ← Cihazlar                   ＋      ║
╠══════════════════════════════════════╣
║  Bağlı cihazlar (2)                  ║
║  ┌────────────────────────────────┐  ║
║  │ 📺  Salon TV                   │  ║  ← 96 dp
║  │     Chromecast GTV · A12       │  ║
║  │     ● şimdi oynatıyor          │  ║
║  │     Son görülme: 12 sn önce    │  ║
║  │                    [Yeniden başlat] [Kaldır] │
║  └────────────────────────────────┘  ║
║  ┌────────────────────────────────┐  ║
║  │ 📺  Yatak Odası                │  ║
║  │     Mi Box S2 · A11            │  ║
║  │     ○ boşta                    │  ║
║  │     Connect 1.0.0              │  ║
║  └────────────────────────────────┘  ║
╠══════════════════════════════════════╣
║  Kurulu değil                        ║
║  ┌────────────────────────────────┐  ║
║  │ ＋ Yeni TV ekle                │  ║
║  │    Ağda ara veya IP gir        │  ║
║  └────────────────────────────────┘  ║
╚══════════════════════════════════════╝
```

**Cihaz satırı ölçüleri:**

| Öğe | Değer |
|---|---|
| Satır yüksekliği | 96 dp (2 satır bilgi + butonlar) |
| İkon | 24 dp |
| Başlık | `titleMedium` 18sp |
| Alt metin | `bodySmall` 12sp, alpha 0.65 |
| Durum noktası | 8 dp |
| Buton yüksekliği | 36 dp |
| Butonlar arası | 8 dp |

**"Kaldır" davranışı:** Onay diyaloğu → cihaz silinir → **token iptal** (T-5) → TV'de bir sonraki istekte `401 UNAUTHORIZED` → TV "Sunucuya bağlanılamıyor, yeniden eşleştirin" gösterir (Y-10, sahte çevrimdışı mod yok).

### 5.5 Ekran 12 — Oturumlar (S-5)

```
╔══════════════════════════════════════╗
║  ← Şu an izleniyor           ⟳      ║
╠══════════════════════════════════════╣
║  ┌────────────────────────────────┐  ║
║  │ 📺 Salon TV  ·  Ahmet          │  ║  ← 120 dp
║  │ ┌──────┐                       │  ║
║  │ │ 16:9 │  Öğe Adı              │  ║
║  │ └──────┘  Doğrudan akış        │  ║
║  │           ▬▬▬▬▬▬░░░░░  42:17   │  ║
║  │           1,4 MB/s · HEVC 4K   │  ║
║  └────────────────────────────────┘  ║
║  16 dp                               ║
║  ┌────────────────────────────────┐  ║
║  │ 📱 Bu telefon  ·  Ahmet        │  ║
║  │ ┌──────┐  Duraklatıldı         │  ║
║  │ │ 16:9 │  ▬▬▬░░░░░░░░  12:03   │  ║
║  └────────────────────────────────┘  ║
╚══════════════════════════════════════╝
```

| Öğe | Değer |
|---|---|
| Kart yüksekliği | 120 dp |
| Küçük görsel | 96 × 54 dp (16:9), `radiusSm` |
| İlerleme çubuğu | 4 dp |
| Tazeleme | WS `Sessions` mesajı + 5 sn fallback |
| Boş durum | "Şu an kimse izlemiyor" + ana ekrana dön |

**Boş durum `[TASARIM]`:** Sahte bir "örnek oturum" **gösterilmez** (Y-1). Gerçek boş durum metni + ikon.

### 5.6 Ortak bileşen kullanımı

| Bileşen | Kaynak | Server'da |
|---|---|---|
| `GenPlayCard` | `genplayui.md` §5.4 | ✅ `isTv=false` |
| `SpotlightCard` | §5.5 | ❌ (telefonda spotlight yok) |
| `SongRow` | §5.6 | ✅ |
| `SectionHeader` | §6.3 | ✅ |
| `ContextMenu` | §8.3 | ✅ 14 eylem |
| `SectionList` | §9.7 | ✅ |
| `CardFocusRing` | §9.8 | ❌ `focusRingWidth = 0` |
| `GenPlayDock` | §7.8 | ✅ **alt dock 80 dp** |

---

## 6. GÜVENLİK — Server

### 6.1 Tehdit modeli — T-1…T-8

| # | Tehdit | Varlık | Azaltma |
|---|---|---|---|
| **T-1** | Aynı Wi-Fi'daki kötü niyetli cihaz | Kütüphane | Token zorunlu, `AUTH_SECRET` ile HMAC eşleştirme |
| **T-2** | Token hırsızlığı | Oturum | Argon2id hash (T-3), `noBackupFilesDir`, loglanmaz (Y-11) |
| **T-3** | ADB kanalı ele geçirme | `AUTH_SECRET` | Token **hiç** gönderilmez (§4.3) |
| **T-4** | Ayar çakışması / kötüye kullanım | 44 alan | `config_revision` + `adminOnly` |
| **T-5** | Path traversal | Dosya sistemi | Yalnızca SAF `treeUri` altındaki dosyalar, `canonicalPath` doğrulaması |
| **T-6** | DRM'li içerik | Yasal risk | `HasDrm=true` → `451 DRM_DETECTED` (Y-8) |
| **T-7** | Log sızıntısı | Token, dosya yolu | 3 katman hijyen: token loglanmaz, yol `show_file_path` arkasında |
| **T-8** | Brute force | Eşleştirme | 3 başarısız → 60 sn kilit (T-8) |

### 6.2 Anahtar yönetimi

| Anahtar | Nerede | Nasıl korunur |
|---|---|---|
| `AUTH_SECRET` | Server | AES-256-GCM, `noBackupFilesDir()/auth.bin`, StrongBox → TEE → yazılım |
| `api_token` (düz) | **Hiçbir yerde** | Yalnızca Argon2id hash DB'de |
| `api_token` (istemci) | Connect | AES-256-GCM, `getNoBackupFilesDir()` |
| DB şifreleme | — | v1: **yok** (LAN, dosya sistemi korumalı). ⚠️ §6.4 |

### 6.3 Log hijyeni — 3 katman

| Katman | Kural |
|---|---|
| L1 — Token | Hiçbir log seviyesinde yazılmaz. `Timber` ağacında `Token` regex maskeleme |
| L2 — Dosya yolu | Yalnızca `show_file_path=true` **ve** yönetici ise |
| L3 — IP adresi | Loglanabilir (LAN), ama `log_level=error` ise yalnızca hata |

### 6.4 Dürüst boşluk — TLS yok

**v1'de HTTP düz metindir.** Gerekçe:

1. LAN içi, RFC 1918 — trafik router'dan çıkmıyor
2. Self-signed sertifika yönetimi kullanıcıya 3 ekran daha yük getiriyor (sertifika üret, pinle, süresi dolunca yenile)
3. Android TV'de özel CA'ya güvenmek zor (Trust Store yönetimi yok)

**Ama bu bir risktir:** aynı Wi-Fi'daki bir saldırgan trafiği **dinleyebilir**. Token `Authorization` başlığında olduğu için ele geçirilebilir.

**Planlanan çözüm (Faz 2):** `AUTH_SECRET`'tan türetilen **pre-shared key TLS** (PSK-TLS) veya self-signed + TOFU pinning. `genplay.md` §32.3 **O-1** açık karar olarak kayıtlı.

**v1'de azaltma:** Kütüphane yalnızca LAN'da, token iptal edilebilir (T-5), 4 eşzamanlı akış sınırı, `HasDrm` reddi.

---

## 7. TEST — Server

### 7.1 Test piramidi

| Katman | Sayı | Araç |
|---|---|---|
| Birim (`:core:*`) | ~420 | JUnit 5.13.4 + Turbine 1.2.1 |
| DAO / Room | ~60 | `Room.inMemoryDatabaseBuilder` |
| HTTP sözleşme | ~85 | Ktor `testApplication` |
| WebSocket | ~24 | Ktor `testApplication` + WS client |
| ADB (sahte soket) | ~40 | Sahte `ServerSocket` — **sahte ADB sunucusu**, gerçek cihaz değil |
| Compose UI | ~95 | `createComposeRule` |
| Görsel regresyon | 63 | Roborazzi (7 şekil × 9 kombinasyon) |
| **Toplam** | **~787** | |

### 7.2 Zorunlu testler — T-01…T-20 (Server)

| ID | Ne | Kaynak |
|---|---|---|
| **T-01** | `Range: bytes=0-` → `206` + doğru `Content-Range` | §0.4.7 |
| **T-02** | `Range: bytes=N-` → `416` | §0.4.7 |
| **T-03** | Çoklu aralık → `200` tam gövde | §0.4.7 |
| **T-04** | `If-Range` ETag uyuşmaz → `200` | §0.4.7 |
| **T-05** | Token yok → `401` | §0.4.3 |
| **T-06** | İptal token → `401` | T-5 |
| **T-07** | `pair/challenge` 15 sn sonra `410 Gone` | T-7 |
| **T-08** | 3 başarısız `confirm` → 60 sn kilit | T-8 |
| **T-09** | `HasDrm=true` → `451` | Y-8 |
| **T-10** | 5. eşzamanlı akış → `503` + `Retry-After` | §2.4 |
| **T-11** | WS `Identity` olmadan başka mesaj → `1008` | §0.4.8 |
| **T-12** | `SettingsChanged` sonrası `config_revision` artar | §3.3 |
| **T-13** | Eski `revision` ile yazma → `409` | §3.4 |
| **T-14** | `adminOnly` alan yönetici olmayan → `403` | §3.4 |
| **T-15** | `resolveCardShape` asla `BANNER`/`SMALL_SIDE_FOOTER`/`THUMB` döndürmez | §0.4.9 |
| **T-16** | 3 katmanlı şekil önceliği (kullanıcı > veri > varsayılan) | §0.4.9 |
| **T-17** | Deterministik ID: aynı dosya iki taramada aynı ID | §2.7 |
| **T-18** | Türkçe arama: `"Ispanak"` → `"ispanak"`, `"ıhlamur"` → `"ihlamur"` | §3.2 |
| **T-19** | Tarama iptal → `scan_cursor` korunur | §3.1 |
| **T-20** | Path traversal `../../etc/passwd` → `404` | T-5 |

### 7.3 K-16 çelişkisi — dürüst not

**K-16 "çökme oranı ≤ %0,1" ölçülemez**, çünkü Y-4 telemetri yasağı var. Çözüm:

| Ne | Nasıl |
|---|---|
| Yerel çökme günlüğü | `CrashLog` — son 20 çökme, `filesDir/crashes.jsonl` |
| Kullanıcı dışa aktarır | Ayarlar → Hakkında → "Tanılama paketini paylaş" (kullanıcı **kendi** seçer) |
| Sunucuya **gönderilmez** | Y-4 |
| Kabul | "Sürüm adayı 8 cihazda 7 senaryo × 2 saat, sıfır çökme" |

### 7.4 CI kapıları

| Kapı | Komut | Eşik |
|---|---|---|
| Format | `ktlintCheck` | 0 hata |
| Statik | `detekt` | 0 hata, `Locale` kuralı ✅ |
| Yasak denetimi | `forbidden-literals.sh` | Y-1…Y-12 **12/12** |
| APK hijyeni | `apk-hygiene.sh` | `assets/` temiz, `lib/` boş (Y-3, Y-7) |
| **Ortak sözleşme** | `diff <(sed -n '/### 0.4/,/^## 1/p' genplay-server.md) <(sed -n '/### 0.4/,/^## 1/p' genplay-connect.md)` | **boş çıktı** |
| Test | `test` | Hepsi geçer |
| Kapsam | `jacocoTestReport` | `:core:*` ≥ %80 |
| Boyut | `stat` | ≤ 25 MB (K-11) |

---

## 8. PROMPT KULLANIM KURALLARI

### 8.1 Nasıl kullanılır

| Adım | Ne |
|---|---|
| 1 | `PROMPT 0`'ı **hiç değiştirmeden** ajana ver |
| 2 | Sonra `PROMPT 1`…`PROMPT 8`'i **sırayla** ver |
| 3 | Her prompt biterken **kabul kriterlerini** ajan kendisi kontrol eder |
| 4 | Başarısız olursa prompt'u **tekrar verme** — hatayı prompt'a ekle |

### 8.2 Prompt → bölüm eşleme

| # | Prompt | Konum | Ana bölümler | Modüller | Süre |
|---|---|---|---|---:|---|
| **0** | Master sözleşme | §9.1 | 0.4 (paylaşılan), 1, 2 | tümü | — |
| **1** | İskelet + ortak çekirdek | §9.2 | 2.1, 2.2, `:core:design` | `build-logic`, `:core:model`, `:core:design`, `:core:ui` | 3 gün |
| **2** | Veri + tarama | §9.3 | 2.7, 3.1, 3.2 | `:core:data`, `:core:scan` | 4 gün |
| **3** | HTTP + Range + akış | §9.4 | 0.4.3–0.4.7, 2.4, 2.5 | `:core:server` | 4 gün |
| **4** | WS + eşleştirme + güvenlik | §9.5 | 0.4.4, 0.4.8, 6 | `:core:security`, `:core:server` | 3 gün |
| **5** | ⭐ ADB dağıtım | §9.6 | 2.6, 4 | `:core:deploy` | 4 gün |
| **6** | ⭐ Ayar motoru + canlı yayın | §9.7 | 0.4.10, 3.3, 3.4 | `:core:data`, `:feature:settings` | 3 gün |
| **7** | Server arayüzü (14 ekran) | §9.8 | 5 | `:feature:*` | 4 gün |
| **8** | Test + sertleştirme + sürüm | §9.9 | 7, 8.3 | `benchmark`, CI | 3 gün |
| | | | | **Toplam** | **28 gün** |

### 8.3 Sürüm kontrol listesi — 24 madde

| # | Kontrol |
|---|---|
| 1 | `forbidden-literals.sh` 12/12 ✅ |
| 2 | `apk-hygiene.sh` — `assets/` boş, `lib/` boş |
| 3 | APK ≤ 25 MB (K-11) |
| 4 | Kapsam `:core:*` ≥ %80 (K-15) |
| 5 | Sözleşme `diff` boş (§7.4) |
| 6 | `Range` 8 senaryo ✅ (T-01…T-04) |
| 7 | Eşleştirme 4 senaryo ✅ (T-07, T-08) |
| 8 | ADB kurulum ≤ 90 sn **gerçek TV'de** (K-3) |
| 9 | Ayar yayını ≤ 600 ms **gerçek TV'de** (K-4) |
| 10 | 44 alan `SettingSchema` doğrulaması |
| 11 | `config_revision` çakışma 3 senaryo ✅ |
| 12 | Türkçe arama 20 kelime ✅ |
| 13 | Tarama iptal + devam ✅ |
| 14 | Sıfır kopya akış — `ByteArray` tahsisi yok (kod incelemesi) |
| 15 | Token hiçbir logda yok (grep) |
| 16 | `AUTH_SECRET` `noBackupFilesDir`'da |
| 17 | 8 cihazda 7 senaryo **elle** (2 saat) |
| 18 | Düşük pil kısıtı (`scan_wifi_only`) ✅ |
| 19 | Ekran döndürme tüm ekranlarda ✅ |
| 20 | Karanlık/aydınlık/AMOLED **3 palet × 3 mod = 9** ✅ |
| 21 | TalkBack tüm düğmelerde ✅ |
| 22 | `reduce_motion` ✅ |
| 23 | 20 çökme günlüğü testi (kasıtlı çökme) |
| 24 | Kanıt dizini `evidence/server/` dolu |

---

## 9. PROMPTLAR — GenPlay Server

### 9.1 PROMPT 0 — Master sistem sözleşmesi

```
Sen GenPlay Server'ı yazacak kıdemli bir Android geliştiricisisin.
Bu proje TEK bir uygulamadır: app.genplay.server.

═══════════════════════════════════════════════════════════════
BAĞLAM
═══════════════════════════════════════════════════════════════
GenPlay iki uygulamadan oluşur:
  • GenPlay SERVER (bu proje)  — telefonda, kütüphaneyi barındırır
  • GenPlay CONNECT            — TV'de, kütüphaneyi tüketir

Server şunları YAPAR:
  1. SAF treeUri ile medya klasörünü indeksler (19 Room tablosu)
  2. Ktor Netty ile 25 uç noktalı HTTP + WebSocket sunar
  3. Range/206 destekli sıfır kopya akış verir
  4. Saf Kotlin ADB-over-TCP ile Connect'i TV'lere kurar
  5. 44 alanlık ayarı TV'lere canlı yayınlar
  6. Kendi kütüphanesini telefonda oynatır

Server şunları YAPMAZ:
  × İnternete çıkmaz         × Hesap/abonelik yok
  × Transcoding yapmaz       × DRM çözmez (reddeder)
  × Cast yapmaz              × Bulut yedek yok
  × Telemetri toplamaz       × Reklam yok

═══════════════════════════════════════════════════════════════
DEĞİŞTİRİLEMEZ 12 YASAK  (Y-1…Y-12) — HER PR'DA CI DENETLER
═══════════════════════════════════════════════════════════════
Y-1  Demo modu yok    — kodda demo/sample/mock/fake/dummy/lorem geçmez
Y-2  Sabit IP/port yok — 192.168.*, 10.*, :8096, :8080 literal yasak
Y-3  Test medyası yok  — assets/ içinde örnek video/ses/görsel yok
Y-4  İnternet yok      — istek sadece RFC1918 + link-local + loopback
Y-5  Hesap yok         — kayıt/giriş/e-posta/abonelik/lisans yok
Y-6  Cast yok          — Cast/DLNA/UPnP/Miracast/AirPlay yok
Y-7  Transcoding yok   — ffmpeg/ffprobe/HLS segment yok
Y-8  DRM kırma yok     — HasDrm=true → 451 DRM_DETECTED
Y-9  Boş tık yok       — işlevsiz düğme/menü/ayar yok
Y-10 Sahte başarı yok  — hata varsa gerçek sebep, "tamamlandı" yalanı yasak
Y-11 Token sızıntısı yok — token sadece Authorization başlığında
Y-12 Sabit demo config yok — varsayılan adres/kullanıcı/hemen-dene yok

PLATFORMA ÖZGÜ EK YASAKLAR
YS-1  Dosya okuma yalnızca SAF treeUri ile — READ_EXTERNAL_STORAGE geniş izni YOK
YS-2  Token düz metin SharedPreferences'a YAZILMAZ

═══════════════════════════════════════════════════════════════
MİMARİ — 12 KATMAN (K1…K12) + 6 YASAK (KR-1…KR-6)
═══════════════════════════════════════════════════════════════
K1  Veri        Room 2.8.1, 19 tablo — ana thread'de DB erişimi yasak
K2  Depo        Repository, Flow — UI asla DAO görmez
K3  Alan        Use-case, saf Kotlin — Android bağımlılığı yok
K4  Ağ          Ktor 3.3.0 server+client — sıfır kopya akış
K5  Dağıtım     ADB istemcisi — durum makinesi < 1 sn/adım
K6  Güvenlik    Argon2id, AES-256-GCM, HMAC-SHA256
K7  Tarama      SAF + MediaMetadataRetriever — iptal edilebilir
K8  UI          Compose + :core:design — isTv = false
K9  Navigasyon  type-safe route
K10 DI          Koin 4.1.1
K11 Log         Timber 5.0.1 + 3 katman hijyen
K12 Ayarlar     SettingSchema 44 alan + DataStore, config_revision

KR-1 :core:deploy yalnızca :app:server'a bağlanır
KR-2 :core:data :core:server'a bağımlı olamaz
KR-3 UI katmanı HttpClient göremez
KR-4 System.currentTimeMillis() iş mantığında yasak — Clock enjekte
KR-5 GlobalScope yasak
KR-6 runBlocking UI thread'de yasak

═══════════════════════════════════════════════════════════════
SABİT SÜRÜMLER — DEĞİŞTİRME
═══════════════════════════════════════════════════════════════
agp 8.13.0 · kotlin 2.2.20 · compose-bom 2025.10.00 · ktor 3.3.0
media3 1.8.0 · room 2.8.1 · dadb 1.2.9 · okio 3.16.0
coroutines 1.10.2 · serialization 1.9.0 · datastore 1.1.7
coil 3.3.0 · koin 4.1.1 · timber 5.0.1 · work 2.10.5
junit5 5.13.4 · turbine 1.2.1 · mockk 1.14.5
minSdk 24 · targetSdk 37 · compileSdk 37

═══════════════════════════════════════════════════════════════
TASARIM SİSTEMİ — genplayui.md'den, DEĞİŞTİRİLEMEZ
═══════════════════════════════════════════════════════════════
• 3 palet (genplay/sinema/orman) × 3 mod (dark/light/amoled) = 9
• Rubik variable font, 15 tipografi token'ı
• 9 boşluk, 6 yarıçap, 6 motion token'ı
• 7 kart şekli üretiliyor (PORTRAIT/SQUARE/BACKDROP/FOUR_THREE/
  SIDE_FOOTER/SPOTLIGHT/AUTO_WIDTH)
• Tek GenPlayCard bileşeni tüm şekilleri çizer
• isTv = false → odak halkası YOK, dokunma + gesture VAR
• reduce_motion açıksa tüm süreler 0

═══════════════════════════════════════════════════════════════
DİL KURALI — KRİTİK
═══════════════════════════════════════════════════════════════
• Kullanıcıya görünen her metin TÜRKÇE
• Kod, değişken, sınıf adları İNGİLİZCE
• Hata mesajları kullanıcıya gösterilebilir ve GERÇEK olmalı (Y-10)
• lowercase()/uppercase()/compareTo() HER ZAMAN Locale açık alır
  Yanlış: "ISTIKLAL".lowercase()        → "ıstıklal"
  Doğru:  "ISTIKLAL".lowercase(Locale("tr")) → "istiklal"

═══════════════════════════════════════════════════════════════
YANIT FORMATI
═══════════════════════════════════════════════════════════════
Her görev için:
1. Ne yaptığını 1-2 cümle
2. Tam dosya yolu + tam dosya içeriği (kısaltma YOK, "..." YOK)
3. Bu görevin kabul kriterlerini nasıl karşıladığı (madde madde)
4. Y-1…Y-12'den hangilerinin bu dosyada risk altında olduğu
5. Sonraki göreve geç

KURAL: Dosya içeriğini asla "benzer şekilde devam eder" diye kısaltma.
Her dosya TAM olarak yazılır.
```

### 9.2 PROMPT 1 — İskelet + ortak çekirdek

```
GÖREV 1 — Proje iskeleti ve :core:design modülü

BAĞLAM
Server, Connect ile AYNI tasarım sistemini kullanmak zorunda.
:core:design ve :core:ui modülleri İKİ APK'da da derlenir.
Bu yüzden bu modüllerde Android'e özgü hiçbir şey olmaz —
saf Compose Multiplatform uyumlu kod.

GÖREVLER
1.1  Gradle iskeleti: build-logic/convention ile 7 convention plugin
     (android-app, android-library, compose, ktor-server, room, koin, test)
1.2  version catalog: gradle/libs.versions.toml — 23 sabit sürüm (yukarıda)
1.3  Modül ağacı: §2.1'deki 17 modülü oluştur, bağımlılıkları KR-1…KR-6'ya uygun bağla
1.4  :core:design — genplayui.md §9'un TAMAMI:
     - Color.kt: 3 palet enum + ThemeMode enum + colorSchemeFor() + tonal()
     - Type.kt: Rubik variable font, genPlayTypography(isTv) 15 token
     - Dimens.kt: GenPlaySpacing, TvSpacing, PhoneSpacing
     - Motion.kt: GenPlayMotion.forPlatform(isTv, reduceMotion) + reduceMotionEnabled()
     - GenPlayTheme.kt: CompositionLocal sağlayıcı (LocalIsTv, LocalSpacing,
       LocalMotion, LocalCardDensity, LocalInfoMode, LocalGenPlayColors)
     - token/CardShape.kt: 10 enum değeri
     - token/CardDensity.kt: TvPortrait…PhoneAutoWidth, 7 şekil × 2 platform
1.5  rubik_variable.ttf dosyasını res/font/ altına yerleştir
     (variable font, tek dosya, 356 KB — 6 statik dosya YASAK)
1.6  :core:model — saf Kotlin, Android bağımlılığı YOK:
     - §0.4.6 MediaItem DTO (kotlinx.serialization)
     - §0.4.9 SectionType enum (12 değer)
     - §0.4.10 SettingSchema (44 alan) + SettingDef + isValid()
     - resolveCardShape() — 3 katmanlı öncelik, saf fonksiyon
1.7  :core:ui — GenPlayCard + SectionHeader + SongRow + ContextMenu
     (genplayui.md §5.4, §5.6, §6.3, §8.3 birebir)
1.8  CI: GitHub Actions — ktlint + detekt + forbidden-literals.sh +
     apk-hygiene.sh + test + jacoco
1.9  forbidden-literals.sh: Y-1…Y-12 için 12 ayrı grep, her biri
     başarısızsa exit 1 + hangi kural ihlal edildiği
1.10 detekt.yml: Locale kuralı (lowercase/uppercase/compareTo yersiz çağrı)

KABUL KRİTERLERİ
□ ./gradlew :core:design:build başarılı
□ ./gradlew :core:model:test başarılı — resolveCardShape 1000 örnek, asla BANNER dönmez
□ forbidden-literals.sh 12/12 geçer
□ GenPlayTheme(LocalIsTv=false) ile PhoneSpacing uygulanıyor, focusRingWidth=0
□ 3 palet × 3 mod = 9 ColorScheme üretiliyor, hepsi derleniyor
□ Hiçbir dosyada "demo", "mock", "sample", "fake" geçmiyor
□ Rubik font 356 KB ± 20 KB, tek .ttf dosyası

RİSK ALTINDAKİ YASAKLAR: Y-1 (demo), Y-2 (sabit IP), Y-9 (boş tık)
```

### 9.3 PROMPT 2 — Veri + tarama

```
GÖREV 2 — Room 19 tablo, DAO'lar, SAF tarama, Türkçe ad ayrıştırma

GÖREVLER
2.1  §2.7'deki 19 tabloyu Room @Entity olarak yaz. Tam DDL:
     - media_item: 41 sütun (MediaItem DTO'nun tamamı + yerel alanlar)
     - FTS4 sanal tablo: media_item_fts(sortName, name) + gölge sütun
     - home_section: userId + position + sectionType + cardShapeOverride
     - api_token: token_hash (Argon2id), device_id, revoked_at
     - setting: key, value, config_revision
2.2  Deterministik ID: sha256(relPath|fileSize|mtime)[0..16] → 32 hex
     Aynı dosya iki taramada AYNI ID üretmeli (T-17)
2.3  DAO'lar: MediaItemDao, HomeSectionDao, SettingDao, TokenDao,
     ScanCursorDao, ProgressDao, SessionDao — hepsi Flow döner
2.4  :core:scan — ScanWorker (WorkManager 2.10.5):
     - Kısıt: pil > %15, (scan_wifi_only=true ise) Wi-Fi
     - SAF DocumentFile yürüyüşü, 500'lük partiler
     - Her 500'de ensureActive() — iptal edilebilir (T-19)
     - scan_cursor kaldığı yerden devam
2.5  Ad ayrıştırma (§3.2):
     - Nokta/alt çizgi → boşluk
     - Yıl, sezon/bölüm, kalite etiketi ayıklama
     - Türkçe katlama: "Ispanak"→"ispanak", "ıhlamur"→"ihlamur"
     - sortName = name.lowercase(Locale("tr"))  ← Locale ZORUNLU
2.6  MediaMetadataRetriever ile süre/çözünürlük/codec (arka plan, batch 20)
2.7  Gömülü kapak çıkarma → media_image yerel önbellek (max 512 px, WebP)

KABUL KRİTERLERİ
□ 19 tablo şeması §9.5 DDL ile birebir
□ T-17: aynı dosya iki taramada aynı ID
□ T-18: "Ispanak"→"ispanak", "ıhlamur"→"ihlamur" testleri geçer
□ T-19: tarama iptal → scan_cursor korunur, devam eder
□ 5.000 öğelik test verisi 90 sn'de taranır (benchmark)
□ Hiçbir DAO ana thread'de çağrılmıyor (detekt kuralı)

RİSK ALTINDAKİ YASAKLAR: Y-1 (sample data yok), Y-3 (assets'te medya yok)
```

### 9.4 PROMPT 3 — HTTP sunucu + Range + sıfır kopya akış

```
GÖREV 3 — Ktor Netty, 25 uç nokta, Range/206, akış boru hattı

GÖREVLER
3.1  Ktor 3.3.0 + Netty, port varsayılan 8471 (ayarlanabilir — Y-2)
     GenPlayServerService: foregroundServiceType=mediaPlayback|dataSync,
     bildirim id 1001
3.2  §0.4.3'teki 25 uç noktayı route olarak yaz
3.3  Range/206 — §0.4.7 şartnamesinin 8 senaryosu birebir:
     - bytes=0- → 206, Content-Range: bytes 0-{N-1}/{N}
     - bytes=a-b → 206, Content-Length: b-a+1
     - bytes=N- → 416, Content-Range: bytes */{N}
     - bytes=-k (suffix) → 206, son k bayt
     - çoklu aralık → 200 tam gövde
     - If-Range ETag uyuşmaz → 200
     - HEAD → 200, gövde yok, Content-Length + Accept-Ranges
     - Accept-Ranges: bytes HER ZAMAN gönderilir
3.4  Sıfır kopya akış (§2.5):
     ParcelFileDescriptor → RandomAccessFile → FileChannel.transferTo()
     ByteArray tahsisi YOK. 8 MiB buffer yalnızca SAF fallback'te.
     İlk bayt ≤ 120 ms (K-6)
3.5  Eşzamanlı akış sınırı 4 — 5.'de 503 TOO_MANY_STREAMS + Retry-After
3.6  Hata gövdesi: {code, message, param, retryAfter}
     message TÜRKÇE ve kullanıcıya gösterilebilir (Y-10)
3.7  Path traversal koruması: canonicalPath treeUri altında mı kontrol
3.8  DRM reddi: HasDrm=true → 451 DRM_DETECTED (Y-8)
3.9  ETag: ImageTags'tan, If-None-Match → 304
3.10 :core:network — Ktor client (Connect ile aynı DTO'lar)

KABUL KRİTERLERİ
□ T-01…T-04 (Range 4 senaryo) geçer
□ T-05, T-06 (401) geçer
□ T-09 (451 DRM) geçer
□ T-10 (503 akış sınırı) geçer
□ T-20 (path traversal 404) geçer
□ İlk bayt ≤ 120 ms, 100 MB dosyada (K-6)
□ ByteArray tahsisi yok — kod incelemesinde transferTo görünüyor
□ curl -r 0-1023 → 206 + doğru Content-Range

RİSK ALTINDAKİ YASAKLAR: Y-2 (sabit port), Y-4 (internet), Y-7 (transcode), Y-8 (DRM)
```

### 9.5 PROMPT 4 — WebSocket + eşleştirme + güvenlik

```
GÖREV 4 — WS protokolü, T-1…T-9 eşleştirme, anahtar yönetimi

GÖREVLER
4.1  /api/v1/ws — §0.4.8 birebir:
     - Identity ilk mesajda (URL'de token YOK — Y-11)
     - IdentityAck: SessionId, ServerVersion, Api, Capabilities, KeepAliveSeconds=30
     - IdentityReject → 1008 Policy Violation ile kapat (HTTP 401 DEĞİL)
     - Zarf: MessageType + MessageId (ULID 26 karakter) + ServerTime + Data
     - 5 mesaj tipi: LibraryChanged, UserDataChanged, Sessions,
       SettingsChanged, KeepAlive/Ack
4.2  ULID üretimi: Crockford base32, zaman sıralı, 26 karakter
4.3  Eşleştirme §0.4.4 / T-1…T-9:
     - challenge: 32 bayt rastgele, base64url, 15 sn TTL (T-7)
     - confirm: HMAC-SHA256(challenge‖nonce, AUTH_SECRET) doğrula
     - token: 256-bit rastgele base64url 43 karakter, '=' yok (T-1)
     - DB'ye Argon2id HASH yaz, düz token YAZMA (T-3)
     - expiresAt: null, revoked_at var (T-4)
     - 3 başarısız confirm → 60 sn kilit (T-8)
     - Onay diyaloğu TELEFONDA gösterilir (T-9) — Compose dialog
4.4  AUTH_SECRET: 32 bayt, AES-256-GCM ile noBackupFilesDir()/auth.bin
     Anahtar hiyerarşisi: StrongBox → TEE → yazılım
4.5  Log hijyeni 3 katman (§6.3): Timber ağacında token regex maskeleme
4.6  Token doğrulama middleware: her ✓ uç noktada Authorization: Bearer
     Başarısız/iptal → 401

KABUL KRİTERLERİ
□ T-07 (challenge 15 sn TTL) geçer
□ T-08 (3 başarısız → 60 sn kilit) geçer
□ T-11 (Identity olmadan mesaj → 1008) geçer
□ Token DB'de Argon2id hash — düz metin yok (SQL sorgusuyla doğrula)
□ Token hiçbir log satırında yok (grep -r ile doğrula)
□ AUTH_SECRET noBackupFilesDir'da, AES-GCM şifreli
□ WS 30 sn keep-alive, bağlantı 2 saat açık kalır

RİSK ALTINDAKİ YASAKLAR: Y-11 (token sızıntısı), YS-2 (düz metin token)
```

### 9.6 PROMPT 5 — ADB dağıtım yığını

```
GÖREV 5 — Saf Kotlin ADB-over-TCP, 7 fazlı dağıtım, geri alma

BAĞLAM
Bu, CleanYourTV 0.4.5'in kanıtlanmış yöntemidir. `adb` binary'si YOK,
Shizuku YOK, root YOK. Saf Kotlin soket protokolü.

GÖREVLER
5.1  AdbConnection — TCP, 24-Bayt LE başlık:
     CNXN=0x4e584e43 AUTH=0x48545541 OPEN=0x4e45504f OKAY=0x59414b4f
     CLSE=0x45534c43 WRTE=0x45545257 SYNC=0x434e5953 STLS=0x534c5453
     banner "host::\0", checksum = Σpayload (unsigned), magic = cmd xor -1
5.2  AdbAuth — 524-B adbkey:
     len=64, n0inv, n[64], rr[64], exponent
     keyString = Base64(struct) + " genplay"
     AUTH token tam 20 bayt
5.3  AdbShell — "shell,v2,raw:" (fail-closed: desteklenmiyorsa hata)
5.4  AdbSync — 8-B başlık, push mod 420, DONE mtime taşır
5.5  AdbExec — "exec:cmd package install -S <size>" (1 ≤ size < 209715201)
5.6  KRİTİK: Her WRTE OKAY bekler (stop-and-wait). OKAY atlanırsa
     200 MB push KİLİTLENİR. Bu doğrulanmış bir tuzaktır.
5.7  DeployPlanner — 7 faz (§2.6):
     F1 Bağlan · F2 Doğrula · F3 Push · F4 Kur · F5 Başlat
     F6 Enjekte · F7 Doğrula
5.8  F6 adres enjeksiyonu (§4.3):
     - Sunucu IP+port → bootstrap.json
     - AUTH_SECRET (32 B) → ayrı dosya
     - Kullanıcı ID
     - TOKEN GÖNDERİLMEZ (Y-11) — Connect kendi challenge'ını imzalar
5.9  PlanJournal — JSONL, her satır: json + " " + sha256(json) + "\n",
     force(false). Uygulama öldürülürse aynı fazdan devam
5.10 RollbackWatchdog — F4 sonrası 60 sn içinde F5 başarısızsa APK kaldır
     (CleanYourTV'de bu YOK — GenPlay ekliyor)
5.11 19 DeployError türü, her biri TÜRKÇE mesaj + çözüm adımı (Y-10)
5.12 NSD keşif: _genplay-connect._tcp (opsiyonel, IP elle de girilebilir)

KABUL KRİTERLERİ
□ Sahte ADB sunucusuna karşı 40 test geçer (gerçek cihaz gerekmez)
□ Gerçek Chromecast GTV'ye kurulum ≤ 90 sn (K-3)
□ Push 100 MB'ta kilitlenmiyor (OKAY stop-and-wait doğru)
□ PlanJournal'dan kesintiden sonra devam edilebiliyor
□ RollbackWatchdog: F5 başarısızsa APK kaldırılıyor
□ 19 DeployError'ın hepsi Türkçe mesaj taşıyor
□ Token ADB kanalından GEÇMİYOR (kod incelemesi)

RİSK ALTINDAKİ YASAKLAR: Y-2 (sabit IP), Y-10 (sahte başarı), Y-11 (token)
```

### 9.7 PROMPT 6 — Ayar motoru ve canlı yayın

```
GÖREV 6 — 44 alanlık SettingSchema, config_revision, canlı yayın

GÖREVLER
6.1  §0.4.10'daki 44 alanı + Server'a özgü 4 alanı uygula:
     server_port, max_streams, discovery_enabled, scan_wifi_only
6.2  SettingDef: key, type (BOOL/INT/ENUM/STRING), default, range,
     options, readOnly, adminOnly, requiresRestart
6.3  isValid(key, value) — her tip için tam doğrulama
     Geçersizse 400 {code:"INVALID_SETTING", message, param}
6.4  config_revision monotonik artan (K12)
6.5  Çakışma çözümü (§3.4): eski revision ile yazma → 409 CONFLICT
     {currentRevision, changed} → telefonda "Başka bir cihaz değiştirdi"
     + [Yine de yaz] [Vazgeç]
6.6  Canlı yayın (§3.3):
     optimistic UI → 400 ms debounce → DB yaz → revision++ →
     WS SettingsChanged → Connect uygular → ack → ≤ 600 ms (K-4)
6.7  requiresRestart=3 alan (boot_autostart, language, log_level):
     değişince "Yeniden başlatma gerekli" banner'ı
6.8  adminOnly=2 alan (show_file_path, log_level):
     yönetici olmayan kullanıcı → 403
6.9  DataStore 1.1.7 ile yerel önbellek, sunucu ile senkron
6.10 Ayar ekranı: 7 grup (§5.3), her grup alt sayfa, 44 alan
     Compose ListItem + Switch + Slider + enum radio
     D-pad YOK (telefon) — dokunma

KABUL KRİTERLERİ
□ T-12 (revision artar) geçer
□ T-13 (eski revision → 409) geçer
□ T-14 (adminOnly → 403) geçer
□ K-4: gerçek TV'de dokunuş → uygulanmış ≤ 600 ms
□ 44 alanın hepsi doğrulanıyor, geçersiz değer 400 dönüyor
□ requiresRestart 3 alan banner gösteriyor
□ Ayar ekranı 7 grup, her alan erişilebilir

RİSK ALTINDAKİ YASAKLAR: Y-9 (işlevsiz ayar yok), Y-10 (sahte başarı)
```

### 9.8 PROMPT 7 — Server arayüzü (14 ekran)

```
GÖREV 7 — 14 ekran, :core:design token'larıyla, tutarlı

GÖREVLER
7.1  Navigasyon: type-safe route, 14 ekran (§5.1)
7.2  Ekran 1 — Rol seçici: "Server" / "Connect" — bu APK'da sadece Server
7.3  Ekran 2 — İlk kurulum: 3 adım (hoş geldin, kullanıcı adı, klasör seç)
7.4  Ekran 3 — Klasör seçimi: SAF OPEN_DOCUMENT_TREE, kalıcı izin
7.5  Ekran 4 — Tarama: ilerleme çubuğu, öğe sayısı, iptal butonu
7.6  Ekran 5 — ANA EKRAN (§5.2): 5 bölüm
     - Durum kartı (sunucu açık/kapalı, IP:port, cihaz+oturum sayısı)
     - Cihazlar (SIDE_FOOTER 88 dp)
     - Son Eklenenler (PORTRAIT 120×180)
     - Tarama (AUTO_WIDTH)
     - Kütüphaneler (SIDE_FOOTER 72 dp)
     - Devam Et (BACKDROP 213×120)
     - Alt dock 80 dp, 4 sekme
7.7  Ekran 6/7 — Kütüphaneler + kütüphane detayı (portrait ızgara 3 sütun)
7.8  Ekran 8 — Cihazlar (§5.4): 96 dp satır, durum noktası, kaldır butonu
7.9  Ekran 9 — Cihaz kurulum (§4.1–4.2): 7 fazlı ilerleme + 19 hata
7.10 Ekran 10/11 — Ayarlar 7 grup + alt sayfalar (§5.3, 44 alan)
7.11 Ekran 12 — Oturumlar (§5.5): 120 dp kart, boş durum gerçek
7.12 Ekran 13 — Oynatıcı: :core:player'dan, OSD 6 sekme (Connect ile AYNI)
7.13 Ekran 14 — Arama: FTS4, 300 ms debounce, sonuç ızgarası

TUTARLILIK KURALLARI
• Her ekran GenPlayTheme içinde
• Hiçbir sabit renk yok — hepsi MaterialTheme.colorScheme veya LocalGenPlayColors
• Hiçbir sabit dp yok — hepsi LocalSpacing
• Boş durumlar GERÇEK (Y-1): "Henüz kütüphane yok" + [Klasör Ekle]
• Sahte içerik YASAK: örnek film adı, örnek kullanıcı adı yok

KABUL KRİTERLERİ
□ 14 ekranın hepsi açılıyor, geri tuşu doğru çalışıyor
□ 3 palet × 3 mod = 9 kombinasyonda hepsi okunabilir (kontrast testi)
□ Ekran döndürme tüm ekranlarda state koruyor
□ TalkBack her düğmeyi okuyor
□ Boş durumlarda sahte içerik yok (Y-1)
□ Hiçbir ekran sabit dp/renk kullanmıyor

RİSK ALTINDAKİ YASAKLAR: Y-1 (demo), Y-9 (boş tık), Y-12 (sabit config)
```

### 9.9 PROMPT 8 — Test, sertleştirme, sürüm

```
GÖREV 8 — 787 test, 3 cihaz profili, sürüm

GÖREVLER
8.1  T-01…T-20 zorunlu testleri yaz (§7.2)
8.2  K-1…K-16 ölçüm testleri:
     - Macrobenchmark: soğuk açılış (K-1), kaydırma (K-8)
     - PlanJournal zaman damgası: ADB kurulum (K-3)
     - Compose test + elapsedRealtimeNanos: ayar gecikmesi (K-4)
8.3  Görsel regresyon: Roborazzi, 63 anlık görüntü
     (7 şekil × 9 palet/mod kombinasyonu)
8.4  apk-hygiene.sh genişletme:
     - assets/ içinde video/ses/görsel yok (Y-3)
     - lib/ içinde ffmpeg/ffprobe yok (Y-7)
     - 4 ABI yerine sadece arm64-v8a + armeabi-v7a (boyut)
8.5  Baseline Profile: soğuk açılış için
8.6  R8 fullMode — 44 ayar anahtarının silinmediğini doğrula
8.7  ProGuard kuralları: serialization, Room, Ktor, dadb korunur
8.8  İmzalama: upload key + APK v2 imzası
8.9  Sürüm kontrol listesi 24 madde (§8.3) — hepsini geçir
8.10 Kanıt dizini /home/user/evidence/server/ oluştur

KABUL KRİTERLERİ
□ 787 test geçer
□ Kapsam :core:* ≥ %80 (K-15)
□ APK ≤ 25 MB (K-11)
□ Tüm CI kapıları yeşil
□ 8 cihazda 7 senaryo elle test (2 saat) — sıfır çökme
□ 24 maddelik kontrol listesi tamamen ✅

RİSK ALTINDAKİ YASAKLAR: hepsi son kez denetlenir (K-13: 12/12)
```

---

## 10. HATA KATALOĞU — Server'ın gerçek mesajları

Y-10 gereği her hata **gerçek sebep + çözüm** taşır. 19 `DeployError` + 15 sistem hatası:

| # | Kod | Türkçe mesaj | Çözüm |
|---|---|---|---|
| **D-1** | `ADB_TCP_REFUSED` | "TV'ye bağlanılamadı — port kapalı" | TV'de USB Hata Ayıklama açık mı? Aynı Wi-Fi'da mısınız? |
| **D-2** | `ADB_AUTH_REJECTED` | "TV bu bilgisayarı reddetti" | TV ekranındaki 'Buna izin ver' diyaloğunu onaylayın |
| **D-3** | `ADB_AUTH_TIMEOUT` | "TV kimlik doğrulaması zaman aşımına uğradı" | TV ekranına bakın, 30 sn içinde onaylayın |
| **D-4** | `ADB_PROTOCOL_ERROR` | "TV beklenmedik yanıt verdi (protokol hatası)" | TV'yi yeniden başlatın |
| **D-5** | `ADB_DEVICE_OFFLINE` | "TV çevrimdışı görünüyor" | TV'nin uyuduğundan emin olun |
| **D-6** | `ADB_SHELL_UNAVAILABLE` | "Bu TV kabuk komutlarını desteklemiyor" | Üretici kısıtlaması — farklı TV deneyin |
| **D-7** | `ADB_PUSH_FAILED` | "APK gönderilemedi" | Boş alan kontrol edin (≥ 50 MB) |
| **D-8** | `ADB_PUSH_HASH_MISMATCH` | "Gönderilen dosya bozuldu" | Yeniden deneyin |
| **D-9** | `INSTALL_INSUFFICIENT_SPACE` | "TV'de yeterli alan yok" | En az 50 MB boşaltın |
| **D-10** | `INSTALL_SIGNATURE_MISMATCH` | "TV'de farklı imzalı bir sürüm kurulu" | Eski sürümü kaldırın |
| **D-11** | `INSTALL_VERSION_DOWNGRADE` | "TV'de daha yeni bir sürüm var" | Server'ı güncelleyin |
| **D-12** | `INSTALL_FAILED` | "Kurulum reddedildi" | TV'de 'Bilinmeyen kaynaklar'a izin verin |
| **D-13** | `START_FAILED` | "Kuruldu ama başlatılamadı" | TV'de uygulamayı elle açın |
| **D-14** | `INJECT_FAILED` | "Sunucu adresi iletilemedi" | TV'de uygulama verilerini temizleyin |
| **D-15** | `VERIFY_FAILED` | "Kurulum doğrulanamadı — sürüm uyuşmuyor" | Yeniden kurun |
| **D-16** | `ROLLBACK_TRIGGERED` | "Kurulum geri alındı (başlatma başarısız)" | TV günlüklerini kontrol edin |
| **D-17** | `DEVICE_NOT_FOUND` | "Ağda TV bulunamadı" | IP adresini elle girin |
| **D-18** | `ADB_KEY_GEN_FAILED` | "ADB anahtarı oluşturulamadı" | Depolama alanı dolu olabilir |
| **D-19** | `TOO_MANY_STREAMS` | "4 eşzamanlı akış sınırı doldu" | Diğer cihazlardan birini durdurun |

### 10.2 Sistem hataları — 15

| Kod | Türkçe mesaj | Çözüm |
|---|---|---|
| `UNAUTHORIZED` | "Oturum geçersiz — yeniden eşleştirin" | TV'de yeniden eşleştir |
| `FORBIDDEN` | "Bu işlem için yetkiniz yok" | Yönetici kullanıcı ile deneyin |
| `NOT_FOUND` | "İçerik bulunamadı — taşınmış olabilir" | Yeniden tara |
| `DRM_DETECTED` | "Bu içerik DRM korumalı ve oynatılamaz" | — |
| `INVALID_SETTING` | "Bu değer geçersiz" | Aralığı kontrol edin |
| `CONFLICT` | "Başka bir cihaz bu ayarı değiştirdi" | Yine de yaz / vazgeç |
| `SCAN_IN_PROGRESS` | "Tarama zaten sürüyor" | Bitmesini bekleyin |
| `SCAN_FAILED` | "Tarama tamamlanamadı" | Klasör izinlerini kontrol edin |
| `FOLDER_UNAVAILABLE` | "Klasör erişilemez — izin kaldırılmış" | Klasörü yeniden seçin |
| `SERVER_STOPPED` | "Sunucu kapalı" | Ana ekrandan açın |
| `PORT_IN_USE` | "Port başka uygulama tarafından kullanılıyor" | Farklı port seçin |
| `STORAGE_FULL` | "Depolama alanı doldu" | Yer açın |
| `DB_CORRUPT` | "Veritabanı bozuk" | Yeniden tarama gerekli |
| `NETWORK_UNAVAILABLE` | "Wi-Fi bağlantısı yok" | Ağa bağlanın |
| `TIMEOUT` | "İşlem zaman aşımına uğradı" | Yeniden deneyin |

---

## 11. YOL HARİTASI — Server

| Faz | Süre | İçerik | Çıkış |
|---|---|---:|---|
| **0** | 3 gün | PROMPT 1 — iskelet + `:core:design` | Boş ama çalışan APK |
| **1** | 4 gün | PROMPT 2 — veri + tarama | Kütüphane indeksleniyor |
| **2** | 4 gün | PROMPT 3 — HTTP + akış | `curl` ile film oynuyor |
| **3** | 3 gün | PROMPT 4 — WS + eşleştirme | TV token alıyor |
| **4** | 4 gün | PROMPT 5 — ADB | TV'ye kuruluyor |
| **5** | 3 gün | PROMPT 6 — ayar motoru | Canlı ayar çalışıyor |
| **6** | 4 gün | PROMPT 7 — arayüz | 14 ekran |
| **7** | 3 gün | PROMPT 8 — test + sürüm | Yayına hazır |
| | **28 gün** | | |

**Kritik bağımlılık:** Faz 3 (eşleştirme) **Connect Faz 2'ye bağımlı** — iki uygulama paralel geliştirilirse sözleşme (§0.4) **ilk** dondurulmalı.

---

## 12. EKLER

### 12.1 `discovery_probe` — neden `health` kimlik istemiyor

`GET /api/v1/health` **kimlik gerektirmez**. Gerekçe: Connect, token'ı **almadan önce** sunucunun varlığını doğrulamalı. Bu uç nokta **hiçbir hassas bilgi döndürmez**:

```json
{ "status": "ok", "version": "1.0.0", "api": 1,
  "uptimeSeconds": 48213, "pairingRequired": true }
```

**Döndürmedikleri:** kütüphane adı, kullanıcı adı, öğe sayısı, dosya yolu, IP. Sadece "ben bir GenPlay sunucusuyum, API 1 konuşuyorum, eşleştirme gerekiyor."

### 12.2 `sample` kelimesi — neden yasak

Y-1 `sample` kelimesini yasaklar. Ama Android'de `MediaMetadataRetriever.getFrameAtTime()` **"örnek"** anlamında kullanılabilir. Kural: **değişken/sınıf/dosya adlarında** `sample` yasak; insan dilinde "örnekleme" (sampling) kavramı için `sampling` veya `frame` kullanılır.

`forbidden-literals.sh` bu ayrımı yapar:
```bash
grep -rnE '\b(demo|sample|mock|fake|dummy|lorem)\b' --include='*.kt' . \
  | grep -vE '(sampling|sampleRate|SamplingRate)' && exit 1
```

### 12.3 APK boyut bütçesi — 25 MB nasıl tutulur

| Bileşen | Tahmini | Azaltma |
|---|---:|---|
| Compose UI | 6,8 MB | Baseline Profile + R8 fullMode |
| Room + sqlite | 2,1 MB | — |
| Ktor Netty | 3,4 MB | Netty yerine CIO düşünülebilir (⚠️ Range performansı) |
| Media3 ExoPlayer | 4,2 MB | Tek ABI |
| Coil | 1,1 MB | — |
| Rubik variable font | 0,36 MB | Alt küme ile 0,18 MB |
| Diğer | 4,5 MB | — |
| **Toplam** | **22,5 MB** | **K-11 ≤ 25 MB ✅** |

**Tek ABI:** `arm64-v8a` + `armeabi-v7a` (2 ABI). x86/x86_64 **yalnızca debug** build'de.

### 12.4 Değişiklik geçmişi

| Sürüm | Tarih | Ne |
|---|---|---|
| 1.0 | bugün | İlk yayın — 12 bölüm, 8 prompt, 44 ayar alanı, 20 test |

---

*Bu şartname iki APK'nın statik analizine dayanır (`genplayui.md` §0.5 kanıt dizini). Hiçbir uygulama çalıştırılmamış, hiçbir cihazda kurulum yapılmamıştır.*

*Kardeş doküman: `genplay-connect.md` — §0.4 bölümü birebir aynıdır.*

*Arayüz dosyası: `genplay-server.html` — tek dosya, tam ekran, sahte içerik yok (§13).*

---

## 13. ARAYÜZ DOSYASI — `genplay-server.html`

Tek dosya, tam ekran, **cihaz çerçevesi yok**. Google AI Studio'ya olduğu gibi yapıştırılır.

| Özellik | Değer |
|---|---|
| Boyut | ~58 KB · tek `<style>` · tek `<script>` |
| Dış kaynak | **yok** — `<img>`, `<link>`, CDN, font dosyası yok |
| Sahte içerik | **yok** — kartlar iskelet, listeler gerçek boş durum (Y-1) |
| Palet × mod | 3 × 3 = **9** kombinasyon, sağ üstteki panelden |
| Düzen | Telefon öncelikli; **≥900 px'te alt dock → sol raya** dönüşür |
| Ekranlar | 8 rota: `home`, `library`, `devices`, `deploy`, `player`, `sessions`, `settings` + 6 ayar alt sayfası |

### 13.1 Belirteç senkronu — `genplay-connect.html` ile

İki HTML dosyası **15.252 baytlık belirteç bloğunu birebir aynı** taşır. Kaynak: `src/tokens.css`.
Kaynağı değiştirip iki dosyaya yeniden gömmek zorunludur. Kapı:

```bash
./check-tokens.sh   # 0 = geçti
```

### 13.2 Yerleşim dersi

`applyLayout()` fonksiyonu **genişlik eşiğini JS'te** uygular (820 px). CSS'te `@media` ile
eşik uygulanmış olsaydı "otomatik" biçim çalışmazdı. Bu, ilk yazımda gerçekten kırıldı ve
tarayıcı ölçümüyle yakalandı — statik analizle değil.
